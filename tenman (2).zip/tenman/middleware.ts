// middleware.ts
import { NextResponse, NextRequest } from 'next/server';
import { jwtVerify } from 'jose';

// Paths that require auth
const PROTECTED = [
  '/tenant-portal',
  '/property-owner-dashboard',
  '/tenant-management',
  '/property-management',
  '/financial-reports',
  '/payment-processing',
  '/admin',
  '/dashboard',
];

const PUBLIC_AUTH = ['/login', '/accept-invite', '/reset-password'];

function isPath(pathname: string, list: string[]) {
  return list.some((p) => pathname === p || pathname.startsWith(p + '/'));
}

async function verify(token: string) {
  try {
    const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'dev-secret');
    const { payload } = await jwtVerify(token, secret);
    return !!payload?.sub;
  } catch {
    return false;
  }
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const cookie = req.cookies.get('session')?.value;

  const authed = cookie ? await verify(cookie) : false;

  // If visiting protected paths and not authed → redirect to /login
  if (isPath(pathname, PROTECTED) && !authed) {
    const url = new URL('/login', req.url);
    url.searchParams.set('next', pathname);
    return NextResponse.redirect(url);
  }

  // If visiting public auth pages and already authed → go to /dashboard
  if (isPath(pathname, PUBLIC_AUTH) && authed) {
    const url = new URL('/dashboard', req.url);
    return NextResponse.redirect(url);
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    // cover all pages (we filter inside)
    '/((?!_next/static|_next/image|favicon.ico|images|assets|api/health/db).*)',
  ],
};