import React from 'react';
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import ProtectedHeader from '@/components/common/ProtectedHeader';

export default async function ProtectedLayout({ children }: { children: React.ReactNode }) {
  const me = await getCurrentUser();
  if (!me) redirect('/login');

  return (
    <div className="min-h-dvh bg-background text-foreground">
      {/* Your fixed header */}
      <ProtectedHeader
        user={{ name: me.name ?? null, email: me.email, role: me.primaryRole }}
        notifications={[]}
      />

      {/* Push content below the fixed 64px header */}
      <div className="mx-auto max-w-7xl px-4 pt-20 pb-8">{children}</div>
    </div>
  );
}