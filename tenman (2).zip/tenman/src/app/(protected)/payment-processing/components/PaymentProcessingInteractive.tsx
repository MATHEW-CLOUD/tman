'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import PaymentSummaryCards from './PaymentSummaryCards';
import PendingInvoicesTable from './PendingInvoicesTable';
import PaymentInitiationPanel from './PaymentInitiationPanel';
import MpesaSTKPushModal from './MpesaSTKPushModal';
import TransactionHistory from './TransactionHistory';
import BulkPaymentProcessor from './BulkPaymentProcessor';

type Summary = {
  totalCollections: number;
  outstandingAmount: number;
  monthlyRevenue: number;
  paidInvoices: number;
  pendingInvoices: number;
  overdueInvoices: number;
};

type InvoiceUI = {
  id: string;
  tenantName: string;
  propertyName: string;
  unitNumber: string;
  amount: number;
  dueDate: string; // ISO
  status: 'paid' | 'pending' | 'overdue';
  invoiceNumber: string;
  description: string;
};

type TenantUI = {
  id: string;
  name: string;
  phoneNumber: string;
  propertyName: string;
  unitNumber: string;
};

type TransactionUI = {
  id: string;
  transactionId: string;
  tenantName: string;
  tenantAvatar?: string;
  propertyName: string;
  unitNumber: string;
  amount: number;
  paymentMethod: string; // MPESA | CASH | BANK
  status: 'completed' | 'pending' | 'failed';
  date: string; // ISO
  receiptNumber: string;
  description: string;
  vatAmount: number;
};

type Props = {
  summary: Summary;
  invoices: InvoiceUI[];
  tenants: TenantUI[];
  transactions: TransactionUI[];
};

export default function PaymentProcessingInteractive({
  summary,
  invoices,
  tenants,
  transactions,
}: Props) {
  const router = useRouter();
  const [isHydrated, setIsHydrated] = useState(false);
  const [isMpesaModalOpen, setIsMpesaModalOpen] = useState(false);
  const [currentPaymentData, setCurrentPaymentData] = useState<{
    invoiceId: string;
    tenantName: string;
    amount: number;
    phoneNumber: string;
    description: string;
  } | null>(null);

  useEffect(() => setIsHydrated(true), []);

  const handleInitiatePayment = (invoice: InvoiceUI) => {
    const t = tenants.find((x) => x.name === invoice.tenantName);
    setCurrentPaymentData({
      invoiceId: invoice.id,
      tenantName: invoice.tenantName,
      amount: invoice.amount,
      phoneNumber: t?.phoneNumber || '2547XXXXXXXX',
      description: invoice.description,
    });
    setIsMpesaModalOpen(true);
  };

  const handleViewDetails = (invoice: InvoiceUI) => {
    if (!isHydrated) return;
    console.log('Invoice details:', invoice.id);
  };

  const handleInitiatePaymentFromPanel = (data: {
    tenantId: string;
    amount: number;
    paymentMethod: string;
    phoneNumber: string;
    description: string;
  }) => {
    // Pick first unpaid invoice for that tenant, else fallback to any invoice with same name
    const t = tenants.find((x) => x.id === data.tenantId);
    if (!t) return;

    const candidate =
      invoices.find((i) => i.tenantName === t.name && i.status !== 'paid') ||
      invoices.find((i) => i.tenantName === t.name);

    if (!candidate) {
      alert('No invoice found for this tenant. Please create an invoice first.');
      return;
    }

    setCurrentPaymentData({
      invoiceId: candidate.id,
      tenantName: t.name,
      amount: data.amount || candidate.amount,
      phoneNumber: data.phoneNumber || t.phoneNumber || '2547XXXXXXXX',
      description: data.description || candidate.description,
    });
    setIsMpesaModalOpen(true);
  };

  const handleViewReceipt = (tx: TransactionUI) => {
    if (!isHydrated) return;
    console.log('View receipt:', tx.receiptNumber || tx.transactionId);
  };

  const handleDownloadReceipt = (tx: TransactionUI) => {
    if (!isHydrated) return;
    console.log('Download receipt:', tx.receiptNumber || tx.transactionId);
  };

  const handleProcessBulkPayment = (items: any[]) => {
    if (!isHydrated) return;
    console.log('Processing bulk payments (TBD later):', items);
  };

  return (
    <div className="space-y-6">
      <PaymentSummaryCards summary={summary} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <PendingInvoicesTable
            invoices={invoices}
            onInitiatePayment={handleInitiatePayment}
            onViewDetails={handleViewDetails}
          />

          <BulkPaymentProcessor onProcessBulkPayment={handleProcessBulkPayment} />
        </div>

        <div className="lg:col-span-1">
          <PaymentInitiationPanel tenants={tenants} onInitiatePayment={handleInitiatePaymentFromPanel} />
        </div>
      </div>

      <TransactionHistory
        transactions={transactions}
        onViewReceipt={handleViewReceipt}
        onDownloadReceipt={handleDownloadReceipt}
      />

      <MpesaSTKPushModal
        isOpen={isMpesaModalOpen}
        onClose={() => {
          setIsMpesaModalOpen(false);
          setCurrentPaymentData(null);
        }}
        paymentData={currentPaymentData}
        onCompleted={() => router.refresh()}
      />
    </div>
  );
}