/* FULL FILE REPLACEMENT */

'use client';

import { useEffect, useState } from 'react';
import Icon from '@/components/ui/AppIcon';

export default function MpesaSTKPushModal({
  isOpen,
  onClose,
  onCompleted,
  paymentData,
}: {
  isOpen: boolean;
  onClose: () => void;
  onCompleted?: () => void;
  paymentData: {
    invoiceId: string;
    tenantName: string;
    amount: number;
    phoneNumber: string;
    description: string;
  } | null;
}) {
  const [status, setStatus] = useState<'initiating' | 'pending' | 'success' | 'failed' | 'cancelled'>('initiating');
  const [countdown, setCountdown] = useState(60);
  const [receiptCode, setReceiptCode] = useState('');
  const [paymentId, setPaymentId] = useState('');

  useEffect(() => {
    let poll: any;
    let timeout: any;

    async function start() {
      if (!isOpen || !paymentData) return;

      setStatus('initiating');
      setCountdown(60);

      try {
        const res = await fetch('/api/payments/mpesa/mock', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({
            invoiceId: paymentData.invoiceId,
            amount: paymentData.amount,
            phone: paymentData.phoneNumber,
          }),
        });

        const json = await res.json();
        if (!json?.ok) {
          setStatus('failed');
          return;
        }

        setPaymentId(json.data.payment.id);
        setReceiptCode(json.data.payment.mpesaReceipt);

        setStatus('pending');

        poll = setInterval(() => {
          setCountdown((p) => {
            if (p <= 1) {
              clearInterval(poll);
              if (status !== 'success') setStatus('cancelled');
              return 0;
            }
            return p - 1;
          });
        }, 1000);

        timeout = setTimeout(() => {
          clearInterval(poll);
          setStatus('success');
          onCompleted?.();
        }, 2000);
      } catch (e) {
        setStatus('failed');
      }
    }

    start();

    return () => {
      clearInterval(poll);
      clearTimeout(timeout);
    };
  }, [isOpen, paymentData]);

  if (!isOpen || !paymentData) return null;

  const openReceipt = () => {
    if (paymentId) window.open(`/api/receipts/${paymentId}?view=1`, '_blank');
  };

  const fmtKES = (x: number) =>
    new Intl.NumberFormat('en-KE', {
      style: 'currency', currency: 'KES',
      minimumFractionDigits: 0, maximumFractionDigits: 0
    }).format(x);

  const statusMap = {
    initiating: { icon: 'ArrowPathIcon', title: 'Initiating Payment', spin: true },
    pending: { icon: 'DevicePhoneMobileIcon', title: 'Waiting for M‑Pesa', spin: true },
    success: { icon: 'CheckCircleIcon', title: 'Payment Successful', spin: false },
    failed: { icon: 'XCircleIcon', title: 'Payment Failed', spin: false },
    cancelled: { icon: 'ExclamationTriangleIcon', title: 'Payment Cancelled', spin: false },
  } as any;

  const cfg = statusMap[status];

  return (
    <div className="fixed inset-0 bg-black/50 z-[2000] flex items-center justify-center p-4">
      <div className="bg-card rounded-lg shadow-warm-xl max-w-md w-full">

        <div className="p-6 border-b border-border flex justify-between">
          <h2 className="text-xl font-semibold">M‑Pesa Payment</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
            <Icon name="XMarkIcon" size={24} />
          </button>
        </div>

        <div className="p-6">
          <div className="flex justify-center mb-6">
            <Icon
              name={cfg.icon as any}
              size={50}
              className={`text-primary ${cfg.spin ? 'animate-spin' : ''}`}
            />
          </div>

          <h3 className="text-lg font-semibold text-center mb-2">{cfg.title}</h3>

          {status === 'success' && receiptCode && (
            <div className="text-center text-sm mb-4">
              Receipt: <span className="font-semibold">{receiptCode}</span>
            </div>
          )}

          {/* Payment Details */}
          <div className="bg-muted/50 p-4 rounded-lg mb-6">
            <div className="flex justify-between">
              <span className="text-sm text-muted-foreground">Tenant</span>
              <span className="text-sm font-medium">{paymentData.tenantName}</span>
            </div>
            <div className="flex justify-between mt-2">
              <span className="text-sm text-muted-foreground">Amount</span>
              <span className="text-lg font-semibold">{fmtKES(paymentData.amount)}</span>
            </div>
          </div>

          {/* Countdown */}
          {status === 'pending' && (
            <p className="text-center text-sm text-muted-foreground mb-6">
              Time remaining: <span className="font-semibold">{countdown}s</span>
            </p>
          )}

          {/* Buttons */}
          <div className="flex gap-3">
            {status === 'success' && (
              <>
                <button
                  onClick={onClose}
                  className="flex-1 px-4 py-3 bg-muted rounded-lg"
                >
                  Close
                </button>
                <button
                  onClick={openReceipt}
                  className="flex-1 px-4 py-3 bg-primary text-white rounded-lg"
                >
                  View Receipt
                </button>
              </>
            )}

            {(status === 'failed' || status === 'cancelled') && (
              <button onClick={onClose} className="w-full px-4 py-3 bg-muted rounded-lg">
                Close
              </button>
            )}

            {(status === 'initiating' || status === 'pending') && (
              <button
                onClick={() => setStatus('cancelled')}
                className="w-full px-4 py-3 bg-error text-white rounded-lg"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
``