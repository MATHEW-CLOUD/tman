import Icon from '@/components/ui/AppIcon';

interface PaymentSummary {
  totalCollections: number;
  outstandingAmount: number;
  monthlyRevenue: number;
  paidInvoices: number;
  pendingInvoices: number;
  overdueInvoices: number;
}

interface PaymentSummaryCardsProps {
  summary: PaymentSummary;
}

export default function PaymentSummaryCards({ summary }: PaymentSummaryCardsProps) {
  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const cards = [
    {
      title: 'Total Collections',
      value: summary.totalCollections,
      icon: 'CurrencyDollarIcon',
      bgColor: 'bg-success/10',
      iconColor: 'text-success',
      trend: '+12.5%',
      trendUp: true,
    },
    {
      title: 'Outstanding Amount',
      value: summary.outstandingAmount,
      icon: 'ExclamationTriangleIcon',
      bgColor: 'bg-warning/10',
      iconColor: 'text-warning',
      trend: '-8.3%',
      trendUp: false,
    },
    {
      title: 'Monthly Revenue',
      value: summary.monthlyRevenue,
      icon: 'ChartBarIcon',
      bgColor: 'bg-primary/10',
      iconColor: 'text-primary',
      trend: '+15.2%',
      trendUp: true,
    },
    {
      title: 'Paid Invoices',
      value: summary.paidInvoices,
      icon: 'CheckCircleIcon',
      bgColor: 'bg-success/10',
      iconColor: 'text-success',
      subtitle: `${summary.pendingInvoices} pending`,
    },
    {
      title: 'Overdue Invoices',
      value: summary.overdueInvoices,
      icon: 'ClockIcon',
      bgColor: 'bg-error/10',
      iconColor: 'text-error',
      subtitle: 'Requires attention',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-6">
      {cards.map((card, index) => (
        <div
          key={index}
          className="bg-card rounded-lg p-6 shadow-warm-sm border border-border hover:shadow-warm-md transition-smooth"
        >
          <div className="flex items-start justify-between mb-4">
            <div className={`w-12 h-12 rounded-lg ${card.bgColor} flex items-center justify-center`}>
              <Icon name={card.icon as any} size={24} className={card.iconColor} />
            </div>
            {card.trend && (
              <span
                className={`text-xs font-medium caption ${
                  card.trendUp ? 'text-success' : 'text-error'
                }`}
              >
                {card.trend}
              </span>
            )}
          </div>
          <h3 className="text-sm text-muted-foreground mb-1 caption">{card.title}</h3>
          <p className="text-2xl font-semibold text-foreground mb-1">
            {typeof card.value === 'number' && card.title.toLowerCase().includes('amount') || card.title.toLowerCase().includes('collections') || card.title.toLowerCase().includes('revenue')
              ? formatCurrency(card.value)
              : card.value}
          </p>
          {card.subtitle && (
            <p className="text-xs text-muted-foreground caption">{card.subtitle}</p>
          )}
        </div>
      ))}
    </div>
  );
}