'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface BulkPaymentItem {
  id: string;
  tenantName: string;
  propertyName: string;
  unitNumber: string;
  amount: number;
  phoneNumber: string;
  status: 'pending' | 'processing' | 'success' | 'failed';
  error?: string;
}

interface BulkPaymentProcessorProps {
  onProcessBulkPayment: (items: BulkPaymentItem[]) => void;
}

export default function BulkPaymentProcessor({
  onProcessBulkPayment,
}: BulkPaymentProcessorProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  const mockBulkItems: BulkPaymentItem[] = [
    {
      id: '1',
      tenantName: 'John Kamau',
      propertyName: 'Westlands Apartments',
      unitNumber: 'A101',
      amount: 45000,
      phoneNumber: '+254712345678',
      status: 'pending',
    },
    {
      id: '2',
      tenantName: 'Mary Wanjiku',
      propertyName: 'Kilimani Heights',
      unitNumber: 'B205',
      amount: 38000,
      phoneNumber: '+254723456789',
      status: 'pending',
    },
    {
      id: '3',
      tenantName: 'David Omondi',
      propertyName: 'Parklands Plaza',
      unitNumber: 'C302',
      amount: 52000,
      phoneNumber: '+254734567890',
      status: 'pending',
    },
    {
      id: '4',
      tenantName: 'Grace Akinyi',
      propertyName: 'Westlands Apartments',
      unitNumber: 'A203',
      amount: 45000,
      phoneNumber: '+254745678901',
      status: 'pending',
    },
    {
      id: '5',
      tenantName: 'Peter Mwangi',
      propertyName: 'Kilimani Heights',
      unitNumber: 'B108',
      amount: 38000,
      phoneNumber: '+254756789012',
      status: 'pending',
    },
  ];

  const formatCurrency = (amount: number): string => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const handleSelectAll = () => {
    if (selectedItems.length === mockBulkItems.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(mockBulkItems.map((item) => item.id));
    }
  };

  const handleSelectItem = (id: string) => {
    if (selectedItems.includes(id)) {
      setSelectedItems(selectedItems.filter((itemId) => itemId !== id));
    } else {
      setSelectedItems([...selectedItems, id]);
    }
  };

  const handleProcessPayments = () => {
    if (selectedItems.length === 0) return;
    setIsProcessing(true);
    const itemsToProcess = mockBulkItems.filter((item) =>
      selectedItems.includes(item.id)
    );
    onProcessBulkPayment(itemsToProcess);
    setTimeout(() => {
      setIsProcessing(false);
      setSelectedItems([]);
    }, 3000);
  };

  const totalAmount = mockBulkItems
    .filter((item) => selectedItems.includes(item.id))
    .reduce((sum, item) => sum + item.amount, 0);

  return (
    <div className="bg-card rounded-lg shadow-warm-sm border border-border overflow-hidden">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full p-6 flex items-center justify-between hover:bg-muted/30 transition-smooth"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name="BanknotesIcon" size={24} className="text-primary" />
          </div>
          <div className="text-left">
            <h2 className="text-xl font-semibold text-foreground">Bulk Payment Processing</h2>
            <p className="text-sm text-muted-foreground caption">
              Process multiple rent payments at once
            </p>
          </div>
        </div>
        <Icon
          name="ChevronDownIcon"
          size={24}
          className={`text-muted-foreground transition-transform ${
            isExpanded ? 'rotate-180' : ''
          }`}
        />
      </button>

      {isExpanded && (
        <div className="border-t border-border">
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={selectedItems.length === mockBulkItems.length}
                    onChange={handleSelectAll}
                    className="w-5 h-5 rounded border-input text-primary focus:ring-2 focus:ring-primary cursor-pointer"
                  />
                  <span className="text-sm font-medium text-foreground">Select All</span>
                </label>
                {selectedItems.length > 0 && (
                  <span className="text-sm text-muted-foreground caption">
                    {selectedItems.length} of {mockBulkItems.length} selected
                  </span>
                )}
              </div>
              {selectedItems.length > 0 && (
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs text-muted-foreground caption">Total Amount</p>
                    <p className="text-lg font-semibold text-foreground">
                      {formatCurrency(totalAmount)}
                    </p>
                  </div>
                  <button
                    onClick={handleProcessPayments}
                    disabled={isProcessing}
                    className="px-6 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-smooth font-medium flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isProcessing ? (
                      <>
                        <Icon name="ArrowPathIcon" size={20} className="animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Icon name="PaperAirplaneIcon" size={20} />
                        Process Payments
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Desktop Table */}
            <div className="hidden lg:block overflow-x-auto">
              <table className="w-full">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-4 py-3 text-left">
                      <input
                        type="checkbox"
                        checked={selectedItems.length === mockBulkItems.length}
                        onChange={handleSelectAll}
                        className="w-5 h-5 rounded border-input text-primary focus:ring-2 focus:ring-primary cursor-pointer"
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">
                      Tenant
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">
                      Property/Unit
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">
                      Phone Number
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-semibold text-foreground">
                      Amount
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {mockBulkItems.map((item) => (
                    <tr
                      key={item.id}
                      className={`hover:bg-muted/30 transition-smooth ${
                        selectedItems.includes(item.id) ? 'bg-primary/5' : ''
                      }`}
                    >
                      <td className="px-4 py-3">
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(item.id)}
                          onChange={() => handleSelectItem(item.id)}
                          className="w-5 h-5 rounded border-input text-primary focus:ring-2 focus:ring-primary cursor-pointer"
                        />
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm font-medium text-foreground">
                          {item.tenantName}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div>
                          <p className="text-sm text-foreground">{item.propertyName}</p>
                          <p className="text-xs text-muted-foreground caption">
                            Unit {item.unitNumber}
                          </p>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm text-foreground data-text">
                          {item.phoneNumber}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className="text-sm font-semibold text-foreground">
                          {formatCurrency(item.amount)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile Cards */}
            <div className="lg:hidden space-y-3">
              {mockBulkItems.map((item) => (
                <label
                  key={item.id}
                  className={`block p-4 rounded-lg border-2 transition-smooth cursor-pointer ${
                    selectedItems.includes(item.id)
                      ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={selectedItems.includes(item.id)}
                      onChange={() => handleSelectItem(item.id)}
                      className="w-5 h-5 rounded border-input text-primary focus:ring-2 focus:ring-primary cursor-pointer mt-1"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-foreground mb-1">
                        {item.tenantName}
                      </p>
                      <p className="text-xs text-muted-foreground caption mb-2">
                        {item.propertyName} - Unit {item.unitNumber}
                      </p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-muted-foreground caption data-text">
                          {item.phoneNumber}
                        </span>
                        <span className="text-base font-semibold text-foreground">
                          {formatCurrency(item.amount)}
                        </span>
                      </div>
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}