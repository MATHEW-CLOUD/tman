'use client';
import Icon from '@/components/ui/AppIcon';

type Invoice = {
  id: string;
  tenantName: string;
  propertyName: string;
  unitNumber: string;
  amount: number;
  dueDate: string; // ISO
  status: 'paid' | 'pending' | 'overdue';
  invoiceNumber: string;
  description: string;
};

type Props = {
  invoices: Invoice[];
  onInitiatePayment: (invoice: Invoice) => void;
  onViewDetails: (invoice: Invoice) => void;
};

export default function PendingInvoicesTable({ invoices, onInitiatePayment, onViewDetails }: Props) {
  const formatCurrency = (amount: number) =>
    new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);

  const formatDate = (iso: string) =>
    new Date(iso).toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });

  const getStatusChip = (status: Invoice['status']) => {
    switch (status) {
      case 'paid':
        return { label: 'Paid', chip: 'bg-success/10 text-success', icon: 'CheckCircleIcon' };
      case 'overdue':
        return { label: 'Overdue', chip: 'bg-error/10 text-error', icon: 'ExclamationCircleIcon' };
      default:
        return { label: 'Pending', chip: 'bg-warning/10 text-warning', icon: 'ClockIcon' };
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-sm border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-foreground mb-1">Pending Invoices</h2>
            <p className="text-sm text-muted-foreground caption">
              Manage and track payment status for all invoices
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-smooth flex items-center gap-2">
              <Icon name="FunnelIcon" size={20} />
              <span className="hidden sm:inline">Filter</span>
            </button>
            <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-smooth flex items-center gap-2">
              <Icon name="DocumentPlusIcon" size={20} />
              <span className="hidden sm:inline">Generate Invoice</span>
            </button>
          </div>
        </div>
      </div>

      {/* Desktop Table */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Invoice #</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Tenant</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Property/Unit</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Amount</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Due Date</th>
              <th className="px-6 py-4 text-left text-sm font-semibold text-foreground">Status</th>
              <th className="px-6 py-4 text-right text-sm font-semibold text-foreground">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {invoices.map((inv) => {
              const s = getStatusChip(inv.status);
              const overdue = inv.status !== 'paid' && new Date(inv.dueDate) < new Date();
              return (
                <tr key={inv.id} className="hover:bg-muted/30 transition-smooth">
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium text-foreground data-text">{inv.invoiceNumber}</p>
                      <p className="text-xs text-muted-foreground caption">{inv.description}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-foreground">{inv.tenantName}</p>
                  </td>
                    <p className="text-xs text-muted-foreground caption">Unit {inv.unitNumber}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm font-semibold text-foreground">{formatCurrency(inv.amount)}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm text-foreground">{formatDate(inv.dueDate)}</p>
                      {overdue && <p className="text-xs text-error caption">Overdue</p>}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${s.chip}`}>
                      <Icon name={s.icon as any} size={14} />
                      {s.label}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => onViewDetails(inv)}
                        className="p-2 hover:bg-muted rounded-lg transition-smooth"
                        aria-label="View details"
                      >
                        <Icon name="EyeIcon" size={18} className="text-muted-foreground" />
                      </button>
                      {inv.status !== 'paid' && (
                        <button
                          onClick={() => onInitiatePayment(inv)}
                          className="px-3 py-1.5 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-smooth text-sm font-medium"
                        >
                          Collect Payment
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
            {invoices.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center text-muted-foreground">
                  No invoices found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="lg:hidden divide-y divide-border">
        {invoices.map((inv) => {
          const s = getStatusChip(inv.status);
          const overdue = inv.status !== 'paid' && new Date(inv.dueDate) < new Date();
          return (
            <div key={inv.id} className="p-4 hover:bg-muted/30 transition-smooth">
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground">{inv.tenantName}</p>
                  <p className="text-xs text-muted-foreground caption">
                    {inv.propertyName} — Unit {inv.unitNumber}
                  </p>
                  <p className="text-xs text-muted-foreground caption data-text">{inv.invoiceNumber}</p>
                </div>
                <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${s.chip}`}>
                  <Icon name={s.icon as any} size={12} />
                  {s.label}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <p className="text-xs text-muted-foreground caption mb-1">Amount Due</p>
                  <p className="text-base font-semibold text-foreground">{formatCurrency(inv.amount)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground caption mb-1">Due Date</p>
                  <p className="text-sm text-foreground">{formatDate(inv.dueDate)}</p>
                  {overdue && <p className="text-xs text-error caption">Overdue</p>}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onViewDetails(inv)}
                  className="flex-1 px-4 py-2 bg-muted text-foreground rounded-lg hover:bg-muted/80 transition-smooth text-sm font-medium flex items-center justify-center gap-2"
                >
                  <Icon name="EyeIcon" size={18} />
                  View Details
                </button>
                {inv.status !== 'paid' && (
                  <button
                    onClick={() => onInitiatePayment(inv)}
                    className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-smooth text-sm font-medium"
                  >
                    Collect Payment
                  </button>
                )}
              </div>
            </div>
          );
        })}
        {invoices.length === 0 && (
          <div className="p-6 text-center text-muted-foreground">No invoices found.</div>
        )}
      </div>
    </div>
  );
}