'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Tenant {
  id: string;
  name: string;
  phoneNumber: string;
  propertyName: string;
  unitNumber: string;
}

interface PaymentInitiationPanelProps {
  tenants: Tenant[];
  onInitiatePayment: (data: PaymentData) => void;
}

interface PaymentData {
  tenantId: string;
  amount: number;
  paymentMethod: string;
  phoneNumber: string;
  description: string;
}

export default function PaymentInitiationPanel({
  tenants,
  onInitiatePayment,
}: PaymentInitiationPanelProps) {
  const [selectedTenant, setSelectedTenant] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [paymentMethod, setPaymentMethod] = useState<string>('mpesa');
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [description, setDescription] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const paymentMethods = [
    { id: 'mpesa', name: 'M-Pesa', icon: 'DevicePhoneMobileIcon', color: 'text-success' },
    { id: 'airtel', name: 'Airtel Money', icon: 'DevicePhoneMobileIcon', color: 'text-error' },
    { id: 'tkash', name: 'T-Kash', icon: 'DevicePhoneMobileIcon', color: 'text-warning' },
    { id: 'bank', name: 'Bank Transfer', icon: 'BuildingLibraryIcon', color: 'text-primary' },
  ];

  const validatePhoneNumber = (phone: string): boolean => {
    const kenyanPhoneRegex = /^(\+254|254|0)?[17]\d{8}$/;
    return kenyanPhoneRegex.test(phone);
  };

  const formatPhoneNumber = (phone: string): string => {
    let cleaned = phone.replace(/\D/g, '');
    if (cleaned.startsWith('0')) {
      cleaned = '254' + cleaned.substring(1);
    } else if (!cleaned.startsWith('254')) {
      cleaned = '254' + cleaned;
    }
    return cleaned;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!selectedTenant) {
      newErrors.tenant = 'Please select a tenant';
    }
    if (!amount || parseFloat(amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount';
    }
    if (!phoneNumber) {
      newErrors.phoneNumber = 'Please enter a phone number';
    } else if (!validatePhoneNumber(phoneNumber)) {
      newErrors.phoneNumber = 'Please enter a valid Kenyan phone number';
    }
    if (!description) {
      newErrors.description = 'Please enter a description';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const formattedPhone = formatPhoneNumber(phoneNumber);
    onInitiatePayment({
      tenantId: selectedTenant,
      amount: parseFloat(amount),
      paymentMethod,
      phoneNumber: formattedPhone,
      description,
    });

    // Reset form
    setSelectedTenant('');
    setAmount('');
    setPhoneNumber('');
    setDescription('');
    setErrors({});
  };

  const handleTenantChange = (tenantId: string) => {
    setSelectedTenant(tenantId);
    const tenant = tenants.find((t) => t.id === tenantId);
    if (tenant) {
      setPhoneNumber(tenant.phoneNumber);
    }
    setErrors({ ...errors, tenant: '' });
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-sm border border-border p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
          <Icon name="CreditCardIcon" size={24} className="text-primary" />
        </div>
        <div>
          <h2 className="text-xl font-semibold text-foreground">Initiate Payment</h2>
          <p className="text-sm text-muted-foreground caption">
            Collect rent and other payments from tenants
          </p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Tenant Selection */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Select Tenant <span className="text-error">*</span>
          </label>
          <div className="relative">
            <select
              value={selectedTenant}
              onChange={(e) => handleTenantChange(e.target.value)}
              className={`w-full px-4 py-3 bg-background border rounded-lg text-foreground appearance-none cursor-pointer transition-smooth focus:outline-none focus:ring-2 focus:ring-primary ${
                errors.tenant ? 'border-error' : 'border-input'
              }`}
            >
              <option value="">Choose a tenant...</option>
              {tenants.map((tenant) => (
                <option key={tenant.id} value={tenant.id}>
                  {tenant.name} - {tenant.propertyName} (Unit {tenant.unitNumber})
                </option>
              ))}
            </select>
            <Icon
              name="ChevronDownIcon"
              size={20}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none"
            />
          </div>
          {errors.tenant && (
            <p className="text-xs text-error mt-1 caption">{errors.tenant}</p>
          )}
        </div>

        {/* Amount */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Amount (KES) <span className="text-error">*</span>
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
              KES
            </span>
            <input
              type="number"
              value={amount}
              onChange={(e) => {
                setAmount(e.target.value);
                setErrors({ ...errors, amount: '' });
              }}
              placeholder="0.00"
              className={`w-full pl-16 pr-4 py-3 bg-background border rounded-lg text-foreground transition-smooth focus:outline-none focus:ring-2 focus:ring-primary ${
                errors.amount ? 'border-error' : 'border-input'
              }`}
            />
          </div>
          {errors.amount && (
            <p className="text-xs text-error mt-1 caption">{errors.amount}</p>
          )}
        </div>

        {/* Payment Method */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Payment Method <span className="text-error">*</span>
          </label>
          <div className="grid grid-cols-2 gap-3">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                type="button"
                onClick={() => setPaymentMethod(method.id)}
                className={`p-4 rounded-lg border-2 transition-smooth flex items-center gap-3 ${
                  paymentMethod === method.id
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                }`}
              >
                <Icon name={method.icon as any} size={24} className={method.color} />
                <span className="text-sm font-medium text-foreground">{method.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Phone Number */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Phone Number <span className="text-error">*</span>
          </label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground">
              +254
            </span>
            <input
              type="tel"
              value={phoneNumber}
              onChange={(e) => {
                setPhoneNumber(e.target.value);
                setErrors({ ...errors, phoneNumber: '' });
              }}
              placeholder="712345678"
              className={`w-full pl-20 pr-4 py-3 bg-background border rounded-lg text-foreground transition-smooth focus:outline-none focus:ring-2 focus:ring-primary ${
                errors.phoneNumber ? 'border-error' : 'border-input'
              }`}
            />
          </div>
          {errors.phoneNumber && (
            <p className="text-xs text-error mt-1 caption">{errors.phoneNumber}</p>
          )}
          <p className="text-xs text-muted-foreground mt-1 caption">
            Enter phone number in format: 0712345678 or 712345678
          </p>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-foreground mb-2">
            Description <span className="text-error">*</span>
          </label>
          <input
            type="text"
            value={description}
            onChange={(e) => {
              setDescription(e.target.value);
              setErrors({ ...errors, description: '' });
            }}
            placeholder="e.g., January 2026 Rent Payment"
            className={`w-full px-4 py-3 bg-background border rounded-lg text-foreground transition-smooth focus:outline-none focus:ring-2 focus:ring-primary ${
              errors.description ? 'border-error' : 'border-input'
            }`}
          />
          {errors.description && (
            <p className="text-xs text-error mt-1 caption">{errors.description}</p>
          )}
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary/90 transition-smooth font-medium flex items-center justify-center gap-2"
        >
          <Icon name="PaperAirplaneIcon" size={20} />
          Initiate Payment
        </button>
      </form>
    </div>
  );
}