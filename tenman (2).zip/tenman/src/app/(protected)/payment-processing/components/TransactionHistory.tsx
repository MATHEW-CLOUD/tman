/* FULL FILE REPLACEMENT */

'use client';

import Icon from '@/components/ui/AppIcon';

function fmtKES(n: number) {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency', currency: 'KES',
    minimumFractionDigits: 0, maximumFractionDigits: 0
  }).format(n);
}
function fmtDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function statusChip(s: string) {
  switch (s) {
    case 'completed': return { label: 'Completed', chip: 'bg-success/10 text-success', icon: 'CheckCircleIcon' };
    case 'pending': return { label: 'Pending', chip: 'bg-warning/10 text-warning', icon: 'ClockIcon' };
    default: return { label: 'Failed', chip: 'bg-error/10 text-error', icon: 'XCircleIcon' };
  }
}

export default function TransactionHistory({ transactions }: any) {
  return (
    <div className="bg-card rounded-lg shadow-warm-sm border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <h2 className="text-xl font-semibold mb-1">Transaction History</h2>
        <p className="text-sm text-muted-foreground">View and manage all payment transactions</p>
      </div>

      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-6 py-4 text-left">Receipt</th>
              <th className="px-6 py-4 text-left">Tenant</th>
              <th className="px-6 py-4 text-left">Property/Unit</th>
              <th className="px-6 py-4 text-left">Amount</th>
              <th className="px-6 py-4 text-left">Method</th>
              <th className="px-6 py-4 text-left">Date</th>
              <th className="px-6 py-4 text-left">Status</th>
              <th className="px-6 py-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {transactions.map((t: any) => {
              const s = statusChip(t.status);
              return (
                <tr key={t.id}>
                  <td className="px-6 py-4 data-text">{t.transactionId}</td>
                  <td className="px-6 py-4">{t.tenantName}</td>
                  <td className="px-6 py-4">{t.propertyName} – {t.unitNumber}</td>
                  <td className="px-6 py-4 font-semibold">{fmtKES(t.amount)}</td>
                  <td className="px-6 py-4">{t.paymentMethod}</td>
                  <td className="px-6 py-4">{fmtDate(t.date)}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${s.chip}`}>
                      <Icon name={s.icon as any} size={14} /> {s.label}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right flex gap-2 justify-end">

                    {/* View Receipt */}
                    <button
                      onClick={() => window.open(`/api/receipts/${t.id}?view=1`, '_blank')}
                      className="p-2 hover:bg-muted rounded-lg"
                    >
                      <Icon name="EyeIcon" size={18} />
                    </button>

                    {/* Download Receipt */}
                    <button
                      onClick={() => window.open(`/api/receipts/${t.id}?download=1`, '_blank')}
                      className="p-2 hover:bg-muted rounded-lg"
                    >
                      <Icon name="ArrowDownTrayIcon" size={18} />
                    </button>
                  </td>
                </tr>
              );
            })}
            {transactions.length === 0 && (
              <tr><td colSpan={8} className="text-center py-10 text-muted-foreground">No transactions found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
