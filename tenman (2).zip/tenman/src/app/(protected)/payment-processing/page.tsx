import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { redirect } from 'next/navigation';
import PaymentProcessingInteractive from './components/PaymentProcessingInteractive';

export const dynamic = 'force-dynamic';

type Summary = {
  totalCollections: number;
  outstandingAmount: number;
  monthlyRevenue: number;
  paidInvoices: number;
  pendingInvoices: number;
  overdueInvoices: number;
};

export default async function PaymentProcessingPage() {
  const me = await getCurrentUser();
  if (!me) redirect('/login');

  const orgIds = me.membershipOrgIds;

  // Load invoices → map to UI shape
  const invoicesRaw = await prisma.invoice.findMany({
    where: { organizationId: { in: orgIds } },
    include: {
      lease: {
        include: {
          tenant: { select: { id: true, name: true, email: true, phoneNumber: true } },
          unit: { include: { property: { select: { id: true, name: true } } } },
        },
      },
      payments: true,
    },
    orderBy: { dueDate: 'asc' },
  });

  const now = new Date();

  const invoices = invoicesRaw.map((inv) => {
    const tenantName = inv.lease.tenant.name ?? inv.lease.tenant.email;
    const statusUi =
      inv.status === 'PAID'
        ? 'paid'
        : inv.dueDate < now
        ? 'overdue'
        : 'pending';

    return {
      id: inv.id, // UI uses this for actions
      tenantName,
      propertyName: inv.lease.unit.property.name,
      unitNumber: inv.lease.unit.unitNumber,
      amount: Number(inv.amount),
      dueDate: inv.dueDate.toISOString(),
      status: statusUi as 'paid' | 'pending' | 'overdue',
      invoiceNumber: inv.reference || `INV-${inv.id.slice(0, 6).toUpperCase()}`,
      description: inv.description ?? '',
    };
  });

  // Tenants (from active leases)
  const activeLeases = await prisma.lease.findMany({
    where: {
      unit: { property: { organizationId: { in: orgIds } } },
      status: 'ACTIVE',
    },
    include: {
      tenant: { select: { id: true, name: true, email: true, phoneNumber: true } },
      unit: { include: { property: { select: { name: true } } } },
    },
  });

  const tenants = activeLeases.map((l) => ({
    id: l.tenant.id,
    name: l.tenant.name ?? l.tenant.email,
    phoneNumber: l.tenant.phoneNumber ?? '',
    propertyName: l.unit.property.name,
    unitNumber: l.unit.unitNumber,
  }));

  // Payments → Transaction history
  const paymentsRaw = await prisma.payment.findMany({
    where: { invoice: { organizationId: { in: orgIds } } },
    include: {
      invoice: {
        include: {
          lease: {
            include: {
              tenant: { select: { id: true, name: true, email: true } },
              unit: { include: { property: { select: { name: true } } } },
            },
          },
        },
      },
    },
    orderBy: { paidAt: 'desc' },
    take: 100,
  });

  const transactions = paymentsRaw.map((p) => {
    const tenantName = p.invoice.lease.tenant.name ?? p.invoice.lease.tenant.email;
    const statusUi =
      p.status === 'SUCCESS' ? 'completed' : p.status === 'PENDING' ? 'pending' : 'failed';

    return {
      id: p.id,
      transactionId: p.mpesaReceipt ?? p.id.slice(0, 10).toUpperCase(),
      tenantName,
      propertyName: p.invoice.lease.unit.property.name,
      unitNumber: p.invoice.lease.unit.unitNumber,
      amount: Number(p.amount),
      paymentMethod: p.method, // 'MPESA' | 'CASH' | 'BANK'
      status: statusUi as 'completed' | 'pending' | 'failed',
      date: p.paidAt.toISOString(),
      receiptNumber: p.mpesaReceipt ?? '',
      description: p.invoice.description ?? '',
      vatAmount: 0,
    };
  });

  // Summary (same logic as /api/payments/summary)
  let totalCollections = 0;
  let monthlyRevenue = 0;
  let paidInvoices = 0;
  let pendingInvoices = 0;
  let overdueInvoices = 0;
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  for (const inv of invoicesRaw) {
    const paid = inv.payments
      .filter((p) => p.status === 'SUCCESS')
      .reduce((s, p) => s + Number(p.amount), 0);
    totalCollections += paid;

    const monthlyPaid = inv.payments
      .filter((p) => p.status === 'SUCCESS' && p.paidAt >= monthStart)
      .reduce((s, p) => s + Number(p.amount), 0);
    monthlyRevenue += monthlyPaid;

    if (inv.status === 'PAID') paidInvoices++;
    else if (inv.status === 'PENDING' || inv.status === 'PARTIALLY_PAID') pendingInvoices++;

    if (inv.status !== 'PAID' && inv.dueDate < now) overdueInvoices++;
  }
  const outstandingAmount =
    invoicesRaw.reduce((sum, inv) => sum + Number(inv.amount), 0) - totalCollections;

  const summary: Summary = {
    totalCollections,
    outstandingAmount,
    monthlyRevenue,
    paidInvoices,
    pendingInvoices,
    overdueInvoices,
  };

  return (
    <div className="space-y-6">
      <PaymentProcessingInteractive
        summary={summary}
        invoices={invoices}
        tenants={tenants}
        transactions={transactions}
      />
    </div>
  );
}