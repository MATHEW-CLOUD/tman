'use client';

import { useState } from 'react';

export default function UnitFormModal({
  open,
  onClose,
  initial,
  propertyId,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  initial: any | null;
  propertyId: string;
  onSaved: () => void;
}) {
  const isEdit = !!initial;

  const [unitNumber, setUnitNumber] = useState(initial?.unitNumber ?? '');
  const [bedrooms, setBedrooms] = useState(initial?.bedrooms ?? '');
  const [rentAmount, setRentAmount] = useState(initial?.rentAmount ?? '');
  const [status, setStatus] = useState(initial?.status ?? 'AVAILABLE');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (!open) return null;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const payload = {
        propertyId,
        unitNumber,
        bedrooms: bedrooms ? Number(bedrooms) : null,
        rentAmount: Number(rentAmount),
        status,
      };

      let res: Response;
      if (isEdit) {
        res = await fetch(`/api/units/${initial.id}`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(payload),
        });
      } else {
        res = await fetch(`/api/units`, {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(payload),
        });
      }

      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json?.error || 'Failed to save unit');

      onSaved();
    } catch (e: any) {
      setError(e.message || 'Failed to save unit');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 z-[2000] flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-lg w-full max-w-lg">
        <div className="p-4 border-b border-border flex items-center justify-between">
          <h3 className="text-lg font-semibold">{isEdit ? 'Edit Unit' : 'Add Unit'}</h3>
          <button className="p-2 hover:bg-muted rounded" onClick={onClose}>
            Close
          </button>
        </div>

        <form onSubmit={submit} className="p-4 space-y-4">
          <div>
            <label className="block text-sm font-medium">Unit Number</label>
            <input
              required
              value={unitNumber}
              onChange={(e) => setUnitNumber(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-md border border-input bg-background"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium">Bedrooms</label>
              <input
                type="number"
                value={bedrooms}
                onChange={(e) => setBedrooms(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-md border border-input bg-background"
              />
            </div>

            <div>
              <label className="block text-sm font-medium">Rent Amount (KES)</label>
              <input
                required
                type="number"
                value={rentAmount}
                onChange={(e) => setRentAmount(e.target.value)}
                className="mt-1 w-full px-3 py-2 rounded-md border border-input bg-background"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium">Status</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="mt-1 w-full px-3 py-2 rounded-md border border-input bg-background"
            >
              <option value="AVAILABLE">AVAILABLE</option>
              <option value="OCCUPIED">OCCUPIED</option>
              <option value="MAINTENANCE">MAINTENANCE</option>
            </select>
          </div>

          {error && <p className="text-sm text-red-600">{error}</p>}

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded bg-muted"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 rounded bg-primary text-white"
            >
              {loading ? 'Saving…' : isEdit ? 'Save Changes' : 'Add Unit'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}