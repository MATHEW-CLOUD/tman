'use client';

export default function DocumentsTab({ propertyId }: { propertyId: string }) {
  return (
    <div className="text-sm text-muted-foreground">
      Documents for this property are not yet managed in TENMAN. We will add:
      <ul className="list-disc ml-5 mt-2">
        <li>Upload and store property files</li>
        <li>Link documents to leases and units</li>
        <li>Owner/Tenant downloadable access</li>
      </ul>
      <p className="mt-2">Property ID: <span className="data-text">{propertyId}</span></p>
    </div>
  );
}
``