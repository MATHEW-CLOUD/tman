'use client';

import UnitManagementInteractive from './UnitManagementInteractive';

export default function UnitsTab({ propertyId }: { propertyId: string }) {
  return (
    <div>
      <UnitManagementInteractive propertyId={propertyId} />
    </div>
  );
}