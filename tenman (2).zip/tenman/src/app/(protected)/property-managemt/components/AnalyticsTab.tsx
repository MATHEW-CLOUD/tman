'use client';

export default function AnalyticsTab({
  totalUnits,
  occupiedUnits,
}: {
  totalUnits: number;
  occupiedUnits: number;
}) {
  const rate = totalUnits ? Math.round((occupiedUnits / totalUnits) * 100) : 0;
  const available = totalUnits - occupiedUnits;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="bg-card border border-border rounded-lg p-4">
        <p className="text-sm text-muted-foreground">Total Units</p>
        <p className="text-2xl font-semibold">{totalUnits}</p>
      </div>
      <div className="bg-card border border-border rounded-lg p-4">
        <p className="text-sm text-muted-foreground">Occupied Units</p>
        <p className="text-2xl font-semibold">{occupiedUnits}</p>
      </div>
      <div className="bg-card border border-border rounded-lg p-4">
        <p className="text-sm text-muted-foreground">Available Units</p>
        <p className="text-2xl font-semibold">{available}</p>
      </div>

      <div className="md:col-span-3 bg-card border border-border rounded-lg p-4">
        <p className="text-sm text-muted-foreground mb-2">Occupancy</p>
        <div className="h-3 rounded bg-muted overflow-hidden">
          <div className="h-3 bg-success" style={{ width: `${rate}%` }} />
        </div>
        <p className="mt-1 text-xs text-muted-foreground">{rate}% occupancy</p>
      </div>
    </div>
  );
}