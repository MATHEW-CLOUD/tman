'use client';

export default function UnitTable({
  units,
  onEdit,
  onDelete,
}: {
  units: any[];
  onEdit: (unit: any) => void;
  onDelete: (id: string) => void;
}) {
  return (
    <div className="overflow-x-auto border border-border rounded-lg">
      <table className="w-full">
        <thead className="bg-muted/50">
          <tr>
            <th className="px-4 py-3 text-left text-sm font-semibold">Unit Number</th>
            <th className="px-4 py-3 text-left text-sm font-semibold">Bedrooms</th>
            <th className="px-4 py-3 text-left text-sm font-semibold">Rent (KES)</th>
            <th className="px-4 py-3 text-left text-sm font-semibold">Status</th>
            <th className="px-4 py-3 text-left text-sm font-semibold">Tenant</th>
            <th className="px-4 py-3 text-right text-sm font-semibold">Actions</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {units.map((u) => {
            const lease = u.leases?.[0] ?? null;
            return (
              <tr key={u.id} className="hover:bg-muted/30 transition-smooth">
                <td className="px-4 py-3">{u.unitNumber}</td>
                <td className="px-4 py-3">{u.bedrooms ?? '—'}</td>
                <td className="px-4 py-3 font-medium">{Number(u.rentAmount).toLocaleString()}</td>
                <td className="px-4 py-3">
                  <span
                    className={`px-2 py-1 rounded-full text-xs font-medium ${
                      u.status === 'OCCUPIED'
                        ? 'bg-success/10 text-success'
                        : u.status === 'MAINTENANCE'
                        ? 'bg-warning/10 text-warning'
                        : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {u.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  {lease ? lease.tenant.name ?? lease.tenant.email : '—'}
                </td>
                <td className="px-4 py-3 text-right flex gap-2 justify-end">
                  <button
                    onClick={() => onEdit(u)}
                    className="px-3 py-1.5 bg-muted rounded hover:bg-muted/80 text-sm"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => onDelete(u.id)}
                    className="px-3 py-1.5 bg-error text-error-foreground rounded hover:bg-error/90 text-sm"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            );
          })}

          {units.length === 0 && (
            <tr>
              <td colSpan={6} className="text-center py-8 text-muted-foreground">
                No units found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}