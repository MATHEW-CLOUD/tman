'use client';

import Icon from '@/components/ui/AppIcon';

export default function PropertyHeader({
  query,
  onQueryChange,
  onAdd,
  count,
}: {
  query: string;
  onQueryChange: (v: string) => void;
  onAdd: () => void;
  count: number;
}) {
  return (
    <div className="bg-card border border-border rounded-lg p-4 shadow-warm-sm">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">Property Management</h1>
          <p className="text-sm text-muted-foreground">
            Manage properties, units, and occupancy • {count} total
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Icon name="MagnifyingGlassIcon" size={18} className="absolute left-3 top-2.5 text-muted-foreground" />
            <input
              value={query}
              onChange={(e) => onQueryChange(e.target.value)}
              placeholder="Search properties..."
              className="pl-9 pr-3 py-2 rounded-md border border-input bg-background"
            />
          </div>
          <button
            onClick={onAdd}
            className="px-4 py-2 rounded-md bg-primary text-white hover:opacity-90 flex items-center gap-2"
          >
            <Icon name="PlusCircleIcon" size={18} />
            Add Property
          </button>
        </div>
      </div>
    </div>
  );
}