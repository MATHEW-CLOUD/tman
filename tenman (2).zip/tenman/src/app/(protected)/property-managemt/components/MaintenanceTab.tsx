'use client';

export default function MaintenanceTab({ propertyId }: { propertyId: string }) {
  return (
    <div className="text-sm text-muted-foreground">
      Maintenance requests will be added in the Maintenance module (next).
      <ul className="list-disc ml-5 mt-2">
        <li>Create requests with priority and status</li>
        <li>Assign vendors and track costs</li>
        <li>Auto-notify tenants and managers</li>
      </ul>
      <p className="mt-2">Property ID: <span className="data-text">{propertyId}</span></p>
    </div>
  );
}