'use client';

import { useState, useEffect } from 'react';
import UnitTable from './UnitTable';
import UnitFormModal from './UnitFormModal';
import { useRouter } from 'next/navigation';

export default function UnitManagementInteractive({ propertyId }: { propertyId: string }) {
  const router = useRouter();

  const [units, setUnits] = useState<any[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState<string | null>(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<any | null>(null);

  async function load() {
    setLoading(true);
    setErr(null);
    try {
      const res = await fetch(`/api/properties/${propertyId}`, { cache: 'no-store' });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || 'Failed to load units');
      setUnits(json.data.units || []);
    } catch (e: any) {
      setErr(e.message || 'Failed to load units');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [propertyId]);

  function openCreate() {
    setEditing(null);
    setModalOpen(true);
  }

  function openEdit(unit: any) {
    setEditing({
      id: unit.id,
      unitNumber: unit.unitNumber,
      bedrooms: unit.bedrooms ?? '',
      rentAmount: Number(unit.rentAmount),
      status: unit.status,
    });
    setModalOpen(true);
  }

  async function onDelete(id: string) {
    if (!confirm('Delete this unit?')) return;
    const res = await fetch(`/api/units/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      alert(j?.error || 'Failed to delete unit');
      return;
    }
    load();
    router.refresh();
  }

  function onSaved() {
    setModalOpen(false);
    setEditing(null);
    load();
    router.refresh();
  }

  if (loading) return <p className="text-sm text-muted-foreground">Loading units…</p>;
  if (err) return <p className="text-sm text-red-600">{err}</p>;
  if (!units) return <p className="text-sm text-muted-foreground">No units found.</p>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-lg">Units</h3>
        <button
          onClick={openCreate}
          className="px-4 py-2 bg-primary text-white rounded-lg hover:bg-primary/90"
        >
          Add Unit
        </button>
      </div>

      <UnitTable units={units} onEdit={openEdit} onDelete={onDelete} />

      <UnitFormModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditing(null); }}
        initial={editing}
        propertyId={propertyId}
        onSaved={onSaved}
      />
    </div>
  );
}