'use client';

import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import PropertyHeader from './PropertyHeader';
import PropertyFormModal from './PropertyFormModal';
import UnitsTab from './UnitsTab';
import AnalyticsTab from './AnalyticsTab';
import DocumentsTab from './DocumentsTab';
import MaintenanceTab from './MaintenanceTab';
import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

type PropertySummary = {
  id: string;
  name: string;
  address?: string | null;
  city?: string | null;
  description?: string | null;
  photoUrl?: string | null;
  totalUnits: number;
  occupiedUnits: number;
};

type Props = {
  properties: PropertySummary[];
};

type TabKey = 'overview' | 'units' | 'analytics' | 'documents' | 'maintenance';

export default function PropertyManagementInteractive({ properties }: Props) {
  const router = useRouter();

  const [query, setQuery] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(properties[0]?.id ?? null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<PropertySummary | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>('overview');

  const filtered = useMemo(() => {
    if (!query) return properties;
    const q = query.toLowerCase();
    return properties.filter((p) =>
      [p.name, p.city ?? '', p.address ?? ''].some((v) => v.toLowerCase().includes(q))
    );
  }, [properties, query]);

  const selected = useMemo(
    () => properties.find((p) => p.id === selectedId) ?? null,
    [properties, selectedId]
  );

  function openCreate() {
    setEditing(null);
    setModalOpen(true);
  }

  function openEdit(p: PropertySummary) {
    setEditing(p);
    setModalOpen(true);
  }

  async function onDelete(id: string) {
    if (!confirm('Delete this property? Units (if any) will also be removed.')) return;
    const res = await fetch(`/api/properties/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      alert(j?.error || 'Failed to delete property');
      return;
    }
    router.refresh();
  }

  function onSaved() {
    setModalOpen(false);
    setEditing(null);
    router.refresh();
  }

  return (
    <div className="space-y-6">
      <PropertyHeader
        query={query}
        onQueryChange={setQuery}
        onAdd={openCreate}
        count={filtered.length}
      />

      {/* Content layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Property list */}
        <div className="lg:col-span-5 space-y-4">
          {filtered.length === 0 && (
            <div className="bg-card border border-border rounded-lg p-6 text-center text-muted-foreground">
              No properties found.
            </div>
          )}

          {filtered.map((p) => (
            <div
              key={p.id}
              className={`bg-card border rounded-lg p-4 shadow-warm-sm transition-smooth ${
                p.id === selectedId ? 'border-primary' : 'border-border'
              }`}
            >
              <div className="flex gap-4">
                <div className="w-28 h-20 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  {p.photoUrl ? (
                    <AppImage
                      src={p.photoUrl}
                      alt={`${p.name}`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground text-xs">
                      No Image
                    </div>
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-semibold truncate">{p.name}</h3>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedId(p.id)}
                        className="p-2 hover:bg-muted rounded"
                        title="View"
                      >
                        <Icon name="EyeIcon" size={18} />
                      </button>
                      <button
                        onClick={() => openEdit(p)}
                        className="p-2 hover:bg-muted rounded"
                        title="Edit"
                      >
                        <Icon name="PencilSquareIcon" size={18} />
                      </button>
                      <button
                        onClick={() => onDelete(p.id)}
                        className="p-2 hover:bg-muted rounded text-error"
                        title="Delete"
                      >
                        <Icon name="TrashIcon" size={18} />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground">
                    {(p.address || 'Address N/A') + (p.city ? ` • ${p.city}` : '')}
                  </p>

                  <div className="mt-3 flex items-center gap-4 text-sm">
                    <span className="inline-flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-success" />
                      Occupied: {p.occupiedUnits}
                    </span>
                    <span className="inline-flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-muted-foreground" />
                      Total: {p.totalUnits}
                    </span>
                    <span className="ml-auto text-xs text-muted-foreground">
                      {p.totalUnits
                        ? Math.round((p.occupiedUnits / p.totalUnits) * 100)
                        : 0}
                      % occupancy
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Details */}
        <div className="lg:col-span-7">
          {!selected ? (
            <div className="bg-card border border-border rounded-lg p-8 text-center text-muted-foreground">
              Select a property to view its details.
            </div>
          ) : (
            <div className="bg-card border border-border rounded-lg">
              {/* Header */}
              <div className="p-6 border-b border-border flex items-center justify-between">
                <div className="min-w-0">
                  <h2 className="text-xl font-semibold truncate">{selected.name}</h2>
                  <p className="text-sm text-muted-foreground truncate">
                    {(selected.address || 'Address N/A') + (selected.city ? ` • ${selected.city}` : '')}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openEdit(selected)}
                    className="px-3 py-1.5 rounded bg-muted hover:bg-muted/80"
                  >
                    Edit
                  </button>
                </div>
              </div>

              {/* Tabs */}
              <div className="px-6 pt-4 flex items-center gap-4">
                {(['overview', 'units', 'analytics', 'documents', 'maintenance'] as TabKey[]).map(
                  (k) => (
                    <button
                      key={k}
                      onClick={() => setActiveTab(k)}
                      className={`text-sm pb-3 border-b-2 ${
                        activeTab === k ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground'
                      }`}
                    >
                      {k[0].toUpperCase() + k.slice(1)}
                    </button>
                  )
                )}
              </div>

              {/* Tab content */}
              <div className="p-6">
                {activeTab === 'overview' && (
                  <Overview selected={selected} />
                )}
                {activeTab === 'units' && (
                  <UnitsTab propertyId={selected.id} />
                )}
                {activeTab === 'analytics' && (
                  <AnalyticsTab
                    totalUnits={selected.totalUnits}
                    occupiedUnits={selected.occupiedUnits}
                  />
                )}
                {activeTab === 'documents' && (
                  <DocumentsTab propertyId={selected.id} />
                )}
                {activeTab === 'maintenance' && (
                  <MaintenanceTab propertyId={selected.id} />
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modal */}
      <PropertyFormModal
        open={modalOpen}
        onClose={() => { setModalOpen(false); setEditing(null); }}
        initial={editing ? {
          id: editing.id,
          name: editing.name,
          address: editing.address ?? '',
          city: editing.city ?? '',
          description: editing.description ?? '',
          photoUrl: editing.photoUrl ?? '',
        } : null}
        onSaved={onSaved}
      />
    </div>
  );
}

function Overview({ selected }: { selected: PropertySummary }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <div className="w-full h-64 bg-muted rounded-lg overflow-hidden">
          {selected.photoUrl ? (
            <AppImage
              src={selected.photoUrl}
              alt={selected.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-muted-foreground">
              No Image
            </div>
          )}
        </div>

        <div className="mt-4">
          <h3 className="text-lg font-semibold mb-2">Description</h3>
          <p className="text-sm text-muted-foreground whitespace-pre-wrap">
            {selected.description || 'No description.'}
          </p>
        </div>
      </div>

      <div className="lg:col-span-1">
        <div className="bg-popover border border-border rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Total units</span>
            <span className="text-sm font-semibold">{selected.totalUnits}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Occupied units</span>
            <span className="text-sm font-semibold">{selected.occupiedUnits}</span>
          </div>
          <div className="pt-3">
            <div className="h-2 rounded bg-muted overflow-hidden">
              <div
                className="h-2 bg-success"
                style={{
                  width: `${
                    selected.totalUnits
                      ? Math.round((selected.occupiedUnits / selected.totalUnits) * 100)
                      : 0
                  }%`,
                }}
              />
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              Occupancy rate
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}