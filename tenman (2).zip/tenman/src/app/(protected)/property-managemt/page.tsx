// src/app/(protected)/property-management/page.tsx
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { redirect } from "next/navigation";
import PropertyManagementInteractive from "./components/PropertyManagementInteractive";

export const dynamic = "force-dynamic";

export default async function PropertyManagementPage() {
  const me = await getCurrentUser();
  if (!me) redirect("/login");

  const props = await prisma.property.findMany({
    where: { organizationId: { in: me.membershipOrgIds } },
    include: {
      units: true,
    },
    orderBy: { createdAt: "desc" },
  });

  const mapped = props.map((p) => {
    const totalUnits = p.units.length;
    const occupiedUnits = p.units.filter((u) => u.status === "OCCUPIED").length;

    return {
      id: p.id,
      name: p.name,
      address: p.address,
      city: p.city,
      description: p.description,
      photoUrl: p.photoUrl,
      totalUnits,
      occupiedUnits,
    };
  });

  return (
    <div className="space-y-6 py-6">
      <PropertyManagementInteractive properties={mapped} />
    </div>
  );
}