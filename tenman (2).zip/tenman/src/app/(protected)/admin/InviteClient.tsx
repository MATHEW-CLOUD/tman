'use client';

import React, { useState } from 'react';

type Role = 'ADMIN' | 'MANAGER' | 'OWNER' | 'TENANT';

export default function InviteClient() {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<Role>('OWNER');
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    setLoading(true);
    try {
      const res = await fetch('/api/users/invite', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ email, role }),
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json?.error || 'Invite failed');
      setMsg({ type: 'ok', text: 'Invite sent. (Dev: link printed in server console)' });
      setEmail('');
      setRole('OWNER');
    } catch (e: any) {
      setMsg({ type: 'err', text: e?.message ?? 'Invite failed' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium">Email</label>
        <input
          type="email"
          className="mt-1 block w-full rounded-md border border-input bg-background px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ring"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="user@example.com"
          autoFocus
        />
      </div>

      <div>
        <label className="block text-sm font-medium">Role</label>
        <select
          className="mt-1 block w-full rounded-md border border-input bg-background px-3 py-2 focus:outline-none focus:ring-2 focus:ring-ring"
          value={role}
          onChange={(e) => setRole(e.target.value as Role)}
        >
          <option value="OWNER">Property Owner</option>
          <option value="TENANT">Tenant</option>
          <option value="MANAGER">Property Manager</option>
          <option value="ADMIN">Admin</option>
        </select>
      </div>

      {msg ? (
        <p className={`text-sm ${msg.type === 'ok' ? 'text-green-600' : 'text-red-600'}`}>
          {msg.text}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={loading || !email}
        className="rounded-md bg-primary px-4 py-2 text-white hover:opacity-90 disabled:opacity-60"
      >
        {loading ? 'Sending…' : 'Send invite'}
      </button>
    </form>
  );
}