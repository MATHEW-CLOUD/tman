import React from 'react';
import { getCurrentUser } from '@/lib/auth';
import InviteClient from './InviteClient';

export const dynamic = 'force-dynamic';

export default async function AdminPage() {
  const me = await getCurrentUser();
  // Server-side guard for UX (API still enforces)
  if (!me || (me.primaryRole !== 'ADMIN' && me.primaryRole !== 'MANAGER')) {
    return (
      <div className="max-w-3xl">
        <h1 className="text-xl font-semibold mb-2">Admin</h1>
        <p className="text-sm text-muted-foreground">
          You don’t have permission to view this page.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-3xl">
      <h1 className="text-xl font-semibold mb-6">Invite Users</h1>
      <p className="text-sm text-muted-foreground mb-6">
        Send an invite to add a user to your organization. They will set their password and be
        redirected based on their role.
      </p>
      <InviteClient />
    </div>
  );
}