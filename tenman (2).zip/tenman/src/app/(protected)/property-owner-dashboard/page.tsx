import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Breadcrumb from '@/components/common/Breadcrumb';
import MetricCard from './components/MetricCard';
import DashboardInteractive from './components/DashboardInteractive';

export const metadata: Metadata = {
  title: 'Property Owner Dashboard - TenantMaster',
  description: 'Comprehensive multi-property oversight with real-time performance metrics, financial analytics, and property portfolio monitoring for efficient property management in Kenya.',
};

interface Property {
  id: string;
  name: string;
  image: string;
  imageAlt: string;
  location: string;
  county: string;
  totalUnits: number;
  occupiedUnits: number;
  monthlyIncome: number;
  status: 'active' | 'maintenance' | 'vacant';
  type: string;
}

interface ChartData {
  month: string;
  income: number;
  expenses: number;
}

interface ExpenseData {
  name: string;
  value: number;
  color: string;
}

interface Activity {
  id: string;
  type: 'payment' | 'maintenance' | 'tenant' | 'document';
  title: string;
  description: string;
  timestamp: string;
  property: string;
}

export default function PropertyOwnerDashboard() {
  const mockProperties: Property[] = [
    {
      id: "prop-001",
      name: "Kilimani Heights",
      image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800",
      imageAlt: "Modern high-rise apartment building with glass facade and balconies in Kilimani, Nairobi",
      location: "Kilimani",
      county: "nairobi",
      totalUnits: 24,
      occupiedUnits: 22,
      monthlyIncome: 1680000,
      status: "active",
      type: "residential"
    },
    {
      id: "prop-002",
      name: "Westlands Plaza",
      image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800",
      imageAlt: "Contemporary commercial office building with modern architecture in Westlands business district",
      location: "Westlands",
      county: "nairobi",
      totalUnits: 12,
      occupiedUnits: 10,
      monthlyIncome: 2400000,
      status: "active",
      type: "commercial"
    },
    {
      id: "prop-003",
      name: "Karen Gardens",
      image: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800",
      imageAlt: "Luxury residential villa with landscaped gardens and swimming pool in Karen suburb",
      location: "Karen",
      county: "nairobi",
      totalUnits: 8,
      occupiedUnits: 7,
      monthlyIncome: 960000,
      status: "active",
      type: "residential"
    },
    {
      id: "prop-004",
      name: "Mombasa Trade Center",
      image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800",
      imageAlt: "Multi-story commercial building with retail shops on ground floor in Mombasa CBD",
      location: "Mombasa CBD",
      county: "mombasa",
      totalUnits: 16,
      occupiedUnits: 14,
      monthlyIncome: 1920000,
      status: "maintenance",
      type: "mixed"
    },
    {
      id: "prop-005",
      name: "Nakuru Residences",
      image: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800",
      imageAlt: "Row of modern townhouses with red tile roofs and white walls in Nakuru residential area",
      location: "Milimani",
      county: "nakuru",
      totalUnits: 20,
      occupiedUnits: 18,
      monthlyIncome: 1440000,
      status: "active",
      type: "residential"
    },
    {
      id: "prop-006",
      name: "Kisumu Lakeside Apartments",
      image: "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800",
      imageAlt: "Waterfront apartment complex with balconies overlooking Lake Victoria in Kisumu",
      location: "Milimani",
      county: "kisumu",
      totalUnits: 18,
      occupiedUnits: 15,
      monthlyIncome: 1350000,
      status: "active",
      type: "residential"
    }
  ];

  const mockIncomeData: ChartData[] = [
    { month: "Jul", income: 8750000, expenses: 2100000 },
    { month: "Aug", income: 9200000, expenses: 2350000 },
    { month: "Sep", income: 8900000, expenses: 2200000 },
    { month: "Oct", income: 9500000, expenses: 2400000 },
    { month: "Nov", income: 9800000, expenses: 2500000 },
    { month: "Dec", income: 10200000, expenses: 2650000 },
  ];

  const mockExpenseBreakdown: ExpenseData[] = [
    { name: "Maintenance", value: 850000, color: "#1B5E20" },
    { name: "Utilities", value: 620000, color: "#2E7D32" },
    { name: "Staff Salaries", value: 480000, color: "#388E3C" },
    { name: "Insurance", value: 350000, color: "#43A047" },
    { name: "Taxes", value: 250000, color: "#66BB6A" },
    { name: "Other", value: 100000, color: "#81C784" },
  ];

  const mockActivities: Activity[] = [
    {
      id: "act-001",
      type: "payment",
      title: "Rent Payment Received",
      description: "KES 70,000 from John Kamau - Unit 2B",
      timestamp: "2 hours ago",
      property: "Kilimani Heights"
    },
    {
      id: "act-002",
      type: "maintenance",
      title: "Maintenance Request",
      description: "Plumbing issue reported in Unit 5A",
      timestamp: "4 hours ago",
      property: "Westlands Plaza"
    },
    {
      id: "act-003",
      type: "tenant",
      title: "New Tenant Onboarded",
      description: "Sarah Wanjiku moved into Unit 3C",
      timestamp: "1 day ago",
      property: "Karen Gardens"
    },
    {
      id: "act-004",
      type: "document",
      title: "Lease Agreement Signed",
      description: "Digital signature completed for Unit 4D",
      timestamp: "2 days ago",
      property: "Nakuru Residences"
    },
    {
      id: "act-005",
      type: "payment",
      title: "Utility Bill Paid",
      description: "KES 15,000 electricity bill cleared",
      timestamp: "3 days ago",
      property: "Mombasa Trade Center"
    }
  ];

  const totalProperties = mockProperties.length;
  const totalUnits = mockProperties.reduce((sum, p) => sum + p.totalUnits, 0);
  const occupiedUnits = mockProperties.reduce((sum, p) => sum + p.occupiedUnits, 0);
  const occupancyRate = Math.round((occupiedUnits / totalUnits) * 100);
  const totalMonthlyRevenue = mockProperties.reduce((sum, p) => sum + p.monthlyIncome, 0);
  const pendingMaintenance = mockProperties.filter(p => p.status === 'maintenance').length;

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-16">
        <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Breadcrumb className="mb-6" />
          
          <div className="mb-8">
            <h1 className="text-3xl font-semibold text-foreground mb-2">Property Owner Dashboard</h1>
            <p className="text-muted-foreground">
              Welcome back! Here's an overview of your property portfolio performance.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <MetricCard
              title="Total Properties"
              value={totalProperties}
              icon="BuildingOfficeIcon"
              subtitle={`${totalUnits} total units`}
              trend={{ value: 12, isPositive: true }}
            />
            <MetricCard
              title="Occupancy Rate"
              value={`${occupancyRate}%`}
              icon="HomeIcon"
              subtitle={`${occupiedUnits}/${totalUnits} units occupied`}
              trend={{ value: 5, isPositive: true }}
              iconBgColor="bg-success/10"
              iconColor="text-success"
            />
            <MetricCard
              title="Monthly Revenue"
              value={`KES ${(totalMonthlyRevenue / 1000000).toFixed(1)}M`}
              icon="BanknotesIcon"
              subtitle="Total rental income"
              trend={{ value: 8, isPositive: true }}
              iconBgColor="bg-warning/10"
              iconColor="text-warning"
            />
            <MetricCard
              title="Pending Maintenance"
              value={pendingMaintenance}
              icon="WrenchScrewdriverIcon"
              subtitle="Requires attention"
              iconBgColor="bg-error/10"
              iconColor="text-error"
            />
          </div>

          <DashboardInteractive
            properties={mockProperties}
            incomeData={mockIncomeData}
            expenseBreakdown={mockExpenseBreakdown}
            activities={mockActivities}
          />
        </div>
      </main>
    </div>
  );
}