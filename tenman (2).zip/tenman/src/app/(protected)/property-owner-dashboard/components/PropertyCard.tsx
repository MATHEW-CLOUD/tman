import AppImage from '@/components/ui/AppImage';
import Icon from '@/components/ui/AppIcon';

interface PropertyCardProps {
  property: {
    id: string;
    name: string;
    image: string;
    imageAlt: string;
    location: string;
    county: string;
    totalUnits: number;
    occupiedUnits: number;
    monthlyIncome: number;
    status: 'active' | 'maintenance' | 'vacant';
  };
  onViewDetails: () => void;
  onAddUnit: () => void;
  onViewTenants: () => void;
}

export default function PropertyCard({ property, onViewDetails, onAddUnit, onViewTenants }: PropertyCardProps) {
  const occupancyRate = Math.round((property.occupiedUnits / property.totalUnits) * 100);
  const statusColors = {
    active: 'bg-success/10 text-success',
    maintenance: 'bg-warning/10 text-warning',
    vacant: 'bg-error/10 text-error',
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-hidden transition-smooth hover:shadow-warm-lg">
      <div className="relative h-48 overflow-hidden">
        <AppImage
          src={property.image}
          alt={property.imageAlt}
          className="w-full h-full object-cover transition-smooth hover:scale-105"
        />
        <div className="absolute top-3 right-3">
          <span className={`px-3 py-1 rounded-full text-xs font-semibold ${statusColors[property.status]} backdrop-blur-sm`}>
            {property.status.charAt(0).toUpperCase() + property.status.slice(1)}
          </span>
        </div>
      </div>
      
      <div className="p-5">
        <h3 className="text-xl font-semibold text-foreground mb-2">{property.name}</h3>
        <div className="flex items-center gap-2 text-muted-foreground mb-4">
          <Icon name="MapPinIcon" size={16} />
          <span className="text-sm caption">{property.location}, {property.county}</span>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4 pb-4 border-b border-border">
          <div>
            <p className="text-sm text-muted-foreground caption mb-1">Total Units</p>
            <p className="text-lg font-semibold text-foreground">{property.totalUnits}</p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground caption mb-1">Occupancy</p>
            <div className="flex items-center gap-2">
              <p className="text-lg font-semibold text-foreground">{occupancyRate}%</p>
              <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-smooth"
                  style={{ width: `${occupancyRate}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm text-muted-foreground caption mb-1">Monthly Income</p>
          <p className="text-2xl font-semibold text-primary">
            KES {property.monthlyIncome.toLocaleString('en-KE')}
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={onViewDetails}
            className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md font-medium text-sm transition-smooth hover:bg-primary/90 flex items-center justify-center gap-2"
          >
            <Icon name="EyeIcon" size={16} />
            View Details
          </button>
          <button
            onClick={onAddUnit}
            className="px-4 py-2 bg-muted text-foreground rounded-md font-medium text-sm transition-smooth hover:bg-muted/80"
            aria-label="Add unit"
          >
            <Icon name="PlusIcon" size={16} />
          </button>
          <button
            onClick={onViewTenants}
            className="px-4 py-2 bg-muted text-foreground rounded-md font-medium text-sm transition-smooth hover:bg-muted/80"
            aria-label="View tenants"
          >
            <Icon name="UsersIcon" size={16} />
          </button>
        </div>
      </div>
    </div>
  );
}