import Icon from '@/components/ui/AppIcon';

interface Activity {
  id: string;
  type: 'payment' | 'maintenance' | 'tenant' | 'document';
  title: string;
  description: string;
  timestamp: string;
  property: string;
}

interface RecentActivityProps {
  activities: Activity[];
}

export default function RecentActivity({ activities }: RecentActivityProps) {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'payment':
        return 'BanknotesIcon';
      case 'maintenance':
        return 'WrenchScrewdriverIcon';
      case 'tenant':
        return 'UserIcon';
      case 'document':
        return 'DocumentTextIcon';
      default:
        return 'BellIcon';
    }
  };

  const getActivityColor = (type: string) => {
    switch (type) {
      case 'payment':
        return 'bg-success/10 text-success';
      case 'maintenance':
        return 'bg-warning/10 text-warning';
      case 'tenant':
        return 'bg-primary/10 text-primary';
      case 'document':
        return 'bg-accent/10 text-accent';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md p-6 border border-border">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">Recent Activity</h2>
        <button className="text-sm text-primary font-medium hover:underline">
          View All
        </button>
      </div>

      <div className="space-y-4">
        {activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Icon name="ClockIcon" size={48} className="mx-auto mb-2 opacity-50" />
            <p>No recent activity</p>
          </div>
        ) : (
          activities.map(activity => (
            <div key={activity.id} className="flex gap-4 pb-4 border-b border-border last:border-0 last:pb-0">
              <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${getActivityColor(activity.type)}`}>
                <Icon name={getActivityIcon(activity.type) as any} size={20} />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-medium text-foreground mb-1">{activity.title}</h3>
                <p className="text-sm text-muted-foreground mb-1">{activity.description}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground caption">
                  <Icon name="BuildingOfficeIcon" size={14} />
                  <span>{activity.property}</span>
                  <span>•</span>
                  <span>{activity.timestamp}</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}