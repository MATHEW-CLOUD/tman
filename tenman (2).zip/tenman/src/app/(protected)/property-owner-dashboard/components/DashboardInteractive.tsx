'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import PropertyCard from './PropertyCard';
import FinancialChart from './FinancialChart';
import FilterControls, { FilterState } from './FilterControls';
import QuickActions from './QuickActions';
import RecentActivity from './RecentActivity';
import Icon from '@/components/ui/AppIcon';

interface Property {
  id: string;
  name: string;
  image: string;
  imageAlt: string;
  location: string;
  county: string;
  totalUnits: number;
  occupiedUnits: number;
  monthlyIncome: number;
  status: 'active' | 'maintenance' | 'vacant';
  type: string;
}

interface ChartData {
  month: string;
  income: number;
  expenses: number;
}

interface ExpenseData {
  name: string;
  value: number;
  color: string;
}

interface Activity {
  id: string;
  type: 'payment' | 'maintenance' | 'tenant' | 'document';
  title: string;
  description: string;
  timestamp: string;
  property: string;
}

interface DashboardInteractiveProps {
  properties: Property[];
  incomeData: ChartData[];
  expenseBreakdown: ExpenseData[];
  activities: Activity[];
}

export default function DashboardInteractive({
  properties: initialProperties,
  incomeData,
  expenseBreakdown,
  activities,
}: DashboardInteractiveProps) {
  const router = useRouter();
  const [isHydrated, setIsHydrated] = useState(false);
  const [filteredProperties, setFilteredProperties] = useState(initialProperties);
  const [showAddPropertyModal, setShowAddPropertyModal] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const propertyTypes = [
    { value: 'residential', label: 'Residential' },
    { value: 'commercial', label: 'Commercial' },
    { value: 'mixed', label: 'Mixed Use' },
  ];

  const counties = [
    { value: 'nairobi', label: 'Nairobi' },
    { value: 'mombasa', label: 'Mombasa' },
    { value: 'kisumu', label: 'Kisumu' },
    { value: 'nakuru', label: 'Nakuru' },
  ];

  const handleFilterChange = useCallback((filters: FilterState) => {
    if (!isHydrated) return;

    let filtered = initialProperties;

    if (filters.propertyType !== 'all') {
      filtered = filtered.filter(p => p.type === filters.propertyType);
    }

    if (filters.county !== 'all') {
      filtered = filtered.filter(p => p.county.toLowerCase() === filters.county);
    }

    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      filtered = filtered.filter(p =>
        p.name.toLowerCase().includes(query) ||
        p.location.toLowerCase().includes(query)
      );
    }

    setFilteredProperties(filtered);
  }, [initialProperties, isHydrated]);

  const handleViewDetails = (propertyId: string) => {
    router.push(`/property-management?id=${propertyId}`);
  };

  const handleAddUnit = (propertyId: string) => {
    router.push(`/property-management?id=${propertyId}&action=add-unit`);
  };

  const handleViewTenants = (propertyId: string) => {
    router.push(`/tenant-management?property=${propertyId}`);
  };

  const handleQuickAction = (actionId: string) => {
    switch (actionId) {
      case 'add-property':
        setShowAddPropertyModal(true);
        break;
      case 'add-tenant': router.push('/tenant-management?action=add');
        break;
      case 'record-payment': router.push('/payment-processing?action=record');
        break;
      case 'generate-report': router.push('/financial-reports?action=generate');
        break;
    }
  };

  if (!isHydrated) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-6">
          <div className="h-32 bg-muted rounded-lg" />
          <div className="h-64 bg-muted rounded-lg" />
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 h-96 bg-muted rounded-lg" />
            <div className="h-96 bg-muted rounded-lg" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6">
        <QuickActions onActionClick={handleQuickAction} />

        <FilterControls
          propertyTypes={propertyTypes}
          counties={counties}
          onFilterChange={handleFilterChange}
        />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-semibold text-foreground">
                Properties ({filteredProperties.length})
              </h2>
              <button
                onClick={() => setShowAddPropertyModal(true)}
                className="px-4 py-2 bg-primary text-primary-foreground rounded-md font-medium text-sm transition-smooth hover:bg-primary/90 flex items-center gap-2"
              >
                <Icon name="PlusIcon" size={16} />
                Add Property
              </button>
            </div>

            {filteredProperties.length === 0 ? (
              <div className="bg-card rounded-lg shadow-warm-md p-12 border border-border text-center">
                <Icon name="BuildingOfficeIcon" size={64} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-xl font-semibold text-foreground mb-2">No properties found</h3>
                <p className="text-muted-foreground mb-6">
                  Try adjusting your filters or add a new property to get started
                </p>
                <button
                  onClick={() => setShowAddPropertyModal(true)}
                  className="px-6 py-3 bg-primary text-primary-foreground rounded-md font-medium transition-smooth hover:bg-primary/90"
                >
                  Add Your First Property
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
                {filteredProperties.map(property => (
                  <PropertyCard
                    key={property.id}
                    property={property}
                    onViewDetails={() => handleViewDetails(property.id)}
                    onAddUnit={() => handleAddUnit(property.id)}
                    onViewTenants={() => handleViewTenants(property.id)}
                  />
                ))}
              </div>
            )}
          </div>

          <div className="space-y-6">
            <RecentActivity activities={activities} />
          </div>
        </div>

        <FinancialChart
          incomeData={incomeData}
          expenseBreakdown={expenseBreakdown}
        />
      </div>

      {showAddPropertyModal && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-black/50 animate-fade-in">
          <div className="bg-card rounded-lg shadow-warm-xl max-w-md w-full p-6 animate-slide-up">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold text-foreground">Add New Property</h3>
              <button
                onClick={() => setShowAddPropertyModal(false)}
                className="p-2 hover:bg-muted rounded-md transition-smooth"
              >
                <Icon name="XMarkIcon" size={20} />
              </button>
            </div>
            <p className="text-muted-foreground mb-6">
              You will be redirected to the property management page to add a new property with all required details.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowAddPropertyModal(false)}
                className="flex-1 px-4 py-2 bg-muted text-foreground rounded-md font-medium transition-smooth hover:bg-muted/80"
              >
                Cancel
              </button>
              <button
                onClick={() => router.push('/property-management?action=add')}
                className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-md font-medium transition-smooth hover:bg-primary/90"
              >
                Continue
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}