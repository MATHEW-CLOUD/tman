'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface QuickAction {
  id: string;
  label: string;
  icon: string;
  description: string;
  color: string;
}

interface QuickActionsProps {
  onActionClick: (actionId: string) => void;
}

export default function QuickActions({ onActionClick }: QuickActionsProps) {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const actions: QuickAction[] = [
    {
      id: 'add-property',
      label: 'Add Property',
      icon: 'PlusCircleIcon',
      description: 'Register new property',
      color: 'bg-primary/10 text-primary hover:bg-primary/20',
    },
    {
      id: 'add-tenant',
      label: 'Add Tenant',
      icon: 'UserPlusIcon',
      description: 'Onboard new tenant',
      color: 'bg-success/10 text-success hover:bg-success/20',
    },
    {
      id: 'record-payment',
      label: 'Record Payment',
      icon: 'BanknotesIcon',
      description: 'Log manual payment',
      color: 'bg-warning/10 text-warning hover:bg-warning/20',
    },
    {
      id: 'generate-report',
      label: 'Generate Report',
      icon: 'DocumentChartBarIcon',
      description: 'Create financial report',
      color: 'bg-accent/10 text-accent hover:bg-accent/20',
    },
  ];

  if (!isHydrated) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="bg-card rounded-lg shadow-warm-md p-4 border border-border animate-pulse">
            <div className="h-20 bg-muted rounded-md" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {actions.map(action => (
        <button
          key={action.id}
          onClick={() => onActionClick(action.id)}
          className={`bg-card rounded-lg shadow-warm-md p-4 border border-border transition-smooth hover:shadow-warm-lg text-left ${action.color}`}
        >
          <div className="flex items-start gap-3">
            <Icon name={action.icon as any} size={24} />
            <div>
              <h3 className="font-semibold text-base mb-1">{action.label}</h3>
              <p className="text-sm opacity-80 caption">{action.description}</p>
            </div>
          </div>
        </button>
      ))}
    </div>
  );
}