'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface FilterOption {
  value: string;
  label: string;
}

interface FilterControlsProps {
  propertyTypes: FilterOption[];
  counties: FilterOption[];
  onFilterChange: (filters: FilterState) => void;
}

export interface FilterState {
  propertyType: string;
  county: string;
  searchQuery: string;
}

export default function FilterControls({ propertyTypes, counties, onFilterChange }: FilterControlsProps) {
  const [isHydrated, setIsHydrated] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    propertyType: 'all',
    county: 'all',
    searchQuery: '',
  });

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  useEffect(() => {
    if (isHydrated) {
      onFilterChange(filters);
    }
  }, [filters, isHydrated, onFilterChange]);

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-lg shadow-warm-md p-4 border border-border">
        <div className="animate-pulse h-10 bg-muted rounded-md" />
      </div>
    );
  }

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilters(prev => ({ ...prev, searchQuery: e.target.value }));
  };

  const handlePropertyTypeChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, propertyType: e.target.value }));
  };

  const handleCountyChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setFilters(prev => ({ ...prev, county: e.target.value }));
  };

  const handleReset = () => {
    setFilters({
      propertyType: 'all',
      county: 'all',
      searchQuery: '',
    });
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md p-4 border border-border">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="relative">
          <Icon 
            name="MagnifyingGlassIcon" 
            size={20} 
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <input
            type="text"
            placeholder="Search properties..."
            value={filters.searchQuery}
            onChange={handleSearchChange}
            className="w-full pl-10 pr-4 py-2 bg-background border border-input rounded-md text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-smooth"
          />
        </div>

        <select
          value={filters.propertyType}
          onChange={handlePropertyTypeChange}
          className="w-full px-4 py-2 bg-background border border-input rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-smooth"
        >
          <option value="all">All Property Types</option>
          {propertyTypes.map(type => (
            <option key={type.value} value={type.value}>{type.label}</option>
          ))}
        </select>

        <select
          value={filters.county}
          onChange={handleCountyChange}
          className="w-full px-4 py-2 bg-background border border-input rounded-md text-foreground focus:outline-none focus:ring-2 focus:ring-ring transition-smooth"
        >
          <option value="all">All Counties</option>
          {counties.map(county => (
            <option key={county.value} value={county.value}>{county.label}</option>
          ))}
        </select>

        <button
          onClick={handleReset}
          className="px-4 py-2 bg-muted text-foreground rounded-md font-medium text-sm transition-smooth hover:bg-muted/80 flex items-center justify-center gap-2"
        >
          <Icon name="ArrowPathIcon" size={16} />
          Reset Filters
        </button>
      </div>
    </div>
  );
}