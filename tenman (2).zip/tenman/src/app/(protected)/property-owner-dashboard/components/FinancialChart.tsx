'use client';

import { useState, useEffect } from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Icon from '@/components/ui/AppIcon';

interface ChartData {
  month: string;
  income: number;
  expenses: number;
}

interface ExpenseData {
  name: string;
  value: number;
  color: string;
}

interface FinancialChartProps {
  incomeData: ChartData[];
  expenseBreakdown: ExpenseData[];
}

export default function FinancialChart({ incomeData, expenseBreakdown }: FinancialChartProps) {
  const [isHydrated, setIsHydrated] = useState(false);
  const [activeChart, setActiveChart] = useState<'income' | 'expenses' | 'breakdown'>('income');

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  if (!isHydrated) {
    return (
      <div className="bg-card rounded-lg shadow-warm-md p-6 border border-border">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-foreground">Financial Analytics</h2>
        </div>
        <div className="h-80 flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">Loading charts...</div>
        </div>
      </div>
    );
  }

  const chartButtons = [
    { id: 'income' as const, label: 'Income Trends', icon: 'ChartBarIcon' },
    { id: 'expenses' as const, label: 'Expense Analysis', icon: 'ArrowTrendingDownIcon' },
    { id: 'breakdown' as const, label: 'Expense Breakdown', icon: 'ChartPieIcon' },
  ];

  return (
    <div className="bg-card rounded-lg shadow-warm-md p-6 border border-border">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <h2 className="text-xl font-semibold text-foreground">Financial Analytics</h2>
        <div className="flex gap-2 flex-wrap">
          {chartButtons.map((button) => (
            <button
              key={button.id}
              onClick={() => setActiveChart(button.id)}
              className={`px-4 py-2 rounded-md font-medium text-sm transition-smooth flex items-center gap-2 ${
                activeChart === button.id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              <Icon name={button.icon as any} size={16} />
              <span className="hidden sm:inline">{button.label}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="h-80">
        {activeChart === 'income' && (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={incomeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
              <XAxis 
                dataKey="month" 
                stroke="#666"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="#666"
                style={{ fontSize: '12px' }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-popover)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px',
                  fontSize: '14px'
                }}
                formatter={(value: number) => [`KES ${value.toLocaleString('en-KE')}`, '']}
              />
              <Legend 
                wrapperStyle={{ fontSize: '14px' }}
              />
              <Line 
                type="monotone" 
                dataKey="income" 
                stroke="#1B5E20" 
                strokeWidth={3}
                name="Monthly Income"
                dot={{ fill: '#1B5E20', r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}

        {activeChart === 'expenses' && (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={incomeData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.1)" />
              <XAxis 
                dataKey="month" 
                stroke="#666"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="#666"
                style={{ fontSize: '12px' }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}K`}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-popover)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px',
                  fontSize: '14px'
                }}
                formatter={(value: number) => [`KES ${value.toLocaleString('en-KE')}`, '']}
              />
              <Legend 
                wrapperStyle={{ fontSize: '14px' }}
              />
              <Bar 
                dataKey="income" 
                fill="#1B5E20" 
                name="Income"
                radius={[8, 8, 0, 0]}
              />
              <Bar 
                dataKey="expenses" 
                fill="#C62828" 
                name="Expenses"
                radius={[8, 8, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        )}

        {activeChart === 'breakdown' && (
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={expenseBreakdown}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {expenseBreakdown.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'var(--color-popover)', 
                  border: '1px solid var(--color-border)',
                  borderRadius: '8px',
                  fontSize: '14px'
                }}
                formatter={(value: number) => [`KES ${value.toLocaleString('en-KE')}`, '']}
              />
            </PieChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}