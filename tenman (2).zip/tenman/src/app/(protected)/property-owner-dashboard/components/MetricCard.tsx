import Icon from '@/components/ui/AppIcon';

interface MetricCardProps {
  title: string;
  value: string | number;
  icon: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  subtitle?: string;
  iconBgColor?: string;
  iconColor?: string;
}

export default function MetricCard({
  title,
  value,
  icon,
  trend,
  subtitle,
  iconBgColor = 'bg-primary/10',
  iconColor = 'text-primary',
}: MetricCardProps) {
  return (
    <div className="bg-card rounded-lg shadow-warm-md p-6 border border-border transition-smooth hover:shadow-warm-lg">
      <div className="flex items-start justify-between mb-4">
        <div className={`w-12 h-12 ${iconBgColor} rounded-lg flex items-center justify-center`}>
          <Icon name={icon as any} size={24} className={iconColor} />
        </div>
        {trend && (
          <div className={`flex items-center gap-1 px-2 py-1 rounded-md ${trend.isPositive ? 'bg-success/10 text-success' : 'bg-error/10 text-error'}`}>
            <Icon 
              name={trend.isPositive ? 'ArrowTrendingUpIcon' : 'ArrowTrendingDownIcon'} 
              size={16} 
            />
            <span className="text-sm font-semibold">{Math.abs(trend.value)}%</span>
          </div>
        )}
      </div>
      <h3 className="text-sm font-medium text-muted-foreground mb-1 caption">{title}</h3>
      <p className="text-3xl font-semibold text-foreground mb-1">{value}</p>
      {subtitle && (
        <p className="text-sm text-muted-foreground caption">{subtitle}</p>
      )}
    </div>
  );
}