'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface MaintenanceFormData {
  title: string;
  description: string;
  category: string;
  priority: string;
  location: string;
  photos: File[];
}

interface MaintenanceRequestFormProps {
  onSubmit: (data: MaintenanceFormData) => void;
}

const MaintenanceRequestForm = ({ onSubmit }: MaintenanceRequestFormProps) => {
  const [formData, setFormData] = useState<MaintenanceFormData>({
    title: '',
    description: '',
    category: '',
    priority: 'medium',
    location: '',
    photos: []
  });

  const categories = [
    { value: 'plumbing', label: 'Plumbing', icon: 'WrenchScrewdriverIcon' },
    { value: 'electrical', label: 'Electrical', icon: 'BoltIcon' },
    { value: 'hvac', label: 'HVAC', icon: 'FireIcon' },
    { value: 'appliance', label: 'Appliance', icon: 'CpuChipIcon' },
    { value: 'structural', label: 'Structural', icon: 'HomeIcon' },
    { value: 'other', label: 'Other', icon: 'EllipsisHorizontalCircleIcon' }
  ];

  const priorities = [
    { value: 'low', label: 'Low', color: 'text-success' },
    { value: 'medium', label: 'Medium', color: 'text-warning' },
    { value: 'high', label: 'High', color: 'text-error' }
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFormData({ ...formData, photos: Array.from(e.target.files) });
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <h3 className="text-xl font-semibold">Submit Maintenance Request</h3>
        <p className="text-sm text-muted-foreground mt-1">Report any issues that need attention</p>
      </div>

      <form onSubmit={handleSubmit} className="p-6 space-y-6">
        <div>
          <label className="block text-sm font-medium mb-2">Request Title *</label>
          <input
            type="text"
            required
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="Brief description of the issue"
            className="w-full px-4 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Category *</label>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {categories.map((cat) => (
              <button
                key={cat.value}
                type="button"
                onClick={() => setFormData({ ...formData, category: cat.value })}
                className={`flex items-center gap-2 px-4 py-3 rounded-lg border-2 transition-smooth ${
                  formData.category === cat.value
                    ? 'border-primary bg-primary/5 text-primary' :'border-border hover:border-primary/30'
                }`}
              >
                <Icon name={cat.icon as any} size={20} />
                <span className="text-sm font-medium">{cat.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Priority *</label>
          <div className="flex gap-3">
            {priorities.map((priority) => (
              <button
                key={priority.value}
                type="button"
                onClick={() => setFormData({ ...formData, priority: priority.value })}
                className={`flex-1 px-4 py-2 rounded-lg border-2 transition-smooth ${
                  formData.priority === priority.value
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/30'
                }`}
              >
                <span className={`text-sm font-medium ${formData.priority === priority.value ? 'text-primary' : priority.color}`}>
                  {priority.label}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Location *</label>
          <input
            type="text"
            required
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            placeholder="e.g., Kitchen, Bedroom 1, Bathroom"
            className="w-full px-4 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Description *</label>
          <textarea
            required
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Provide detailed information about the issue"
            rows={4}
            className="w-full px-4 py-2 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring resize-none"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Photos (Optional)</label>
          <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary/30 transition-smooth">
            <input
              type="file"
              multiple
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
              id="photo-upload"
            />
            <label htmlFor="photo-upload" className="cursor-pointer">
              <Icon name="PhotoIcon" size={48} className="mx-auto mb-2 text-muted-foreground" />
              <p className="text-sm font-medium mb-1">Click to upload photos</p>
              <p className="text-xs text-muted-foreground caption">PNG, JPG up to 10MB each</p>
            </label>
            {formData.photos.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-2 justify-center">
                {formData.photos.map((photo, index) => (
                  <span key={index} className="px-3 py-1 bg-primary/10 text-primary rounded-full text-xs caption">
                    {photo.name}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        <button
          type="submit"
          className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth font-medium"
        >
          <Icon name="PaperAirplaneIcon" size={20} />
          <span>Submit Request</span>
        </button>
      </form>
    </div>
  );
};

export default MaintenanceRequestForm;