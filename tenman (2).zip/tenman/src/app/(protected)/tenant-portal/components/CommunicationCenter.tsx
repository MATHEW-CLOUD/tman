import Icon from '@/components/ui/AppIcon';

interface Announcement {
  id: string;
  title: string;
  message: string;
  date: string;
  type: 'general' | 'maintenance' | 'emergency' | 'event';
  priority: 'low' | 'medium' | 'high';
}

interface CommunicationCenterProps {
  announcements: Announcement[];
  onSendMessage: () => void;
}

const CommunicationCenter = ({ announcements, onSendMessage }: CommunicationCenterProps) => {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'general':
        return 'MegaphoneIcon';
      case 'maintenance':
        return 'WrenchScrewdriverIcon';
      case 'emergency':
        return 'ExclamationTriangleIcon';
      case 'event':
        return 'CalendarDaysIcon';
      default:
        return 'BellIcon';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'general':
        return 'bg-primary/10 text-primary';
      case 'maintenance':
        return 'bg-warning/10 text-warning';
      case 'emergency':
        return 'bg-error/10 text-error';
      case 'event':
        return 'bg-success/10 text-success';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-error/10 text-error';
      case 'medium':
        return 'bg-warning/10 text-warning';
      case 'low':
        return 'bg-success/10 text-success';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-hidden">
      <div className="p-6 border-b border-border flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold">Communication Center</h3>
          <p className="text-sm text-muted-foreground mt-1">Property announcements and messages</p>
        </div>
        <button
          onClick={onSendMessage}
          className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth"
        >
          <Icon name="ChatBubbleLeftRightIcon" size={20} />
          <span className="text-sm font-medium hidden sm:inline">Message Management</span>
        </button>
      </div>

      <div className="divide-y divide-border max-h-96 overflow-y-auto">
        {announcements.length === 0 ? (
          <div className="p-12 text-center">
            <Icon name="MegaphoneIcon" size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground">No announcements at this time</p>
          </div>
        ) : (
          announcements.map((announcement) => (
            <div key={announcement.id} className="p-6 hover:bg-muted/30 transition-smooth">
              <div className="flex items-start gap-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0 ${getTypeColor(announcement.type)}`}>
                  <Icon name={getTypeIcon(announcement.type) as any} size={24} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <h4 className="font-semibold">{announcement.title}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium caption whitespace-nowrap ${getPriorityBadge(announcement.priority)}`}>
                      {announcement.priority.charAt(0).toUpperCase() + announcement.priority.slice(1)}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{announcement.message}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground caption">
                    <Icon name="ClockIcon" size={14} />
                    <span>{new Date(announcement.date).toLocaleDateString('en-GB')} at {new Date(announcement.date).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default CommunicationCenter;