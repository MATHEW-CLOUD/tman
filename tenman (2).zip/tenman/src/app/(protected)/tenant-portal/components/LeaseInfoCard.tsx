import Icon from '@/components/ui/AppIcon';

interface LeaseInfo {
  unitNumber: string;
  propertyName: string;
  propertyAddress: string;
  rentAmount: number;
  leaseStartDate: string;
  leaseEndDate: string;
  daysUntilExpiry: number;
  securityDeposit: number;
  status: 'active' | 'expiring-soon' | 'expired';
}

interface LeaseInfoCardProps {
  leaseInfo: LeaseInfo;
}

const LeaseInfoCard = ({ leaseInfo }: LeaseInfoCardProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-success/10 text-success';
      case 'expiring-soon':
        return 'bg-warning/10 text-warning';
      case 'expired':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active Lease';
      case 'expiring-soon':
        return 'Expiring Soon';
      case 'expired':
        return 'Expired';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-2xl font-semibold mb-1">Unit {leaseInfo.unitNumber}</h2>
          <p className="text-muted-foreground">{leaseInfo.propertyName}</p>
          <p className="text-sm text-muted-foreground caption">{leaseInfo.propertyAddress}</p>
        </div>
        <span className={`px-3 py-1 rounded-full text-sm font-medium caption ${getStatusColor(leaseInfo.status)}`}>
          {getStatusText(leaseInfo.status)}
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Icon name="CurrencyDollarIcon" size={20} className="text-primary" />
            <span className="text-sm text-muted-foreground caption">Monthly Rent</span>
          </div>
          <p className="text-xl font-semibold data-text">
            KES {leaseInfo.rentAmount.toLocaleString('en-KE')}
          </p>
        </div>

        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Icon name="CalendarIcon" size={20} className="text-primary" />
            <span className="text-sm text-muted-foreground caption">Lease Period</span>
          </div>
          <p className="text-sm font-medium">
            {new Date(leaseInfo.leaseStartDate).toLocaleDateString('en-GB')} - {new Date(leaseInfo.leaseEndDate).toLocaleDateString('en-GB')}
          </p>
        </div>

        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Icon name="ClockIcon" size={20} className="text-primary" />
            <span className="text-sm text-muted-foreground caption">Days Until Expiry</span>
          </div>
          <p className="text-xl font-semibold data-text">
            {leaseInfo.daysUntilExpiry} days
          </p>
        </div>

        <div className="bg-muted/50 rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <Icon name="ShieldCheckIcon" size={20} className="text-primary" />
            <span className="text-sm text-muted-foreground caption">Security Deposit</span>
          </div>
          <p className="text-xl font-semibold data-text">
            KES {leaseInfo.securityDeposit.toLocaleString('en-KE')}
          </p>
        </div>
      </div>

      {leaseInfo.status === 'expiring-soon' && (
        <div className="mt-4 bg-warning/10 border border-warning/20 rounded-lg p-4 flex items-start gap-3">
          <Icon name="ExclamationTriangleIcon" size={24} className="text-warning flex-shrink-0" />
          <div>
            <p className="font-medium text-warning mb-1">Lease Renewal Required</p>
            <p className="text-sm text-muted-foreground">
              Your lease is expiring in {leaseInfo.daysUntilExpiry} days. Please contact property management to discuss renewal options.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeaseInfoCard;