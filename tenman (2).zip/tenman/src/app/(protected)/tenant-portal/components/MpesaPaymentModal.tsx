'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface MpesaPaymentModalProps {
  isOpen: boolean;
  amount: number;
  description: string;
  onClose: () => void;
  onConfirm: (phoneNumber: string) => void;
}

const MpesaPaymentModal = ({ isOpen, amount, description, onClose, onConfirm }: MpesaPaymentModalProps) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    onConfirm(phoneNumber);
  };

  const formatPhoneNumber = (value: string) => {
    const cleaned = value.replace(/\D/g, '');
    if (cleaned.startsWith('254')) {
      return cleaned.slice(0, 12);
    }
    if (cleaned.startsWith('0')) {
      return '254' + cleaned.slice(1, 10);
    }
    return '254' + cleaned.slice(0, 9);
  };

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-black/50 animate-fade-in">
      <div className="bg-card rounded-lg shadow-warm-xl border border-border w-full max-w-md animate-slide-up">
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-success/10 rounded-lg flex items-center justify-center">
              <Icon name="DevicePhoneMobileIcon" size={24} className="text-success" />
            </div>
            <div>
              <h3 className="text-xl font-semibold">M-Pesa Payment</h3>
              <p className="text-sm text-muted-foreground caption">STK Push Payment</p>
            </div>
          </div>
          <button
            onClick={onClose}
            disabled={isProcessing}
            className="p-2 hover:bg-muted rounded-md transition-smooth disabled:opacity-50"
          >
            <Icon name="XMarkIcon" size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-muted-foreground">Payment For:</span>
              <span className="text-sm font-medium">{description}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-muted-foreground">Amount:</span>
              <span className="text-2xl font-bold text-primary data-text">KES {amount.toLocaleString('en-KE')}</span>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">M-Pesa Phone Number *</label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-2 text-muted-foreground">
                <Icon name="DevicePhoneMobileIcon" size={20} />
                <span className="text-sm caption">+254</span>
              </div>
              <input
                type="tel"
                required
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(formatPhoneNumber(e.target.value))}
                placeholder="712345678"
                className="w-full pl-24 pr-4 py-3 bg-background border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring data-text"
                disabled={isProcessing}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2 caption">
              Enter your M-Pesa registered phone number
            </p>
          </div>

          <div className="bg-warning/10 border border-warning/20 rounded-lg p-4 flex items-start gap-3">
            <Icon name="InformationCircleIcon" size={20} className="text-warning flex-shrink-0 mt-0.5" />
            <div className="text-sm text-muted-foreground">
              <p className="font-medium text-warning mb-1">Payment Instructions:</p>
              <ol className="list-decimal list-inside space-y-1 caption">
                <li>You will receive an M-Pesa prompt on your phone</li>
                <li>Enter your M-Pesa PIN to complete payment</li>
                <li>Wait for confirmation message</li>
              </ol>
            </div>
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isProcessing}
              className="flex-1 px-6 py-3 border border-border rounded-md hover:bg-muted transition-smooth font-medium disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isProcessing || phoneNumber.length < 12}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-success text-white rounded-md hover:bg-success/90 transition-smooth font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Icon name="ArrowPathIcon" size={20} className="animate-spin" />
                  <span>Processing...</span>
                </>
              ) : (
                <>
                  <Icon name="CheckCircleIcon" size={20} />
                  <span>Initiate Payment</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default MpesaPaymentModal;