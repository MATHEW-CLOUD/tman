import Icon from '@/components/ui/AppIcon';

interface LeaseDocument {
  id: string;
  name: string;
  type: 'lease-agreement' | 'addendum' | 'property-rules' | 'inspection-report';
  uploadDate: string;
  size: string;
  status: 'signed' | 'pending-signature' | 'expired';
}

interface LeaseDocumentsSectionProps {
  documents: LeaseDocument[];
  onViewDocument: (documentId: string) => void;
  onSignDocument: (documentId: string) => void;
}

const LeaseDocumentsSection = ({ documents, onViewDocument, onSignDocument }: LeaseDocumentsSectionProps) => {
  const getDocumentIcon = (type: string) => {
    switch (type) {
      case 'lease-agreement':
        return 'DocumentTextIcon';
      case 'addendum':
        return 'DocumentPlusIcon';
      case 'property-rules':
        return 'ClipboardDocumentListIcon';
      case 'inspection-report':
        return 'ClipboardDocumentCheckIcon';
      default:
        return 'DocumentIcon';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'signed':
        return 'bg-success/10 text-success';
      case 'pending-signature':
        return 'bg-warning/10 text-warning';
      case 'expired':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'signed':
        return 'Signed';
      case 'pending-signature':
        return 'Pending Signature';
      case 'expired':
        return 'Expired';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <h3 className="text-xl font-semibold">Lease Documents</h3>
        <p className="text-sm text-muted-foreground mt-1">Access your lease agreements and property documents</p>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {documents.map((doc) => (
            <div key={doc.id} className="bg-muted/30 rounded-lg p-4 border border-border hover:border-primary/30 transition-smooth">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name={getDocumentIcon(doc.type) as any} size={20} className="text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-medium mb-1 truncate">{doc.name}</h4>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground caption">
                    <span>{doc.size}</span>
                    <span>•</span>
                    <span>{new Date(doc.uploadDate).toLocaleDateString('en-GB')}</span>
                  </div>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium caption whitespace-nowrap ${getStatusColor(doc.status)}`}>
                  {getStatusText(doc.status)}
                </span>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => onViewDocument(doc.id)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-primary/10 text-primary rounded-md hover:bg-primary/20 transition-smooth"
                >
                  <Icon name="EyeIcon" size={18} />
                  <span className="text-sm font-medium">View</span>
                </button>
                {doc.status === 'pending-signature' && (
                  <button
                    onClick={() => onSignDocument(doc.id)}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth"
                  >
                    <Icon name="PencilSquareIcon" size={18} />
                    <span className="text-sm font-medium">Sign</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default LeaseDocumentsSection;