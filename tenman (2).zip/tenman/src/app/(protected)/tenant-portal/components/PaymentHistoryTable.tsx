import Icon from '@/components/ui/AppIcon';

interface Payment {
  id: string;
  date: string;
  amount: number;
  method: string;
  status: 'paid' | 'pending' | 'overdue';
  receiptNumber: string;
  description: string;
}

interface PaymentHistoryTableProps {
  payments: Payment[];
  onDownloadReceipt: (receiptNumber: string) => void;
}

const PaymentHistoryTable = ({ payments, onDownloadReceipt }: PaymentHistoryTableProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-success/10 text-success';
      case 'pending':
        return 'bg-warning/10 text-warning';
      case 'overdue':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid':
        return 'Paid';
      case 'pending':
        return 'Pending';
      case 'overdue':
        return 'Overdue';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <h3 className="text-xl font-semibold">Payment History</h3>
        <p className="text-sm text-muted-foreground mt-1">View and download your payment receipts</p>
      </div>

      {/* Desktop Table */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Date</th>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Description</th>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Amount</th>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Method</th>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Status</th>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Receipt</th>
              <th className="px-6 py-3 text-left text-sm font-medium text-muted-foreground caption">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {payments.map((payment) => (
              <tr key={payment.id} className="hover:bg-muted/30 transition-smooth">
                <td className="px-6 py-4 text-sm">
                  {new Date(payment.date).toLocaleDateString('en-GB')}
                </td>
                <td className="px-6 py-4 text-sm">{payment.description}</td>
                <td className="px-6 py-4 text-sm font-medium data-text">
                  KES {payment.amount.toLocaleString('en-KE')}
                </td>
                <td className="px-6 py-4 text-sm">{payment.method}</td>
                <td className="px-6 py-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium caption ${getStatusColor(payment.status)}`}>
                    {getStatusText(payment.status)}
                  </span>
                </td>
                <td className="px-6 py-4 text-sm caption">{payment.receiptNumber}</td>
                <td className="px-6 py-4">
                  {payment.status === 'paid' && (
                    <button
                      onClick={() => onDownloadReceipt(payment.receiptNumber)}
                      className="flex items-center gap-2 text-primary hover:text-primary/80 transition-smooth"
                    >
                      <Icon name="ArrowDownTrayIcon" size={18} />
                      <span className="text-sm font-medium">Download</span>
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden divide-y divide-border">
        {payments.map((payment) => (
          <div key={payment.id} className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="font-medium mb-1">{payment.description}</p>
                <p className="text-sm text-muted-foreground caption">
                  {new Date(payment.date).toLocaleDateString('en-GB')}
                </p>
              </div>
              <span className={`px-2 py-1 rounded-full text-xs font-medium caption ${getStatusColor(payment.status)}`}>
                {getStatusText(payment.status)}
              </span>
            </div>
            <div className="space-y-2 mb-3">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Amount:</span>
                <span className="font-medium data-text">KES {payment.amount.toLocaleString('en-KE')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Method:</span>
                <span>{payment.method}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Receipt:</span>
                <span className="caption">{payment.receiptNumber}</span>
              </div>
            </div>
            {payment.status === 'paid' && (
              <button
                onClick={() => onDownloadReceipt(payment.receiptNumber)}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth"
              >
                <Icon name="ArrowDownTrayIcon" size={18} />
                <span className="text-sm font-medium">Download Receipt</span>
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default PaymentHistoryTable;