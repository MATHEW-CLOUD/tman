'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface OutstandingBalance {
  amount: number;
  dueDate: string;
  description: string;
  lateFee: number;
}

interface OutstandingBalanceCardProps {
  balance: OutstandingBalance;
  onPayNow: () => void;
}

const OutstandingBalanceCard = ({ balance, onPayNow }: OutstandingBalanceCardProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useState(() => {
    setIsHydrated(true);
  });

  const dueDate = new Date(balance.dueDate);
  const today = new Date();
  const daysUntilDue = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
  const isOverdue = daysUntilDue < 0;
  const totalAmount = balance.amount + balance.lateFee;

  return (
    <div className={`bg-card rounded-lg shadow-warm-md border-2 p-6 ${isOverdue ? 'border-error' : 'border-warning'}`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isOverdue ? 'bg-error/10' : 'bg-warning/10'}`}>
            <Icon name="ExclamationTriangleIcon" size={24} className={isOverdue ? 'text-error' : 'text-warning'} />
          </div>
          <div>
            <h3 className="text-lg font-semibold">Outstanding Balance</h3>
            <p className="text-sm text-muted-foreground">{balance.description}</p>
          </div>
        </div>
      </div>

      <div className="space-y-3 mb-6">
        <div className="flex justify-between items-center">
          <span className="text-muted-foreground">Rent Amount:</span>
          <span className="text-lg font-semibold data-text">KES {balance.amount.toLocaleString('en-KE')}</span>
        </div>
        {balance.lateFee > 0 && (
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Late Fee:</span>
            <span className="text-lg font-semibold text-error data-text">KES {balance.lateFee.toLocaleString('en-KE')}</span>
          </div>
        )}
        <div className="pt-3 border-t border-border flex justify-between items-center">
          <span className="font-medium">Total Due:</span>
          <span className="text-2xl font-bold text-primary data-text">KES {totalAmount.toLocaleString('en-KE')}</span>
        </div>
        <div className="flex justify-between items-center text-sm">
          <span className="text-muted-foreground">Due Date:</span>
          <span className={`font-medium ${isOverdue ? 'text-error' : 'text-warning'}`}>
            {isHydrated ? dueDate.toLocaleDateString('en-GB') : 'Loading...'}
            {isOverdue ? ` (${Math.abs(daysUntilDue)} days overdue)` : ` (${daysUntilDue} days remaining)`}
          </span>
        </div>
      </div>

      <button
        onClick={onPayNow}
        className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth font-medium"
      >
        <Icon name="CreditCardIcon" size={20} />
        <span>Pay Now via M-Pesa</span>
      </button>

      {isOverdue && (
        <div className="mt-4 bg-error/10 border border-error/20 rounded-lg p-3 flex items-start gap-2">
          <Icon name="ExclamationCircleIcon" size={20} className="text-error flex-shrink-0 mt-0.5" />
          <p className="text-sm text-error">
            Your payment is overdue. Please settle this balance immediately to avoid additional penalties.
          </p>
        </div>
      )}
    </div>
  );
};

export default OutstandingBalanceCard;