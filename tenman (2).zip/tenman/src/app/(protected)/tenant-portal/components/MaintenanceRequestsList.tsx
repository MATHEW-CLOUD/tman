import Icon from '@/components/ui/AppIcon';

interface MaintenanceRequest {
  id: string;
  title: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  submittedDate: string;
  assignedTo?: string;
  estimatedCompletion?: string;
}

interface MaintenanceRequestsListProps {
  requests: MaintenanceRequest[];
  onViewDetails: (requestId: string) => void;
}

const MaintenanceRequestsList = ({ requests, onViewDetails }: MaintenanceRequestsListProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-success/10 text-success';
      case 'in-progress':
        return 'bg-warning/10 text-warning';
      case 'pending':
        return 'bg-muted text-muted-foreground';
      case 'cancelled':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-error';
      case 'medium':
        return 'text-warning';
      case 'low':
        return 'text-success';
      default:
        return 'text-muted-foreground';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'plumbing':
        return 'WrenchScrewdriverIcon';
      case 'electrical':
        return 'BoltIcon';
      case 'hvac':
        return 'FireIcon';
      case 'appliance':
        return 'CpuChipIcon';
      case 'structural':
        return 'HomeIcon';
      default:
        return 'EllipsisHorizontalCircleIcon';
    }
  };

  return (
    <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <h3 className="text-xl font-semibold">My Maintenance Requests</h3>
        <p className="text-sm text-muted-foreground mt-1">Track the status of your submitted requests</p>
      </div>

      <div className="divide-y divide-border">
        {requests.length === 0 ? (
          <div className="p-12 text-center">
            <Icon name="WrenchScrewdriverIcon" size={48} className="mx-auto mb-4 text-muted-foreground opacity-50" />
            <p className="text-muted-foreground">No maintenance requests submitted yet</p>
          </div>
        ) : (
          requests.map((request) => (
            <div key={request.id} className="p-6 hover:bg-muted/30 transition-smooth">
              <div className="flex items-start justify-between gap-4 mb-3">
                <div className="flex items-start gap-3 flex-1 min-w-0">
                  <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={getCategoryIcon(request.category) as any} size={20} className="text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium mb-1 truncate">{request.title}</h4>
                    <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground caption">
                      <span className="capitalize">{request.category}</span>
                      <span>•</span>
                      <span className={`font-medium capitalize ${getPriorityColor(request.priority)}`}>
                        {request.priority} Priority
                      </span>
                      <span>•</span>
                      <span>{new Date(request.submittedDate).toLocaleDateString('en-GB')}</span>
                    </div>
                  </div>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-medium caption whitespace-nowrap ${getStatusColor(request.status)}`}>
                  {request.status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </span>
              </div>

              {request.assignedTo && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2 ml-13">
                  <Icon name="UserIcon" size={16} />
                  <span>Assigned to: {request.assignedTo}</span>
                </div>
              )}

              {request.estimatedCompletion && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3 ml-13">
                  <Icon name="ClockIcon" size={16} />
                  <span>Estimated completion: {new Date(request.estimatedCompletion).toLocaleDateString('en-GB')}</span>
                </div>
              )}

              <button
                onClick={() => onViewDetails(request.id)}
                className="ml-13 flex items-center gap-2 text-primary hover:text-primary/80 transition-smooth"
              >
                <span className="text-sm font-medium">View Details</span>
                <Icon name="ArrowRightIcon" size={16} />
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default MaintenanceRequestsList;