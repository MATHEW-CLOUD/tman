'use client';

import { useState, useEffect } from 'react';
import LeaseInfoCard from './LeaseInfoCard';
import PaymentHistoryTable from './PaymentHistoryTable';
import OutstandingBalanceCard from './OutstandingBalanceCard';
import LeaseDocumentsSection from './LeaseDocumentsSection';
import MaintenanceRequestForm from './MaintenanceRequestForm';
import MaintenanceRequestsList from './MaintenanceRequestsList';
import CommunicationCenter from './CommunicationCenter';
import MpesaPaymentModal from './MpesaPaymentModal';
import Icon from '@/components/ui/AppIcon';

interface LeaseInfo {
  unitNumber: string;
  propertyName: string;
  propertyAddress: string;
  rentAmount: number;
  leaseStartDate: string;
  leaseEndDate: string;
  daysUntilExpiry: number;
  securityDeposit: number;
  status: 'active' | 'expiring-soon' | 'expired';
}

interface Payment {
  id: string;
  date: string;
  amount: number;
  method: string;
  status: 'paid' | 'pending' | 'overdue';
  receiptNumber: string;
  description: string;
}

interface OutstandingBalance {
  amount: number;
  dueDate: string;
  description: string;
  lateFee: number;
}

interface LeaseDocument {
  id: string;
  name: string;
  type: 'lease-agreement' | 'addendum' | 'property-rules' | 'inspection-report';
  uploadDate: string;
  size: string;
  status: 'signed' | 'pending-signature' | 'expired';
}

interface MaintenanceRequest {
  id: string;
  title: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  submittedDate: string;
  assignedTo?: string;
  estimatedCompletion?: string;
}

interface Announcement {
  id: string;
  title: string;
  message: string;
  date: string;
  type: 'general' | 'maintenance' | 'emergency' | 'event';
  priority: 'low' | 'medium' | 'high';
}

interface MaintenanceFormData {
  title: string;
  description: string;
  category: string;
  priority: string;
  location: string;
  photos: File[];
}

const TenantPortalInteractive = () => {
  const [isHydrated, setIsHydrated] = useState(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'payments' | 'documents' | 'maintenance' | 'communication'>('overview');
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const mockLeaseInfo: LeaseInfo = {
    unitNumber: "A-204",
    propertyName: "Kilimani Heights Apartments",
    propertyAddress: "Argwings Kodhek Road, Kilimani, Nairobi",
    rentAmount: 45000,
    leaseStartDate: "2024-01-01",
    leaseEndDate: "2024-12-31",
    daysUntilExpiry: 345,
    securityDeposit: 90000,
    status: "active"
  };

  const mockPayments: Payment[] = [
    {
      id: "1",
      date: "2026-01-05",
      amount: 45000,
      method: "M-Pesa",
      status: "paid",
      receiptNumber: "RCP-2026-001",
      description: "January 2026 Rent"
    },
    {
      id: "2",
      date: "2025-12-05",
      amount: 45000,
      method: "M-Pesa",
      status: "paid",
      receiptNumber: "RCP-2025-012",
      description: "December 2025 Rent"
    },
    {
      id: "3",
      date: "2025-11-05",
      amount: 45000,
      method: "Bank Transfer",
      status: "paid",
      receiptNumber: "RCP-2025-011",
      description: "November 2025 Rent"
    },
    {
      id: "4",
      date: "2025-10-05",
      amount: 45000,
      method: "M-Pesa",
      status: "paid",
      receiptNumber: "RCP-2025-010",
      description: "October 2025 Rent"
    }
  ];

  const mockOutstandingBalance: OutstandingBalance = {
    amount: 45000,
    dueDate: "2026-02-05",
    description: "February 2026 Rent",
    lateFee: 0
  };

  const mockDocuments: LeaseDocument[] = [
    {
      id: "1",
      name: "Lease Agreement 2024",
      type: "lease-agreement",
      uploadDate: "2024-01-01",
      size: "2.4 MB",
      status: "signed"
    },
    {
      id: "2",
      name: "Property Rules & Regulations",
      type: "property-rules",
      uploadDate: "2024-01-01",
      size: "856 KB",
      status: "signed"
    },
    {
      id: "3",
      name: "Move-in Inspection Report",
      type: "inspection-report",
      uploadDate: "2024-01-02",
      size: "1.2 MB",
      status: "signed"
    },
    {
      id: "4",
      name: "Lease Renewal Addendum",
      type: "addendum",
      uploadDate: "2026-01-15",
      size: "645 KB",
      status: "pending-signature"
    }
  ];

  const mockMaintenanceRequests: MaintenanceRequest[] = [
    {
      id: "1",
      title: "Kitchen Sink Leaking",
      category: "plumbing",
      priority: "high",
      status: "in-progress",
      submittedDate: "2026-01-18",
      assignedTo: "John Mwangi - Plumber",
      estimatedCompletion: "2026-01-22"
    },
    {
      id: "2",
      title: "Bedroom AC Not Cooling",
      category: "hvac",
      priority: "medium",
      status: "pending",
      submittedDate: "2026-01-20"
    },
    {
      id: "3",
      title: "Broken Window Lock",
      category: "structural",
      priority: "low",
      status: "completed",
      submittedDate: "2026-01-10",
      assignedTo: "Peter Ochieng - Handyman"
    }
  ];

  const mockAnnouncements: Announcement[] = [
    {
      id: "1",
      title: "Water Supply Interruption",
      message: "Water supply will be interrupted on Saturday, 25th January from 8:00 AM to 2:00 PM for maintenance work on the main tank. Please store sufficient water in advance.",
      date: "2026-01-21T09:30:00",
      type: "maintenance",
      priority: "high"
    },
    {
      id: "2",
      title: "Community Clean-Up Day",
      message: "Join us for our monthly community clean-up on Sunday, 26th January at 9:00 AM. Refreshments will be provided. Let's keep our property beautiful together!",
      date: "2026-01-20T14:15:00",
      type: "event",
      priority: "low"
    },
    {
      id: "3",
      title: "Security Update",
      message: "New security protocols have been implemented. All visitors must now register at the gate with valid ID. Thank you for your cooperation in keeping our community safe.",
      date: "2026-01-19T11:00:00",
      type: "general",
      priority: "medium"
    }
  ];

  const handleDownloadReceipt = (receiptNumber: string) => {
    console.log('Downloading receipt:', receiptNumber);
    alert(`Receipt ${receiptNumber} download initiated. In a real application, this would download the PDF receipt.`);
  };

  const handlePayNow = () => {
    setIsPaymentModalOpen(true);
  };

  const handleMpesaPayment = (phoneNumber: string) => {
    console.log('Processing M-Pesa payment for:', phoneNumber);
    setTimeout(() => {
      setIsPaymentModalOpen(false);
      setShowSuccessMessage(true);
      setTimeout(() => setShowSuccessMessage(false), 5000);
    }, 2000);
  };

  const handleViewDocument = (documentId: string) => {
    console.log('Viewing document:', documentId);
    alert(`Opening document ${documentId}. In a real application, this would open the PDF viewer.`);
  };

  const handleSignDocument = (documentId: string) => {
    console.log('Signing document:', documentId);
    alert(`Opening e-signature interface for document ${documentId}. In a real application, this would open the digital signature workflow.`);
  };

  const handleSubmitMaintenance = (data: MaintenanceFormData) => {
    console.log('Submitting maintenance request:', data);
    alert('Maintenance request submitted successfully! You will receive an SMS notification once it has been reviewed.');
    setActiveTab('maintenance');
  };

  const handleViewMaintenanceDetails = (requestId: string) => {
    console.log('Viewing maintenance request:', requestId);
    alert(`Opening details for request ${requestId}. In a real application, this would show full request details with photos and updates.`);
  };

  const handleSendMessage = () => {
    alert('Opening messaging interface. In a real application, this would open a chat window to communicate with property management.');
  };

  const tabs = [
    { id: 'overview' as const, label: 'Overview', icon: 'HomeIcon' },
    { id: 'payments' as const, label: 'Payments', icon: 'CreditCardIcon' },
    { id: 'documents' as const, label: 'Documents', icon: 'DocumentTextIcon' },
    { id: 'maintenance' as const, label: 'Maintenance', icon: 'WrenchScrewdriverIcon' },
    { id: 'communication' as const, label: 'Communication', icon: 'ChatBubbleLeftRightIcon' }
  ];

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Icon name="ArrowPathIcon" size={48} className="mx-auto mb-4 text-primary animate-spin" />
          <p className="text-muted-foreground">Loading tenant portal...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {showSuccessMessage && (
        <div className="bg-success/10 border border-success/20 rounded-lg p-4 flex items-center gap-3 animate-slide-down">
          <Icon name="CheckCircleIcon" size={24} className="text-success flex-shrink-0" />
          <div>
            <p className="font-medium text-success">Payment Successful!</p>
            <p className="text-sm text-muted-foreground">Your payment has been processed. You will receive a confirmation SMS and email receipt shortly.</p>
          </div>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="bg-card rounded-lg shadow-warm-md border border-border overflow-x-auto">
        <div className="flex gap-1 p-2 min-w-max">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-md font-medium transition-smooth ${
                activeTab === tab.id
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
              }`}
            >
              <Icon name={tab.icon as any} size={20} />
              <span className="whitespace-nowrap">{tab.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <LeaseInfoCard leaseInfo={mockLeaseInfo} />
          <OutstandingBalanceCard balance={mockOutstandingBalance} onPayNow={handlePayNow} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <MaintenanceRequestsList 
              requests={mockMaintenanceRequests.slice(0, 2)} 
              onViewDetails={handleViewMaintenanceDetails}
            />
            <CommunicationCenter 
              announcements={mockAnnouncements.slice(0, 2)} 
              onSendMessage={handleSendMessage}
            />
          </div>
        </div>
      )}

      {activeTab === 'payments' && (
        <div className="space-y-6">
          <OutstandingBalanceCard balance={mockOutstandingBalance} onPayNow={handlePayNow} />
          <PaymentHistoryTable payments={mockPayments} onDownloadReceipt={handleDownloadReceipt} />
        </div>
      )}

      {activeTab === 'documents' && (
        <LeaseDocumentsSection 
          documents={mockDocuments} 
          onViewDocument={handleViewDocument}
          onSignDocument={handleSignDocument}
        />
      )}

      {activeTab === 'maintenance' && (
        <div className="space-y-6">
          <MaintenanceRequestForm onSubmit={handleSubmitMaintenance} />
          <MaintenanceRequestsList 
            requests={mockMaintenanceRequests} 
            onViewDetails={handleViewMaintenanceDetails}
          />
        </div>
      )}

      {activeTab === 'communication' && (
        <CommunicationCenter 
          announcements={mockAnnouncements} 
          onSendMessage={handleSendMessage}
        />
      )}

      <MpesaPaymentModal
        isOpen={isPaymentModalOpen}
        amount={mockOutstandingBalance.amount + mockOutstandingBalance.lateFee}
        description={mockOutstandingBalance.description}
        onClose={() => setIsPaymentModalOpen(false)}
        onConfirm={handleMpesaPayment}
      />
    </div>
  );
};

export default TenantPortalInteractive;