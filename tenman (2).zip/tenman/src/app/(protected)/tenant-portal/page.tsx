import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Breadcrumb from '@/components/common/Breadcrumb';
import TenantPortalInteractive from './components/TenantPortalInteractive';

export const metadata: Metadata = {
  title: 'Tenant Portal - TenantMaster',
  description: 'Access your lease information, make payments via M-Pesa, submit maintenance requests, and communicate with property management through your personalized tenant portal.',
};

export default function TenantPortalPage() {
  const mockNotifications = [
    {
      id: '1',
      title: 'Rent Payment Due',
      message: 'Your February 2026 rent payment of KES 45,000 is due on 5th February.',
      timestamp: '2026-01-21T09:00:00',
      read: false,
      link: '/tenant-portal',
      type: 'payment' as const
    },
    {
      id: '2',
      title: 'Maintenance Update',
      message: 'Your kitchen sink repair has been scheduled for 22nd January.',
      timestamp: '2026-01-20T14:30:00',
      read: false,
      link: '/tenant-portal',
      type: 'maintenance' as const
    }
  ];

  return (
    <>
      <Header notifications={mockNotifications} />
      <main className="min-h-screen bg-background pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6">
            <Breadcrumb />
            <div className="mt-4">
              <h1 className="text-3xl font-bold mb-2">Tenant Portal</h1>
              <p className="text-muted-foreground">
                Manage your lease, payments, and maintenance requests in one place
              </p>
            </div>
          </div>

          <TenantPortalInteractive />
        </div>
      </main>
    </>
  );
}