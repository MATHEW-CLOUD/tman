'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Property {
  id: string;
  name: string;
  type: string;
  units: number;
}

interface PropertyFilterProps {
  properties: Property[];
  selectedProperties: string[];
  onPropertyChange: (propertyIds: string[]) => void;
}

const PropertyFilter = ({ properties, selectedProperties, onPropertyChange }: PropertyFilterProps) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleToggleProperty = (propertyId: string) => {
    if (selectedProperties.includes(propertyId)) {
      onPropertyChange(selectedProperties.filter(id => id !== propertyId));
    } else {
      onPropertyChange([...selectedProperties, propertyId]);
    }
  };

  const handleSelectAll = () => {
    if (selectedProperties.length === properties.length) {
      onPropertyChange([]);
    } else {
      onPropertyChange(properties.map(p => p.id));
    }
  };

  const getDisplayText = () => {
    if (selectedProperties.length === 0) return 'All Properties';
    if (selectedProperties.length === properties.length) return 'All Properties';
    if (selectedProperties.length === 1) {
      const property = properties.find(p => p.id === selectedProperties[0]);
      return property?.name || 'All Properties';
    }
    return `${selectedProperties.length} Properties`;
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full sm:w-auto flex items-center gap-2 px-4 py-3 bg-card border border-border rounded-lg hover:bg-muted transition-smooth"
      >
        <Icon name="BuildingOfficeIcon" size={20} className="text-muted-foreground" />
        <span className="text-sm font-medium">{getDisplayText()}</span>
        <Icon 
          name="ChevronDownIcon" 
          size={16} 
          className={`text-muted-foreground transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute top-full left-0 right-0 sm:right-auto sm:w-80 mt-2 bg-popover border border-border rounded-lg shadow-warm-xl z-20 animate-slide-down max-h-96 overflow-y-auto">
            <div className="sticky top-0 bg-popover border-b border-border p-3">
              <button
                onClick={handleSelectAll}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-md hover:bg-muted transition-smooth"
              >
                <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                  selectedProperties.length === properties.length
                    ? 'bg-primary border-primary' :'border-border'
                }`}>
                  {selectedProperties.length === properties.length && (
                    <Icon name="CheckIcon" size={14} className="text-primary-foreground" />
                  )}
                </div>
                <span className="text-sm font-medium">Select All Properties</span>
              </button>
            </div>
            <div className="p-2">
              {properties.map((property) => (
                <button
                  key={property.id}
                  onClick={() => handleToggleProperty(property.id)}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted transition-smooth"
                >
                  <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 ${
                    selectedProperties.includes(property.id)
                      ? 'bg-primary border-primary' :'border-border'
                  }`}>
                    {selectedProperties.includes(property.id) && (
                      <Icon name="CheckIcon" size={14} className="text-primary-foreground" />
                    )}
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-medium">{property.name}</p>
                    <p className="text-xs text-muted-foreground caption">
                      {property.type} • {property.units} units
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default PropertyFilter;