'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { useMemo } from 'react';
import FinancialSummaryCards from './FinancialSummaryCards';
import RevenueChart from './RevenueChart';
import OccupancyCharts from './OccupancyCharts';
import TransactionTable from './TransactionTable';
import DateRangePicker from './DateRangePicker';

type Summary = {
  revenueThisMonth: number;
  revenueYTD: number;
  outstandingArrears: number;
  overallOccupancy: number; // %
};

type RevenuePoint = { month: string; total: number };
type Aging = { bucket0to30: number; bucket31to60: number; bucket61to90: number; bucket90plus: number };
type OccupancyItem = { propertyName: string; totalUnits: number; occupiedUnits: number; rate: number };

type Tx = {
  id: string;
  transactionId: string;
  tenantName: string;
  propertyName: string;
  unitNumber: string;
  amount: number;
  paymentMethod: string;
  status: 'completed' | 'pending' | 'failed';
  date: string;
  receiptNumber: string;
  description: string;
  vatAmount: number;
};

export default function FinancialReportsInteractive({
  from,
  to,
  summary,
  revenueSeries,
  aging,
  occupancy,
  transactions,
}: {
  from: string;
  to: string;
  summary: Summary;
  revenueSeries: RevenuePoint[];
  aging: Aging;
  occupancy: OccupancyItem[];
  transactions: Tx[];
}) {
  const router = useRouter();
  const search = useSearchParams();

  function onRangeChange(nextFrom: string, nextTo: string) {
    const params = new URLSearchParams(search?.toString() || '');
    params.set('from', nextFrom);
    params.set('to', nextTo);
    router.replace(`/financial-reports?${params.toString()}`);
  }

  const revenueTotal = useMemo(
    () => revenueSeries.reduce((s, p) => s + p.total, 0),
    [revenueSeries]
  );

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <FinancialSummaryCards
            summary={{
              revenueThisMonth: summary.revenueThisMonth,
              revenueYTD: summary.revenueYTD,
              outstandingArrears: summary.outstandingArrears,
              overallOccupancy: summary.overallOccupancy,
              revenueTotal,
            }}
          />
        </div>
        <div className="shrink-0">
          <DateRangePicker from={from} to={to} onChange={onRangeChange} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RevenueChart data={revenueSeries} />
        </div>
        <div className="lg:col-span-1">
          <OccupancyCharts data={occupancy} aging={aging} />
        </div>
      </div>

      <TransactionTable transactions={transactions} />
    </div>
  );
}