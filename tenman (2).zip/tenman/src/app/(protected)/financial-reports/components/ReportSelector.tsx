'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface ReportType {
  id: string;
  name: string;
  icon: string;
  description: string;
}

interface ReportSelectorProps {
  selectedReport: string;
  onReportChange: (reportId: string) => void;
}

const ReportSelector = ({ selectedReport, onReportChange }: ReportSelectorProps) => {
  const [isOpen, setIsOpen] = useState(false);

  const reportTypes: ReportType[] = [
    {
      id: 'income-statement',
      name: 'Income Statement',
      icon: 'CurrencyDollarIcon',
      description: 'Revenue and expense summary'
    },
    {
      id: 'cash-flow',
      name: 'Cash Flow',
      icon: 'ArrowTrendingUpIcon',
      description: 'Money in and out analysis'
    },
    {
      id: 'tax-report',
      name: 'Tax Report',
      icon: 'DocumentTextIcon',
      description: 'KRA compliance report with 16% VAT'
    },
    {
      id: 'occupancy-analysis',
      name: 'Occupancy Analysis',
      icon: 'ChartBarIcon',
      description: 'Vacancy and occupancy metrics'
    }
  ];

  const currentReport = reportTypes.find(r => r.id === selectedReport) || reportTypes[0];

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full sm:w-auto flex items-center justify-between gap-3 px-4 py-3 bg-card border border-border rounded-lg hover:bg-muted transition-smooth"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <Icon name={currentReport.icon as any} size={20} className="text-primary" />
          </div>
          <div className="text-left">
            <p className="font-medium text-sm">{currentReport.name}</p>
            <p className="text-xs text-muted-foreground caption">{currentReport.description}</p>
          </div>
        </div>
        <Icon 
          name="ChevronDownIcon" 
          size={20} 
          className={`text-muted-foreground transition-transform ${isOpen ? 'rotate-180' : ''}`}
        />
      </button>

      {isOpen && (
        <>
          <div 
            className="fixed inset-0 z-10" 
            onClick={() => setIsOpen(false)}
          />
          <div className="absolute top-full left-0 right-0 sm:right-auto sm:w-80 mt-2 bg-popover border border-border rounded-lg shadow-warm-xl z-20 animate-slide-down">
            {reportTypes.map((report) => (
              <button
                key={report.id}
                onClick={() => {
                  onReportChange(report.id);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-muted transition-smooth first:rounded-t-lg last:rounded-b-lg ${
                  report.id === selectedReport ? 'bg-primary/5' : ''
                }`}
              >
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  report.id === selectedReport ? 'bg-primary/20' : 'bg-muted'
                }`}>
                  <Icon 
                    name={report.icon as any} 
                    size={20} 
                    className={report.id === selectedReport ? 'text-primary' : 'text-muted-foreground'}
                  />
                </div>
                <div className="flex-1 text-left">
                  <p className={`font-medium text-sm ${
                    report.id === selectedReport ? 'text-primary' : 'text-foreground'
                  }`}>
                    {report.name}
                  </p>
                  <p className="text-xs text-muted-foreground caption">{report.description}</p>
                </div>
                {report.id === selectedReport && (
                  <Icon name="CheckIcon" size={20} className="text-primary" />
                )}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default ReportSelector;