'use client';

import { useState } from 'react';

export default function DateRangePicker({
  from,
  to,
  onChange,
}: {
  from: string; // YYYY-MM-DD
  to: string;   // YYYY-MM-DD
  onChange: (from: string, to: string) => void;
}) {
  const [f, setF] = useState(from);
  const [t, setT] = useState(to);

  return (
    <div className="bg-card border border-border rounded-lg p-3 flex items-center gap-2">
      <input
        type="date"
        value={f}
        onChange={(e) => setF(e.target.value)}
        className="border border-input rounded px-2 py-1 text-sm bg-background"
      />
      <span className="text-sm text-muted-foreground">to</span>
      <input
        type="date"
        value={t}
        onChange={(e) => setT(e.target.value)}
        className="border border-input rounded px-2 py-1 text-sm bg-background"
      />
      <button
        onClick={() => onChange(f, t)}
        className="px-3 py-1.5 rounded bg-primary text-white text-sm hover:opacity-90"
      >
        Apply
      </button>
    </div>
  );
}