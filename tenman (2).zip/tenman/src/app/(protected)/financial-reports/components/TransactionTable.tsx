'use client';

import Icon from '@/components/ui/AppIcon';

type Tx = {
  id: string;
  transactionId: string;
  tenantName: string;
  propertyName: string;
  unitNumber: string;
  amount: number;
  paymentMethod: string;
  status: 'completed' | 'pending' | 'failed';
  date: string; // ISO
  receiptNumber: string;
  description: string;
  vatAmount: number;
};

function fmtKES(n: number) {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n);
}
function fmtDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function statusChip(s: Tx['status']) {
  switch (s) {
    case 'completed':
      return { label: 'Completed', chip: 'bg-success/10 text-success', icon: 'CheckCircleIcon' };
    case 'pending':
      return { label: 'Pending', chip: 'bg-warning/10 text-warning', icon: 'ClockIcon' };
    default:
      return { label: 'Failed', chip: 'bg-error/10 text-error', icon: 'XCircleIcon' };
  }
}

export default function TransactionTable({ transactions }: { transactions: Tx[] }) {
  return (
    <div className="bg-card rounded-lg shadow-warm-sm border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Recent Transactions</h3>
            <p className="text-sm text-muted-foreground">Latest payments in the selected range</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="px-3 py-2 bg-muted rounded-lg text-sm">Export</button>
          </div>
        </div>
      </div>

      {/* Desktop */}
      <div className="hidden lg:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-muted/50">
            <tr>
              <th className="px-6 py-4 text-left text-sm font-semibold">Receipt</th>
              <th className="px-6 py-4 text-left text-sm font-semibold">Tenant</th>
              <th className="px-6 py-4 text-left text-sm font-semibold">Property/Unit</th>
              <th className="px-6 py-4 text-left text-sm font-semibold">Amount</th>
              <th className="px-6 py-4 text-left text-sm font-semibold">Method</th>
              <th className="px-6 py-4 text-left text-sm font-semibold">Date</th>
              <th className="px-6 py-4 text-left text-sm font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {transactions.map((t) => {
              const s = statusChip(t.status);
              return (
                <tr key={t.id} className="hover:bg-muted/30 transition-smooth">
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-sm font-medium data-text">{t.transactionId}</p>
                      <p className="text-xs text-muted-foreground">{t.description}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">{t.tenantName}</td>
                  <td className="px-6 py-4">
                    {t.propertyName} — Unit {t.unitNumber}
                  </td>
                  <td className="px-6 py-4 font-semibold">{fmtKES(t.amount)}</td>
                  <td className="px-6 py-4">{t.paymentMethod}</td>
                  <td className="px-6 py-4">{fmtDate(t.date)}</td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${s.chip}`}
                    >
                      <Icon name={s.icon as any} size={14} />
                      {s.label}
                    </span>
                  </td>
                </tr>
              );
            })}
            {transactions.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-8 text-center text-muted-foreground">
                  No transactions in this range.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile */}
      <div className="lg:hidden divide-y divide-border">
        {transactions.map((t) => {
          const s = statusChip(t.status);
          return (
            <div key={t.id} className="p-4 hover:bg-muted/30 transition-smooth">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <p className="text-sm font-medium">{t.tenantName}</p>
                  <p className="text-xs text-muted-foreground">
                    {t.propertyName} — Unit {t.unitNumber}
                  </p>
                  <p className="text-xs text-muted-foreground data-text">{t.transactionId}</p>
                </div>
                <span
                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${s.chip}`}
                >
                  <Icon name={s.icon as any} size={12} />
                  {s.label}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-3">
                <div>
                  <p className="text-xs text-muted-foreground">Amount</p>
                  <p className="text-base font-semibold">{fmtKES(t.amount)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Method</p>
                  <p className="text-sm">{t.paymentMethod}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-xs text-muted-foreground">Date</p>
                  <p className="text-sm">{fmtDate(t.date)}</p>
                </div>
              </div>
            </div>
          );
        })}
        {transactions.length === 0 && (
          <div className="p-6 text-center text-muted-foreground">No transactions in this range.</div>
        )}
      </div>
    </div>
  );
}