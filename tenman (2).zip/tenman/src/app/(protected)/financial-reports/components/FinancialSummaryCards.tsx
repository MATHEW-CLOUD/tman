'use client';

function fmtKES(n: number) {
  return new Intl.NumberFormat('en-KE', {
    style: 'currency',
    currency: 'KES',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(n);
}

export default function FinancialSummaryCards({
  summary,
}: {
  summary: {
    revenueThisMonth: number;
    revenueYTD: number;
    outstandingArrears: number;
    overallOccupancy: number;
    revenueTotal: number;
  };
}) {
  const items = [
    {
      label: 'Revenue (This Month)',
      value: fmtKES(summary.revenueThisMonth),
      sub: `YTD: ${fmtKES(summary.revenueYTD)}`,
    },
    {
      label: 'Outstanding Arrears',
      value: fmtKES(summary.outstandingArrears),
      sub: 'Past due balance',
    },
    {
      label: 'Overall Occupancy',
      value: `${summary.overallOccupancy}%`,
      sub: 'Across all properties',
    },
    {
      label: 'Revenue (Selected Range)',
      value: fmtKES(summary.revenueTotal),
      sub: 'Sum of paid receipts',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {items.map((it) => (
        <div
          key={it.label}
          className="bg-card rounded-lg p-5 shadow-warm-sm border border-border"
        >
          <p className="text-sm text-muted-foreground">{it.label}</p>
          <p className="text-2xl font-semibold mt-1">{it.value}</p>
          <p className="text-xs text-muted-foreground mt-1">{it.sub}</p>
        </div>
      ))}
    </div>
  );
}