'use client';

import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function RevenueChart({ data }: { data: { month: string; total: number }[] }) {
  return (
    <div className="bg-card rounded-lg p-6 shadow-warm-sm border border-border h-[360px]">
      <div className="mb-4">
        <h3 className="text-lg font-semibold">Revenue by Month</h3>
        <p className="text-sm text-muted-foreground">Successful payments in the selected period</p>
      </div>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#15803d" stopOpacity={0.8} />
              <stop offset="95%" stopColor="#15803d" stopOpacity={0.05} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis dataKey="month" tick={{ fontSize: 12 }} />
          <YAxis tick={{ fontSize: 12 }} />
          <Tooltip />
          <Area type="monotone" dataKey="total" stroke="#15803d" fill="url(#rev)" />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}