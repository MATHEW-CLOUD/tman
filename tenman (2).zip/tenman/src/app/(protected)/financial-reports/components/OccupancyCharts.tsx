'use client';

import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';

export default function OccupancyCharts({
  data,
  aging,
}: {
  data: { propertyName: string; totalUnits: number; occupiedUnits: number; rate: number }[];
  aging: { bucket0to30: number; bucket31to60: number; bucket61to90: number; bucket90plus: number };
}) {
  const occ = data.map((d) => ({ name: d.propertyName, Occupied: d.rate }));

  const agingSeries = [
    { name: '0–30', Amount: aging.bucket0to30 },
    { name: '31–60', Amount: aging.bucket31to60 },
    { name: '61–90', Amount: aging.bucket61to90 },
    { name: '90+', Amount: aging.bucket90plus },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-card rounded-lg p-6 shadow-warm-sm border border-border h-[160px]">
        <h3 className="text-sm font-semibold mb-2">Occupancy by Property</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={occ}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" hide />
            <YAxis domain={[0, 100]} />
            <Tooltip />
            <Bar dataKey="Occupied" fill="#15803d" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="bg-card rounded-lg p-6 shadow-warm-sm border border-border h-[160px]">
        <h3 className="text-sm font-semibold mb-2">Arrears Aging (KES)</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={agingSeries}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Bar dataKey="Amount" fill="#a21caf" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}