'use client';

import { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

interface ExpenseData {
  category: string;
  amount: number;
  percentage: number;
}

interface ExpenseBreakdownChartProps {
  data: ExpenseData[];
}

const ExpenseBreakdownChart = ({ data }: ExpenseBreakdownChartProps) => {
  const [isHydrated, setIsHydrated] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const COLORS = ['#2E7D32', '#388E3C', '#66BB6A', '#81C784', '#A5D6A7', '#C8E6C9'];

  if (!isHydrated) {
    return (
      <div className="bg-card border border-border rounded-lg p-6">
        <div className="mb-6">
          <h3 className="text-lg font-semibold">Expense Breakdown</h3>
          <p className="text-sm text-muted-foreground caption">Category-wise expense distribution</p>
        </div>
        <div className="h-80 flex items-center justify-center bg-muted/30 rounded-lg">
          <p className="text-muted-foreground">Loading chart...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold">Expense Breakdown</h3>
        <p className="text-sm text-muted-foreground caption">Category-wise expense distribution</p>
      </div>
      <div className="h-80" aria-label="Expense Breakdown Pie Chart">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              label={({ percentage }) => `${percentage}%`}
              outerRadius={100}
              fill="#8884d8"
              dataKey="amount"
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#fff', 
                border: '1px solid #ddd',
                borderRadius: '8px',
                padding: '12px'
              }}
              formatter={(value: number) => `KES ${value.toLocaleString()}`}
            />
            <Legend 
              verticalAlign="bottom" 
              height={36}
              iconType="circle"
            />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-6 space-y-2">
        {data.map((item, index) => (
          <div key={index} className="flex items-center justify-between py-2 border-b border-border last:border-0">
            <div className="flex items-center gap-2">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: COLORS[index % COLORS.length] }}
              />
              <span className="text-sm font-medium">{item.category}</span>
            </div>
            <span className="text-sm font-semibold data-text">KES {item.amount.toLocaleString()}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ExpenseBreakdownChart;