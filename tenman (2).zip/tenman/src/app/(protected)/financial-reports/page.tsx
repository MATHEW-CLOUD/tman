import { redirect } from 'next/navigation';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import FinancialReportsInteractive from './components/FinancialReportsInteractive';

export const dynamic = 'force-dynamic';

function startOfMonth(d: Date) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}
function endOfDay(d: Date) {
  const x = new Date(d);
  x.setHours(23, 59, 59, 999);
  return x;
}
function addMonths(d: Date, delta: number) {
  return new Date(d.getFullYear(), d.getMonth() + delta, 1);
}
function monthKey(d: Date) {
  const m = d.getMonth() + 1;
  return `${d.getFullYear()}-${m < 10 ? '0' + m : m}`;
}

export default async function FinancialReportsPage({
  searchParams,
}: {
  searchParams?: { from?: string; to?: string };
}) {
  const me = await getCurrentUser();
  if (!me) redirect('/login');

  const orgIds = me.membershipOrgIds;
  const now = new Date();

  // Resolve date range (default: last 12 months inclusive)
  const to = searchParams?.to ? endOfDay(new Date(searchParams.to)) : endOfDay(now);
  const defaultFrom = addMonths(startOfMonth(now), -11); // 12 months window
  const from = searchParams?.from ? new Date(searchParams.from) : defaultFrom;

  // ---------- Revenue by month ----------
  // Payments in range, SUCCESS only, grouped by month
  const paymentsInRange = await prisma.payment.findMany({
    where: {
      status: 'SUCCESS',
      paidAt: { gte: from, lte: to },
      invoice: { organizationId: { in: orgIds } },
    },
    select: {
      amount: true,
      paidAt: true,
      invoice: {
        select: {
          reference: true,
          lease: {
            select: {
              tenant: { select: { name: true, email: true } },
              unit: { select: { unitNumber: true, property: { select: { name: true } } } },
            },
          },
        },
      },
      method: true,
      mpesaReceipt: true,
      id: true,
      status: true,
    },
    orderBy: { paidAt: 'asc' },
  });

  // Build month buckets across the range
  const months: string[] = [];
  for (let d = startOfMonth(from); d <= to; d = addMonths(d, 1)) {
    months.push(monthKey(d));
  }
  const revenueByMonthMap = new Map<string, number>(months.map((m) => [m, 0]));
  paymentsInRange.forEach((p) => {
    const k = monthKey(p.paidAt);
    revenueByMonthMap.set(k, (revenueByMonthMap.get(k) || 0) + Number(p.amount));
  });
  const revenueSeries = months.map((m) => ({ month: m, total: revenueByMonthMap.get(m) || 0 }));

  // ---------- Transactions (recent) ----------
  const recentPayments = await prisma.payment.findMany({
    where: {
      invoice: { organizationId: { in: orgIds } },
      paidAt: { gte: from, lte: to },
    },
    include: {
      invoice: {
        include: {
          lease: {
            include: {
              tenant: { select: { name: true, email: true } },
              unit: { include: { property: { select: { name: true } } } },
            },
          },
        },
      },
    },
    orderBy: { paidAt: 'desc' },
    take: 100,
  });

  const transactions = recentPayments.map((p) => {
    const tenantName = p.invoice.lease.tenant.name ?? p.invoice.lease.tenant.email;
    const statusUi = p.status === 'SUCCESS' ? 'completed' : p.status === 'PENDING' ? 'pending' : 'failed';
    return {
      id: p.id,
      transactionId: p.mpesaReceipt ?? p.id.slice(0, 10).toUpperCase(),
      tenantName,
      propertyName: p.invoice.lease.unit.property.name,
      unitNumber: p.invoice.lease.unit.unitNumber,
      amount: Number(p.amount),
      paymentMethod: p.method, // MPESA/CASH/BANK
      status: statusUi as 'completed' | 'pending' | 'failed',
      date: p.paidAt.toISOString(),
      receiptNumber: p.mpesaReceipt ?? '',
      description: p.invoice.reference || p.invoice.lease.unit.property.name,
      vatAmount: 0,
    };
  });

  // ---------- Invoices & aging ----------
  const invoices = await prisma.invoice.findMany({
    where: { organizationId: { in: orgIds } },
    include: { payments: true, lease: { include: { unit: { include: { property: true } }, tenant: true } } },
  });

  let outstandingArrears = 0;
  let bucket0to30 = 0;
  let bucket31to60 = 0;
  let bucket61to90 = 0;
  let bucket90plus = 0;

  for (const inv of invoices) {
    const totalPaid = inv.payments
      .filter((p) => p.status === 'SUCCESS')
      .reduce((s, p) => s + Number(p.amount), 0);
    const balance = Number(inv.amount) - totalPaid;

    if (balance > 0 && inv.dueDate < now) {
      outstandingArrears += balance;
      const days = Math.floor((+now - +inv.dueDate) / (1000 * 60 * 60 * 24));
      if (days <= 30) bucket0to30 += balance;
      else if (days <= 60) bucket31to60 += balance;
      else if (days <= 90) bucket61to90 += balance;
      else bucket90plus += balance;
    }
  }

  const aging = { bucket0to30, bucket31to60, bucket61to90, bucket90plus };

  // ---------- Occupancy ----------
  // Use Unit.status by property
  const units = await prisma.unit.findMany({
    where: { property: { organizationId: { in: orgIds } } },
    include: { property: true },
  });

  const byProperty = new Map<
    string,
    { propertyName: string; totalUnits: number; occupiedUnits: number }
  >();

  for (const u of units) {
    const key = u.property.id;
    if (!byProperty.has(key)) {
      byProperty.set(key, { propertyName: u.property.name, totalUnits: 0, occupiedUnits: 0 });
    }
    const rec = byProperty.get(key)!;
    rec.totalUnits += 1;
    if (u.status === 'OCCUPIED') rec.occupiedUnits += 1;
  }

  const occupancy = Array.from(byProperty.values()).map((p) => ({
    propertyName: p.propertyName,
    totalUnits: p.totalUnits,
    occupiedUnits: p.occupiedUnits,
    rate: p.totalUnits ? Math.round((p.occupiedUnits / p.totalUnits) * 100) : 0,
  }));

  const overallOccupancy =
    units.length > 0
      ? Math.round((units.filter((u) => u.status === 'OCCUPIED').length / units.length) * 100)
      : 0;

  // ---------- Summary KPIs ----------
  const thisMonthStart = startOfMonth(now);
  const ytdStart = new Date(now.getFullYear(), 0, 1);

  const thisMonthRevenue = await prisma.payment.aggregate({
    _sum: { amount: true },
    where: {
      status: 'SUCCESS',
      paidAt: { gte: thisMonthStart, lte: now },
      invoice: { organizationId: { in: orgIds } },
    },
  });

  const ytdRevenueAgg = await prisma.payment.aggregate({
    _sum: { amount: true },
    where: {
      status: 'SUCCESS',
      paidAt: { gte: ytdStart, lte: now },
      invoice: { organizationId: { in: orgIds } },
    },
  });

  const summary = {
    revenueThisMonth: Number(thisMonthRevenue._sum.amount ?? 0),
    revenueYTD: Number(ytdRevenueAgg._sum.amount ?? 0),
    outstandingArrears,
    overallOccupancy,
  };

  return (
    <FinancialReportsInteractive
      from={from.toISOString().slice(0, 10)}
      to={to.toISOString().slice(0, 10)}
      summary={summary}
      revenueSeries={revenueSeries}
      aging={aging}
      occupancy={occupancy}
      transactions={transactions}
    />
  );
}