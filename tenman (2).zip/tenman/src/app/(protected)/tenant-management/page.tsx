import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Breadcrumb from '@/components/common/Breadcrumb';
import TenantManagementInteractive from './components/TenantManagementInteractive';

export const metadata: Metadata = {
  title: 'Tenant Management - TenantMaster',
  description: 'Manage tenant lifecycle from onboarding through lease termination with integrated KYC verification, payment processing, and maintenance tracking for Kenyan properties.',
};

export default function TenantManagementPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Breadcrumb */}
          <Breadcrumb className="mb-6" />

          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-heading font-semibold mb-2">Tenant Management</h1>
            <p className="text-muted-foreground">
              Comprehensive tenant lifecycle management with KYC verification, payment processing, and lease management
            </p>
          </div>

          {/* Interactive Content */}
          <TenantManagementInteractive />
        </div>
      </main>
    </div>
  );
}