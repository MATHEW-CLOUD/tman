'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface Tenant {
  id: string;
  name: string;
  phone: string;
  rentAmount: number;
  unit: string;
}

interface PaymentModalProps {
  isOpen: boolean;
  tenant: Tenant | null;
  onClose: () => void;
  onPaymentComplete: (paymentData: PaymentData) => void;
}

interface PaymentData {
  tenantId: string;
  amount: number;
  method: string;
  reference: string;
  status: 'completed' | 'pending' | 'failed';
}

export default function PaymentModal({ isOpen, tenant, onClose, onPaymentComplete }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<'mpesa' | 'airtel' | 'tkash'>('mpesa');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success' | 'failed'>('idle');
  const [transactionRef, setTransactionRef] = useState('');

  useEffect(() => {
    if (tenant) {
      setPhoneNumber(tenant.phone);
      setAmount(tenant.rentAmount.toString());
    }
  }, [tenant]);

  if (!isOpen || !tenant) return null;

  const handlePayment = () => {
    setIsProcessing(true);
    setPaymentStatus('processing');

    // Simulate M-Pesa STK push
    setTimeout(() => {
      const reference = `TXN${Date.now()}`;
      setTransactionRef(reference);
      setPaymentStatus('success');
      setIsProcessing(false);

      const paymentData: PaymentData = {
        tenantId: tenant.id,
        amount: parseFloat(amount),
        method: paymentMethod.toUpperCase(),
        reference,
        status: 'completed',
      };

      setTimeout(() => {
        onPaymentComplete(paymentData);
        handleClose();
      }, 2000);
    }, 3000);
  };

  const handleClose = () => {
    setPaymentStatus('idle');
    setIsProcessing(false);
    setTransactionRef('');
    onClose();
  };

  const formatCurrency = (value: number) => {
    return `KES ${value.toLocaleString('en-KE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in">
      <div className="w-full max-w-md bg-card rounded-lg shadow-warm-xl overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-heading font-semibold">Process Payment</h2>
            <button
              onClick={handleClose}
              disabled={isProcessing}
              className="p-2 rounded-md hover:bg-muted transition-smooth disabled:opacity-50"
              aria-label="Close payment modal"
            >
              <Icon name="XMarkIcon" size={24} />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          {paymentStatus === 'idle' && (
            <div className="space-y-6">
              {/* Tenant Info */}
              <div className="bg-muted/50 rounded-lg p-4">
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Tenant:</span>
                  <span className="font-medium">{tenant.name}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-muted-foreground">Unit:</span>
                  <span className="font-medium">{tenant.unit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rent Amount:</span>
                  <span className="font-semibold data-text">{formatCurrency(tenant.rentAmount)}</span>
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-sm font-medium mb-3">Payment Method</label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setPaymentMethod('mpesa')}
                    className={`p-4 border-2 rounded-lg transition-smooth ${
                      paymentMethod === 'mpesa' ?'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="text-center">
                      <Icon name="DevicePhoneMobileIcon" size={32} className="mx-auto mb-2 text-success" />
                      <p className="text-sm font-medium">M-Pesa</p>
                    </div>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('airtel')}
                    className={`p-4 border-2 rounded-lg transition-smooth ${
                      paymentMethod === 'airtel' ?'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="text-center">
                      <Icon name="DevicePhoneMobileIcon" size={32} className="mx-auto mb-2 text-error" />
                      <p className="text-sm font-medium">Airtel</p>
                    </div>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('tkash')}
                    className={`p-4 border-2 rounded-lg transition-smooth ${
                      paymentMethod === 'tkash' ?'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="text-center">
                      <Icon name="DevicePhoneMobileIcon" size={32} className="mx-auto mb-2 text-warning" />
                      <p className="text-sm font-medium">T-Kash</p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Phone Number */}
              <div>
                <label className="block text-sm font-medium mb-2">Phone Number</label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-4 py-3 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  placeholder="+254 700 000 000"
                />
              </div>

              {/* Amount */}
              <div>
                <label className="block text-sm font-medium mb-2">Amount (KES)</label>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-4 py-3 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  placeholder="0.00"
                />
              </div>

              {/* Info Box */}
              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <div className="flex gap-3">
                  <Icon name="InformationCircleIcon" size={24} className="text-primary flex-shrink-0" />
                  <div>
                    <h4 className="font-medium mb-1">Payment Instructions</h4>
                    <p className="text-sm text-muted-foreground">
                      You will receive an STK push notification on your phone. Enter your {paymentMethod.toUpperCase()} PIN to complete the payment.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {paymentStatus === 'processing' && (
            <div className="py-8 text-center">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <h3 className="text-lg font-heading font-semibold mb-2">Processing Payment</h3>
              <p className="text-muted-foreground mb-4">
                Please check your phone for the STK push notification
              </p>
              <div className="bg-muted/50 rounded-lg p-4 text-left space-y-2">
                <div className="flex items-center gap-2">
                  <Icon name="CheckCircleIcon" size={20} className="text-success" variant="solid" />
                  <span className="text-sm">STK push sent</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  <span className="text-sm">Waiting for PIN entry...</span>
                </div>
              </div>
            </div>
          )}

          {paymentStatus === 'success' && (
            <div className="py-8 text-center">
              <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Icon name="CheckCircleIcon" size={56} className="text-success" variant="solid" />
              </div>
              <h3 className="text-xl font-heading font-semibold mb-2 text-success">Payment Successful!</h3>
              <p className="text-muted-foreground mb-6">
                Your payment has been processed successfully
              </p>
              <div className="bg-muted/50 rounded-lg p-4 text-left space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount Paid:</span>
                  <span className="font-semibold data-text">{formatCurrency(parseFloat(amount))}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Method:</span>
                  <span className="font-medium">{paymentMethod.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Reference:</span>
                  <span className="font-medium data-text">{transactionRef}</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        {paymentStatus === 'idle' && (
          <div className="p-6 border-t border-border flex items-center justify-between">
            <button
              onClick={handleClose}
              className="px-6 py-2 border border-border rounded-md hover:bg-muted transition-smooth font-medium"
            >
              Cancel
            </button>
            <button
              onClick={handlePayment}
              disabled={!phoneNumber || !amount || parseFloat(amount) <= 0}
              className="px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth disabled:opacity-50 disabled:cursor-not-allowed font-medium"
            >
              Send Payment Request
            </button>
          </div>
        )}
      </div>
    </div>
  );
}