'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: (data: OnboardingData) => void;
}

interface OnboardingData {
  personalDetails: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    nationalId: string;
    kraPin: string;
    dateOfBirth: string;
    occupation: string;
    monthlyIncome: string;
  };
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  propertyDetails: {
    property: string;
    unit: string;
    rentAmount: string;
    leaseStart: string;
    leaseDuration: string;
  };
}

export default function OnboardingModal({ isOpen, onClose, onComplete }: OnboardingModalProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState<'idle' | 'success' | 'failed'>('idle');
  
  const [formData, setFormData] = useState<OnboardingData>({
    personalDetails: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      nationalId: '',
      kraPin: '',
      dateOfBirth: '',
      occupation: '',
      monthlyIncome: '',
    },
    emergencyContact: {
      name: '',
      relationship: '',
      phone: '',
    },
    propertyDetails: {
      property: '',
      unit: '',
      rentAmount: '',
      leaseStart: '',
      leaseDuration: '12',
    },
  });

  const steps = [
    { number: 1, title: 'Personal Details', icon: 'UserIcon' },
    { number: 2, title: 'KYC Verification', icon: 'ShieldCheckIcon' },
    { number: 3, title: 'Property Details', icon: 'BuildingOfficeIcon' },
    { number: 4, title: 'Review & Sign', icon: 'DocumentCheckIcon' },
  ];

  if (!isOpen) return null;

  const handleInputChange = (section: keyof OnboardingData, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value,
      },
    }));
  };

  const handleVerifyKYC = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setVerificationStatus('success');
    }, 2000);
  };

  const handleNext = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    onComplete(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 animate-fade-in">
      <div className="w-full max-w-4xl bg-card rounded-lg shadow-warm-xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-heading font-semibold">Tenant Onboarding</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-md hover:bg-muted transition-smooth"
              aria-label="Close onboarding"
            >
              <Icon name="XMarkIcon" size={24} />
            </button>
          </div>

          {/* Progress Steps */}
          <div className="flex items-center justify-between">
            {steps.map((step, index) => (
              <div key={step.number} className="flex items-center flex-1">
                <div className="flex flex-col items-center flex-1">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center transition-smooth ${
                    currentStep >= step.number
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted text-muted-foreground'
                  }`}>
                    {currentStep > step.number ? (
                      <Icon name="CheckIcon" size={20} variant="solid" />
                    ) : (
                      <Icon name={step.icon as any} size={20} />
                    )}
                  </div>
                  <p className={`text-xs mt-2 font-medium hidden sm:block ${
                    currentStep >= step.number ? 'text-foreground' : 'text-muted-foreground'
                  }`}>
                    {step.title}
                  </p>
                </div>
                {index < steps.length - 1 && (
                  <div className={`h-0.5 flex-1 mx-2 transition-smooth ${
                    currentStep > step.number ? 'bg-primary' : 'bg-muted'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Step 1: Personal Details */}
          {currentStep === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">First Name *</label>
                  <input
                    type="text"
                    value={formData.personalDetails.firstName}
                    onChange={(e) => handleInputChange('personalDetails', 'firstName', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="Enter first name"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Last Name *</label>
                  <input
                    type="text"
                    value={formData.personalDetails.lastName}
                    onChange={(e) => handleInputChange('personalDetails', 'lastName', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="Enter last name"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Email Address *</label>
                  <input
                    type="email"
                    value={formData.personalDetails.email}
                    onChange={(e) => handleInputChange('personalDetails', 'email', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="email@example.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    value={formData.personalDetails.phone}
                    onChange={(e) => handleInputChange('personalDetails', 'phone', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="+254 700 000 000"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Date of Birth *</label>
                  <input
                    type="date"
                    value={formData.personalDetails.dateOfBirth}
                    onChange={(e) => handleInputChange('personalDetails', 'dateOfBirth', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Occupation *</label>
                  <input
                    type="text"
                    value={formData.personalDetails.occupation}
                    onChange={(e) => handleInputChange('personalDetails', 'occupation', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="Enter occupation"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Monthly Income (KES) *</label>
                <input
                  type="number"
                  value={formData.personalDetails.monthlyIncome}
                  onChange={(e) => handleInputChange('personalDetails', 'monthlyIncome', e.target.value)}
                  className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  placeholder="50000"
                />
              </div>

              <div className="pt-4 border-t border-border">
                <h3 className="text-lg font-heading font-semibold mb-4">Emergency Contact</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Name *</label>
                    <input
                      type="text"
                      value={formData.emergencyContact.name}
                      onChange={(e) => handleInputChange('emergencyContact', 'name', e.target.value)}
                      className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                      placeholder="Contact name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Relationship *</label>
                    <input
                      type="text"
                      value={formData.emergencyContact.relationship}
                      onChange={(e) => handleInputChange('emergencyContact', 'relationship', e.target.value)}
                      className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                      placeholder="e.g., Spouse, Parent"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Phone *</label>
                    <input
                      type="tel"
                      value={formData.emergencyContact.phone}
                      onChange={(e) => handleInputChange('emergencyContact', 'phone', e.target.value)}
                      className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                      placeholder="+254 700 000 000"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 2: KYC Verification */}
          {currentStep === 2 && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">National ID Number *</label>
                  <input
                    type="text"
                    value={formData.personalDetails.nationalId}
                    onChange={(e) => handleInputChange('personalDetails', 'nationalId', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="12345678"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">KRA PIN *</label>
                  <input
                    type="text"
                    value={formData.personalDetails.kraPin}
                    onChange={(e) => handleInputChange('personalDetails', 'kraPin', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="A000000000A"
                  />
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-6 text-center">
                {verificationStatus === 'idle' && (
                  <>
                    <Icon name="ShieldCheckIcon" size={64} className="mx-auto mb-4 text-primary" />
                    <h3 className="text-lg font-heading font-semibold mb-2">KYC Verification</h3>
                    <p className="text-muted-foreground mb-4">
                      We will verify your identity using Metropol/CRB integration and validate your National ID and KRA PIN.
                    </p>
                    <button
                      onClick={handleVerifyKYC}
                      disabled={isVerifying}
                      className="px-6 py-3 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth disabled:opacity-50 font-medium"
                    >
                      {isVerifying ? 'Verifying...' : 'Start Verification'}
                    </button>
                  </>
                )}

                {isVerifying && (
                  <>
                    <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                    <h3 className="text-lg font-heading font-semibold mb-2">Verifying Identity</h3>
                    <p className="text-muted-foreground">Please wait while we verify your documents...</p>
                  </>
                )}

                {verificationStatus === 'success' && (
                  <>
                    <div className="w-16 h-16 bg-success/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Icon name="CheckCircleIcon" size={48} className="text-success" variant="solid" />
                    </div>
                    <h3 className="text-lg font-heading font-semibold mb-2 text-success">Verification Successful</h3>
                    <p className="text-muted-foreground mb-4">
                      Your identity has been verified successfully. You can proceed to the next step.
                    </p>
                    <div className="bg-card rounded-lg p-4 text-left space-y-2">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">National ID:</span>
                        <span className="font-medium">Verified ✓</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">KRA PIN:</span>
                        <span className="font-medium">Verified ✓</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Credit Score:</span>
                        <span className="font-medium text-success">Good (720)</span>
                      </div>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {/* Step 3: Property Details */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Property *</label>
                  <select
                    value={formData.propertyDetails.property}
                    onChange={(e) => handleInputChange('propertyDetails', 'property', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  >
                    <option value="">Select property</option>
                    <option value="Westlands Apartments">Westlands Apartments</option>
                    <option value="Kilimani Heights">Kilimani Heights</option>
                    <option value="Lavington Gardens">Lavington Gardens</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Unit Number *</label>
                  <select
                    value={formData.propertyDetails.unit}
                    onChange={(e) => handleInputChange('propertyDetails', 'unit', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  >
                    <option value="">Select unit</option>
                    <option value="A101">A101 - 2BR</option>
                    <option value="A102">A102 - 3BR</option>
                    <option value="B201">B201 - 1BR</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Monthly Rent (KES) *</label>
                  <input
                    type="number"
                    value={formData.propertyDetails.rentAmount}
                    onChange={(e) => handleInputChange('propertyDetails', 'rentAmount', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                    placeholder="45000"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Lease Start Date *</label>
                  <input
                    type="date"
                    value={formData.propertyDetails.leaseStart}
                    onChange={(e) => handleInputChange('propertyDetails', 'leaseStart', e.target.value)}
                    className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Lease Duration (Months) *</label>
                <select
                  value={formData.propertyDetails.leaseDuration}
                  onChange={(e) => handleInputChange('propertyDetails', 'leaseDuration', e.target.value)}
                  className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
                >
                  <option value="6">6 Months</option>
                  <option value="12">12 Months</option>
                  <option value="24">24 Months</option>
                </select>
              </div>

              <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
                <div className="flex gap-3">
                  <Icon name="InformationCircleIcon" size={24} className="text-primary flex-shrink-0" />
                  <div>
                    <h4 className="font-medium mb-1">Deposit Required</h4>
                    <p className="text-sm text-muted-foreground">
                      A security deposit of 2 months rent will be required before lease signing.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Step 4: Review & Sign */}
          {currentStep === 4 && (
            <div className="space-y-6">
              <div className="bg-muted/50 rounded-lg p-6">
                <h3 className="text-lg font-heading font-semibold mb-4">Lease Agreement Summary</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Tenant Name:</span>
                    <span className="font-medium">{formData.personalDetails.firstName} {formData.personalDetails.lastName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Property:</span>
                    <span className="font-medium">{formData.propertyDetails.property}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Unit:</span>
                    <span className="font-medium">{formData.propertyDetails.unit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Monthly Rent:</span>
                    <span className="font-semibold data-text">KES {parseFloat(formData.propertyDetails.rentAmount || '0').toLocaleString('en-KE', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Lease Duration:</span>
                    <span className="font-medium">{formData.propertyDetails.leaseDuration} Months</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Security Deposit:</span>
                    <span className="font-semibold data-text">KES {(parseFloat(formData.propertyDetails.rentAmount || '0') * 2).toLocaleString('en-KE', { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </div>

              <div className="bg-card border border-border rounded-lg p-6">
                <h4 className="font-medium mb-3">Digital Signature</h4>
                <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
                  <Icon name="PencilSquareIcon" size={48} className="mx-auto mb-3 text-muted-foreground" />
                  <p className="text-muted-foreground mb-4">Sign here to accept the lease agreement</p>
                  <button className="px-6 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth font-medium">
                    Add Signature
                  </button>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-warning/10 border border-warning/20 rounded-lg">
                <Icon name="ExclamationTriangleIcon" size={24} className="text-warning flex-shrink-0" />
                <div>
                  <h4 className="font-medium mb-1">Important Notice</h4>
                  <p className="text-sm text-muted-foreground">
                    By signing this agreement, you acknowledge that you have read and understood all terms and conditions of the lease.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border flex items-center justify-between">
          <button
            onClick={handleBack}
            disabled={currentStep === 1}
            className="px-6 py-2 border border-border rounded-md hover:bg-muted transition-smooth disabled:opacity-50 disabled:cursor-not-allowed font-medium"
          >
            Back
          </button>
          <div className="flex items-center gap-3">
            <button
              onClick={onClose}
              className="px-6 py-2 text-muted-foreground hover:text-foreground transition-smooth font-medium"
            >
              Cancel
            </button>
            {currentStep < 4 ? (
              <button
                onClick={handleNext}
                disabled={currentStep === 2 && verificationStatus !== 'success'}
                className="px-6 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth disabled:opacity-50 disabled:cursor-not-allowed font-medium"
              >
                Next
              </button>
            ) : (
              <button
                onClick={handleComplete}
                className="px-6 py-2 bg-success text-success-foreground rounded-md hover:bg-success/90 transition-smooth font-medium"
              >
                Complete Onboarding
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}