'use client';

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  nationalId: string;
  unit: string;
  property: string;
  leaseStatus: 'active' | 'expiring' | 'expired' | 'pending';
  rentAmount: number;
  paymentStatus: 'paid' | 'pending' | 'overdue';
  leaseStart: string;
  leaseEnd: string;
  avatar?: string;
  kycStatus: 'verified' | 'pending' | 'failed';
  lastPaymentDate?: string;
}

interface TenantTableRowProps {
  tenant: Tenant;
  onViewDetails: (tenant: Tenant) => void;
  onProcessPayment: (tenant: Tenant) => void;
  onManageLease: (tenant: Tenant) => void;
}

export default function TenantTableRow({
  tenant,
  onViewDetails,
  onProcessPayment,
  onManageLease,
}: TenantTableRowProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const getLeaseStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-success/10 text-success';
      case 'expiring':
        return 'bg-warning/10 text-warning';
      case 'expired':
        return 'bg-error/10 text-error';
      case 'pending':
        return 'bg-muted text-muted-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getPaymentStatusColor = (status: string) => {
    switch (status) {
      case 'paid':
        return 'bg-success/10 text-success';
      case 'pending':
        return 'bg-warning/10 text-warning';
      case 'overdue':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const formatCurrency = (amount: number) => {
    return `KES ${amount.toLocaleString('en-KE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  return (
    <>
      {/* Desktop Row */}
      <tr className="hidden lg:table-row border-b border-border hover:bg-muted/50 transition-smooth">
        <td className="px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full overflow-hidden bg-primary/10 flex-shrink-0">
              {tenant.avatar ? (
                <AppImage
                  src={tenant.avatar}
                  alt={`Profile photo of ${tenant.name}, tenant at ${tenant.unit}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-primary font-semibold">
                  {tenant.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                </div>
              )}
            </div>
            <div>
              <p className="font-medium text-foreground">{tenant.name}</p>
              <p className="text-sm text-muted-foreground caption">{tenant.email}</p>
            </div>
          </div>
        </td>
        <td className="px-4 py-4">
          <p className="font-medium text-foreground">{tenant.unit}</p>
          <p className="text-sm text-muted-foreground caption">{tenant.property}</p>
        </td>
        <td className="px-4 py-4">
          <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getLeaseStatusColor(tenant.leaseStatus)}`}>
            {tenant.leaseStatus === 'active' && <Icon name="CheckCircleIcon" size={14} variant="solid" />}
            {tenant.leaseStatus === 'expiring' && <Icon name="ClockIcon" size={14} variant="solid" />}
            {tenant.leaseStatus === 'expired' && <Icon name="XCircleIcon" size={14} variant="solid" />}
            {tenant.leaseStatus === 'pending' && <Icon name="ExclamationCircleIcon" size={14} variant="solid" />}
            {tenant.leaseStatus.charAt(0).toUpperCase() + tenant.leaseStatus.slice(1)}
          </span>
        </td>
        <td className="px-4 py-4">
          <p className="font-semibold text-foreground data-text">{formatCurrency(tenant.rentAmount)}</p>
        </td>
        <td className="px-4 py-4">
          <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(tenant.paymentStatus)}`}>
            {tenant.paymentStatus === 'paid' && <Icon name="CheckCircleIcon" size={14} variant="solid" />}
            {tenant.paymentStatus === 'pending' && <Icon name="ClockIcon" size={14} variant="solid" />}
            {tenant.paymentStatus === 'overdue' && <Icon name="ExclamationCircleIcon" size={14} variant="solid" />}
            {tenant.paymentStatus.charAt(0).toUpperCase() + tenant.paymentStatus.slice(1)}
          </span>
        </td>
        <td className="px-4 py-4">
          <p className="text-sm text-foreground data-text">{formatDate(tenant.leaseEnd)}</p>
        </td>
        <td className="px-4 py-4">
          <div className="flex items-center gap-2">
            <button
              onClick={() => onViewDetails(tenant)}
              className="p-2 rounded-md hover:bg-primary/10 text-primary transition-smooth"
              aria-label={`View details for ${tenant.name}`}
            >
              <Icon name="EyeIcon" size={18} />
            </button>
            <button
              onClick={() => onProcessPayment(tenant)}
              className="p-2 rounded-md hover:bg-success/10 text-success transition-smooth"
              aria-label={`Process payment for ${tenant.name}`}
            >
              <Icon name="CreditCardIcon" size={18} />
            </button>
            <button
              onClick={() => onManageLease(tenant)}
              className="p-2 rounded-md hover:bg-warning/10 text-warning transition-smooth"
              aria-label={`Manage lease for ${tenant.name}`}
            >
              <Icon name="DocumentTextIcon" size={18} />
            </button>
          </div>
        </td>
      </tr>

      {/* Mobile Card */}
      <div className="lg:hidden border border-border rounded-lg p-4 bg-card mb-3">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-3 flex-1">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-primary/10 flex-shrink-0">
              {tenant.avatar ? (
                <AppImage
                  src={tenant.avatar}
                  alt={`Profile photo of ${tenant.name}, tenant at ${tenant.unit}`}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-primary font-semibold">
                  {tenant.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-foreground">{tenant.name}</p>
              <p className="text-sm text-muted-foreground caption truncate">{tenant.email}</p>
            </div>
          </div>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-2 rounded-md hover:bg-muted transition-smooth flex-shrink-0"
            aria-label={isExpanded ? 'Collapse details' : 'Expand details'}
          >
            <Icon name={isExpanded ? 'ChevronUpIcon' : 'ChevronDownIcon'} size={20} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <p className="text-xs text-muted-foreground caption mb-1">Unit</p>
            <p className="font-medium text-sm">{tenant.unit}</p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground caption mb-1">Rent Amount</p>
            <p className="font-semibold text-sm data-text">{formatCurrency(tenant.rentAmount)}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 mb-3">
          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getLeaseStatusColor(tenant.leaseStatus)}`}>
            {tenant.leaseStatus.charAt(0).toUpperCase() + tenant.leaseStatus.slice(1)}
          </span>
          <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getPaymentStatusColor(tenant.paymentStatus)}`}>
            {tenant.paymentStatus.charAt(0).toUpperCase() + tenant.paymentStatus.slice(1)}
          </span>
        </div>

        {isExpanded && (
          <div className="pt-3 border-t border-border space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground caption">Property:</span>
              <span className="font-medium">{tenant.property}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground caption">Lease End:</span>
              <span className="font-medium data-text">{formatDate(tenant.leaseEnd)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground caption">Phone:</span>
              <span className="font-medium data-text">{tenant.phone}</span>
            </div>
          </div>
        )}

        <div className="flex items-center gap-2 pt-3 border-t border-border mt-3">
          <button
            onClick={() => onViewDetails(tenant)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth"
          >
            <Icon name="EyeIcon" size={18} />
            <span className="text-sm font-medium">View</span>
          </button>
          <button
            onClick={() => onProcessPayment(tenant)}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-success text-success-foreground rounded-md hover:bg-success/90 transition-smooth"
          >
            <Icon name="CreditCardIcon" size={18} />
            <span className="text-sm font-medium">Pay</span>
          </button>
          <button
            onClick={() => onManageLease(tenant)}
            className="p-2 border border-border rounded-md hover:bg-muted transition-smooth"
            aria-label={`Manage lease for ${tenant.name}`}
          >
            <Icon name="DocumentTextIcon" size={20} />
          </button>
        </div>
      </div>
    </>
  );
}