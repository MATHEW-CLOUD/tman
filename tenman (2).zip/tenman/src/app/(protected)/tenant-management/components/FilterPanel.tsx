'use client';

import Icon from '@/components/ui/AppIcon';

interface FilterPanelProps {
  filters: {
    property: string;
    paymentStatus: string;
    leaseStatus: string;
    searchQuery: string;
  };
  onFilterChange: (key: string, value: string) => void;
  onClearFilters: () => void;
}

export default function FilterPanel({ filters, onFilterChange, onClearFilters }: FilterPanelProps) {
  const hasActiveFilters = filters.property || filters.paymentStatus || filters.leaseStatus || filters.searchQuery;

  return (
    <div className="bg-card rounded-lg border border-border p-4 lg:p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-heading font-semibold text-lg">Filters</h3>
        {hasActiveFilters && (
          <button
            onClick={onClearFilters}
            className="text-sm text-primary hover:text-primary/80 transition-smooth font-medium"
          >
            Clear All
          </button>
        )}
      </div>

      {/* Search */}
      <div>
        <label className="block text-sm font-medium mb-2">Search Tenant</label>
        <div className="relative">
          <Icon name="MagnifyingGlassIcon" size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={(e) => onFilterChange('searchQuery', e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
            placeholder="Search by name, email, or unit"
          />
        </div>
      </div>

      {/* Property Filter */}
      <div>
        <label className="block text-sm font-medium mb-2">Property</label>
        <select
          value={filters.property}
          onChange={(e) => onFilterChange('property', e.target.value)}
          className="w-full px-4 py-2 border border-input rounded-md focus:outline-none focus:ring-2 focus:ring-ring bg-background"
        >
          <option value="">All Properties</option>
          <option value="Westlands Apartments">Westlands Apartments</option>
          <option value="Kilimani Heights">Kilimani Heights</option>
          <option value="Lavington Gardens">Lavington Gardens</option>
          <option value="Parklands Residences">Parklands Residences</option>
        </select>
      </div>

      {/* Payment Status Filter */}
      <div>
        <label className="block text-sm font-medium mb-2">Payment Status</label>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="paymentStatus"
              value=""
              checked={filters.paymentStatus === ''}
              onChange={(e) => onFilterChange('paymentStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">All</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="paymentStatus"
              value="paid"
              checked={filters.paymentStatus === 'paid'}
              onChange={(e) => onFilterChange('paymentStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">Paid</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="paymentStatus"
              value="pending"
              checked={filters.paymentStatus === 'pending'}
              onChange={(e) => onFilterChange('paymentStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">Pending</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="paymentStatus"
              value="overdue"
              checked={filters.paymentStatus === 'overdue'}
              onChange={(e) => onFilterChange('paymentStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">Overdue</span>
          </label>
        </div>
      </div>

      {/* Lease Status Filter */}
      <div>
        <label className="block text-sm font-medium mb-2">Lease Status</label>
        <div className="space-y-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="leaseStatus"
              value=""
              checked={filters.leaseStatus === ''}
              onChange={(e) => onFilterChange('leaseStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">All</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="leaseStatus"
              value="active"
              checked={filters.leaseStatus === 'active'}
              onChange={(e) => onFilterChange('leaseStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">Active</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="leaseStatus"
              value="expiring"
              checked={filters.leaseStatus === 'expiring'}
              onChange={(e) => onFilterChange('leaseStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">Expiring Soon</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="radio"
              name="leaseStatus"
              value="expired"
              checked={filters.leaseStatus === 'expired'}
              onChange={(e) => onFilterChange('leaseStatus', e.target.value)}
              className="w-4 h-4 text-primary focus:ring-2 focus:ring-ring"
            />
            <span className="text-sm">Expired</span>
          </label>
        </div>
      </div>
    </div>
  );
}