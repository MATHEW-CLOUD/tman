'use client';

import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  nationalId: string;
  unit: string;
  property: string;
  leaseStatus: 'active' | 'expiring' | 'expired' | 'pending';
  rentAmount: number;
  paymentStatus: 'paid' | 'pending' | 'overdue';
  leaseStart: string;
  leaseEnd: string;
  avatar?: string;
  kycStatus: 'verified' | 'pending' | 'failed';
  lastPaymentDate?: string;
  kraPin?: string;
  emergencyContact?: string;
  occupation?: string;
  monthlyIncome?: number;
}

interface PaymentHistory {
  id: string;
  date: string;
  amount: number;
  method: string;
  status: 'completed' | 'pending' | 'failed';
  reference: string;
}

interface MaintenanceRequest {
  id: string;
  title: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  status: 'open' | 'in-progress' | 'resolved';
  date: string;
}

interface TenantDetailsPanelProps {
  tenant: Tenant | null;
  paymentHistory: PaymentHistory[];
  maintenanceRequests: MaintenanceRequest[];
  onClose: () => void;
}

export default function TenantDetailsPanel({
  tenant,
  paymentHistory,
  maintenanceRequests,
  onClose,
}: TenantDetailsPanelProps) {
  if (!tenant) return null;

  const formatCurrency = (amount: number) => {
    return `KES ${amount.toLocaleString('en-KE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  const getKycStatusColor = (status: string) => {
    switch (status) {
      case 'verified':
        return 'bg-success/10 text-success';
      case 'pending':
        return 'bg-warning/10 text-warning';
      case 'failed':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-error/10 text-error';
      case 'medium':
        return 'bg-warning/10 text-warning';
      case 'low':
        return 'bg-success/10 text-success';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
      case 'resolved':
        return 'bg-success/10 text-success';
      case 'pending': case'in-progress':
        return 'bg-warning/10 text-warning';
      case 'failed': case'open':
        return 'bg-error/10 text-error';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <div className="fixed inset-0 z-50 lg:relative lg:inset-auto bg-background lg:bg-transparent">
      <div className="h-full overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-card border-b border-border p-4 lg:p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-heading font-semibold">Tenant Details</h2>
            <button
              onClick={onClose}
              className="p-2 rounded-md hover:bg-muted transition-smooth"
              aria-label="Close tenant details"
            >
              <Icon name="XMarkIcon" size={24} />
            </button>
          </div>
        </div>

        <div className="p-4 lg:p-6 space-y-6">
          {/* Profile Section */}
          <div className="bg-card rounded-lg border border-border p-6">
            <div className="flex items-start gap-4 mb-6">
              <div className="w-20 h-20 rounded-full overflow-hidden bg-primary/10 flex-shrink-0">
                {tenant.avatar ? (
                  <AppImage
                    src={tenant.avatar}
                    alt={`Profile photo of ${tenant.name}, tenant at ${tenant.unit}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-primary font-semibold text-2xl">
                    {tenant.name.split(' ').map(n => n[0]).join('').toUpperCase()}
                  </div>
                )}
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-heading font-semibold mb-1">{tenant.name}</h3>
                <p className="text-muted-foreground caption mb-2">{tenant.email}</p>
                <div className="flex items-center gap-2">
                  <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getKycStatusColor(tenant.kycStatus)}`}>
                    {tenant.kycStatus === 'verified' && <Icon name="CheckCircleIcon" size={14} variant="solid" />}
                    {tenant.kycStatus === 'pending' && <Icon name="ClockIcon" size={14} variant="solid" />}
                    {tenant.kycStatus === 'failed' && <Icon name="XCircleIcon" size={14} variant="solid" />}
                    KYC {tenant.kycStatus.charAt(0).toUpperCase() + tenant.kycStatus.slice(1)}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Phone Number</p>
                <p className="font-medium data-text">{tenant.phone}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">National ID</p>
                <p className="font-medium data-text">{tenant.nationalId}</p>
              </div>
              {tenant.kraPin && (
                <div>
                  <p className="text-sm text-muted-foreground caption mb-1">KRA PIN</p>
                  <p className="font-medium data-text">{tenant.kraPin}</p>
                </div>
              )}
              {tenant.occupation && (
                <div>
                  <p className="text-sm text-muted-foreground caption mb-1">Occupation</p>
                  <p className="font-medium">{tenant.occupation}</p>
                </div>
              )}
              {tenant.monthlyIncome && (
                <div>
                  <p className="text-sm text-muted-foreground caption mb-1">Monthly Income</p>
                  <p className="font-medium data-text">{formatCurrency(tenant.monthlyIncome)}</p>
                </div>
              )}
              {tenant.emergencyContact && (
                <div>
                  <p className="text-sm text-muted-foreground caption mb-1">Emergency Contact</p>
                  <p className="font-medium data-text">{tenant.emergencyContact}</p>
                </div>
              )}
            </div>
          </div>

          {/* Lease Information */}
          <div className="bg-card rounded-lg border border-border p-6">
            <h3 className="text-lg font-heading font-semibold mb-4">Lease Information</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Property</p>
                <p className="font-medium">{tenant.property}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Unit Number</p>
                <p className="font-medium">{tenant.unit}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Rent Amount</p>
                <p className="font-semibold text-lg data-text">{formatCurrency(tenant.rentAmount)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Payment Status</p>
                <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(tenant.paymentStatus)}`}>
                  {tenant.paymentStatus.charAt(0).toUpperCase() + tenant.paymentStatus.slice(1)}
                </span>
              </div>
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Lease Start</p>
                <p className="font-medium data-text">{formatDate(tenant.leaseStart)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground caption mb-1">Lease End</p>
                <p className="font-medium data-text">{formatDate(tenant.leaseEnd)}</p>
              </div>
            </div>
          </div>

          {/* Payment History */}
          <div className="bg-card rounded-lg border border-border p-6">
            <h3 className="text-lg font-heading font-semibold mb-4">Payment History</h3>
            {paymentHistory.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Icon name="CreditCardIcon" size={48} className="mx-auto mb-2 opacity-50" />
                <p>No payment history available</p>
              </div>
            ) : (
              <div className="space-y-3">
                {paymentHistory.map((payment) => (
                  <div key={payment.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium data-text">{formatCurrency(payment.amount)}</p>
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${getStatusColor(payment.status)}`}>
                          {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground caption">{payment.method} • {payment.reference}</p>
                    </div>
                    <p className="text-sm text-muted-foreground caption">{formatDate(payment.date)}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Maintenance Requests */}
          <div className="bg-card rounded-lg border border-border p-6">
            <h3 className="text-lg font-heading font-semibold mb-4">Maintenance Requests</h3>
            {maintenanceRequests.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Icon name="WrenchScrewdriverIcon" size={48} className="mx-auto mb-2 opacity-50" />
                <p>No maintenance requests</p>
              </div>
            ) : (
              <div className="space-y-3">
                {maintenanceRequests.map((request) => (
                  <div key={request.id} className="p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <p className="font-medium mb-1">{request.title}</p>
                        <p className="text-sm text-muted-foreground caption">{request.category}</p>
                      </div>
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(request.priority)}`}>
                        {request.priority.charAt(0).toUpperCase() + request.priority.slice(1)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(request.status)}`}>
                        {request.status.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                      </span>
                      <p className="text-sm text-muted-foreground caption">{formatDate(request.date)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}