'use client';

import Icon from '@/components/ui/AppIcon';

interface BulkActionsBarProps {
  selectedCount: number;
  onSendReminders: () => void;
  onSendSMS: () => void;
  onExport: () => void;
  onClearSelection: () => void;
}

export default function BulkActionsBar({
  selectedCount,
  onSendReminders,
  onSendSMS,
  onExport,
  onClearSelection,
}: BulkActionsBarProps) {
  if (selectedCount === 0) return null;

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 animate-slide-up">
      <div className="bg-card border border-border rounded-lg shadow-warm-xl p-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold text-sm">
              {selectedCount}
            </div>
            <span className="font-medium">
              {selectedCount} tenant{selectedCount > 1 ? 's' : ''} selected
            </span>
          </div>

          <div className="h-6 w-px bg-border" />

          <div className="flex items-center gap-2">
            <button
              onClick={onSendReminders}
              className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth"
            >
              <Icon name="BellIcon" size={18} />
              <span className="text-sm font-medium hidden sm:inline">Send Reminders</span>
            </button>

            <button
              onClick={onSendSMS}
              className="flex items-center gap-2 px-4 py-2 bg-success text-success-foreground rounded-md hover:bg-success/90 transition-smooth"
            >
              <Icon name="ChatBubbleLeftRightIcon" size={18} />
              <span className="text-sm font-medium hidden sm:inline">Send SMS</span>
            </button>

            <button
              onClick={onExport}
              className="flex items-center gap-2 px-4 py-2 border border-border rounded-md hover:bg-muted transition-smooth"
            >
              <Icon name="ArrowDownTrayIcon" size={18} />
              <span className="text-sm font-medium hidden sm:inline">Export</span>
            </button>

            <button
              onClick={onClearSelection}
              className="p-2 rounded-md hover:bg-muted transition-smooth"
              aria-label="Clear selection"
            >
              <Icon name="XMarkIcon" size={20} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}