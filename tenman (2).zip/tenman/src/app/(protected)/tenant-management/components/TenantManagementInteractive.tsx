'use client';

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';
import TenantTableRow from './TenantTableRow';
import TenantDetailsPanel from './TenantDetailsPanel';
import OnboardingModal from './OnboardingModal';
import PaymentModal from './PaymentModal';
import BulkActionsBar from './BulkActionsBar';
import FilterPanel from './FilterPanel';

interface Tenant {
  id: string;
  name: string;
  email: string;
  phone: string;
  nationalId: string;
  unit: string;
  property: string;
  leaseStatus: 'active' | 'expiring' | 'expired' | 'pending';
  rentAmount: number;
  paymentStatus: 'paid' | 'pending' | 'overdue';
  leaseStart: string;
  leaseEnd: string;
  avatar?: string;
  kycStatus: 'verified' | 'pending' | 'failed';
  lastPaymentDate?: string;
  kraPin?: string;
  emergencyContact?: string;
  occupation?: string;
  monthlyIncome?: number;
}

interface PaymentHistory {
  id: string;
  date: string;
  amount: number;
  method: string;
  status: 'completed' | 'pending' | 'failed';
  reference: string;
}

interface MaintenanceRequest {
  id: string;
  title: string;
  category: string;
  priority: 'high' | 'medium' | 'low';
  status: 'open' | 'in-progress' | 'resolved';
  date: string;
}

interface OnboardingData {
  personalDetails: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    nationalId: string;
    kraPin: string;
    dateOfBirth: string;
    occupation: string;
    monthlyIncome: string;
  };
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };
  propertyDetails: {
    property: string;
    unit: string;
    rentAmount: string;
    leaseStart: string;
    leaseDuration: string;
  };
}

interface PaymentData {
  tenantId: string;
  amount: number;
  method: string;
  reference: string;
  status: 'completed' | 'pending' | 'failed';
}

export default function TenantManagementInteractive() {
  const [isHydrated, setIsHydrated] = useState(false);
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [selectedTenant, setSelectedTenant] = useState<Tenant | null>(null);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(false);
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentTenant, setPaymentTenant] = useState<Tenant | null>(null);
  const [selectedTenants, setSelectedTenants] = useState<string[]>([]);
  const [filters, setFilters] = useState({
    property: '',
    paymentStatus: '',
    leaseStatus: '',
    searchQuery: '',
  });

  useEffect(() => {
    setIsHydrated(true);
    
    // Mock tenant data
    const mockTenants: Tenant[] = [
      {
        id: '1',
        name: 'Sarah Wanjiku',
        email: 'sarah.wanjiku@email.com',
        phone: '+254 712 345 678',
        nationalId: '12345678',
        kraPin: 'A001234567B',
        unit: 'A101',
        property: 'Westlands Apartments',
        leaseStatus: 'active',
        rentAmount: 45000,
        paymentStatus: 'paid',
        leaseStart: '2024-01-01',
        leaseEnd: '2025-01-01',
        avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg',
        kycStatus: 'verified',
        lastPaymentDate: '2026-01-05',
        occupation: 'Software Engineer',
        monthlyIncome: 150000,
        emergencyContact: '+254 722 111 222',
      },
      {
        id: '2',
        name: 'James Omondi',
        email: 'james.omondi@email.com',
        phone: '+254 723 456 789',
        nationalId: '23456789',
        kraPin: 'A002345678C',
        unit: 'B205',
        property: 'Kilimani Heights',
        leaseStatus: 'active',
        rentAmount: 55000,
        paymentStatus: 'pending',
        leaseStart: '2024-03-01',
        leaseEnd: '2025-03-01',
        avatar: 'https://images.pixabay.com/photo/2016/11/21/12/42/beard-1845166_1280.jpg',
        kycStatus: 'verified',
        occupation: 'Business Analyst',
        monthlyIncome: 180000,
        emergencyContact: '+254 733 222 333',
      },
      {
        id: '3',
        name: 'Grace Muthoni',
        email: 'grace.muthoni@email.com',
        phone: '+254 734 567 890',
        nationalId: '34567890',
        kraPin: 'A003456789D',
        unit: 'C302',
        property: 'Lavington Gardens',
        leaseStatus: 'expiring',
        rentAmount: 65000,
        paymentStatus: 'paid',
        leaseStart: '2024-02-01',
        leaseEnd: '2026-02-28',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330',
        kycStatus: 'verified',
        lastPaymentDate: '2026-01-10',
        occupation: 'Marketing Manager',
        monthlyIncome: 200000,
        emergencyContact: '+254 744 333 444',
      },
      {
        id: '4',
        name: 'Peter Kamau',
        email: 'peter.kamau@email.com',
        phone: '+254 745 678 901',
        nationalId: '45678901',
        unit: 'A203',
        property: 'Westlands Apartments',
        leaseStatus: 'active',
        rentAmount: 48000,
        paymentStatus: 'overdue',
        leaseStart: '2024-04-01',
        leaseEnd: '2025-04-01',
        kycStatus: 'verified',
        occupation: 'Accountant',
        monthlyIncome: 120000,
        emergencyContact: '+254 755 444 555',
      },
      {
        id: '5',
        name: 'Lucy Akinyi',
        email: 'lucy.akinyi@email.com',
        phone: '+254 756 789 012',
        nationalId: '56789012',
        kraPin: 'A005678901F',
        unit: 'D101',
        property: 'Parklands Residences',
        leaseStatus: 'active',
        rentAmount: 52000,
        paymentStatus: 'paid',
        leaseStart: '2024-05-01',
        leaseEnd: '2025-05-01',
        avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
        kycStatus: 'verified',
        lastPaymentDate: '2026-01-08',
        occupation: 'Teacher',
        monthlyIncome: 95000,
        emergencyContact: '+254 766 555 666',
      },
    ];

    setTenants(mockTenants);
  }, []);

  const mockPaymentHistory: PaymentHistory[] = [
    {
      id: '1',
      date: '2026-01-05',
      amount: 45000,
      method: 'M-Pesa',
      status: 'completed',
      reference: 'TXN1704441600000',
    },
    {
      id: '2',
      date: '2025-12-05',
      amount: 45000,
      method: 'M-Pesa',
      status: 'completed',
      reference: 'TXN1701763200000',
    },
    {
      id: '3',
      date: '2025-11-05',
      amount: 45000,
      method: 'Airtel Money',
      status: 'completed',
      reference: 'TXN1699171200000',
    },
  ];

  const mockMaintenanceRequests: MaintenanceRequest[] = [
    {
      id: '1',
      title: 'Leaking kitchen sink',
      category: 'Plumbing',
      priority: 'high',
      status: 'in-progress',
      date: '2026-01-15',
    },
    {
      id: '2',
      title: 'Broken window lock',
      category: 'Carpentry',
      priority: 'medium',
      status: 'open',
      date: '2026-01-18',
    },
  ];

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-background pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-muted rounded w-1/4" />
            <div className="h-64 bg-muted rounded" />
          </div>
        </div>
      </div>
    );
  }

  const handleFilterChange = (key: string, value: string) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  const handleClearFilters = () => {
    setFilters({
      property: '',
      paymentStatus: '',
      leaseStatus: '',
      searchQuery: '',
    });
  };

  const filteredTenants = tenants.filter(tenant => {
    if (filters.property && tenant.property !== filters.property) return false;
    if (filters.paymentStatus && tenant.paymentStatus !== filters.paymentStatus) return false;
    if (filters.leaseStatus && tenant.leaseStatus !== filters.leaseStatus) return false;
    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      return (
        tenant.name.toLowerCase().includes(query) ||
        tenant.email.toLowerCase().includes(query) ||
        tenant.unit.toLowerCase().includes(query)
      );
    }
    return true;
  });

  const handleViewDetails = (tenant: Tenant) => {
    setSelectedTenant(tenant);
  };

  const handleProcessPayment = (tenant: Tenant) => {
    setPaymentTenant(tenant);
    setIsPaymentModalOpen(true);
  };

  const handleManageLease = (tenant: Tenant) => {
    alert(`Manage lease for ${tenant.name}`);
  };

  const handleOnboardingComplete = (data: OnboardingData) => {
    const newTenant: Tenant = {
      id: Date.now().toString(),
      name: `${data.personalDetails.firstName} ${data.personalDetails.lastName}`,
      email: data.personalDetails.email,
      phone: data.personalDetails.phone,
      nationalId: data.personalDetails.nationalId,
      kraPin: data.personalDetails.kraPin,
      unit: data.propertyDetails.unit,
      property: data.propertyDetails.property,
      leaseStatus: 'pending',
      rentAmount: parseFloat(data.propertyDetails.rentAmount),
      paymentStatus: 'pending',
      leaseStart: data.propertyDetails.leaseStart,
      leaseEnd: new Date(new Date(data.propertyDetails.leaseStart).setMonth(
        new Date(data.propertyDetails.leaseStart).getMonth() + parseInt(data.propertyDetails.leaseDuration)
      )).toISOString().split('T')[0],
      kycStatus: 'verified',
      occupation: data.personalDetails.occupation,
      monthlyIncome: parseFloat(data.personalDetails.monthlyIncome),
      emergencyContact: data.emergencyContact.phone,
    };

    setTenants(prev => [newTenant, ...prev]);
    alert('Tenant onboarding completed successfully!');
  };

  const handlePaymentComplete = (paymentData: PaymentData) => {
    setTenants(prev => prev.map(tenant => 
      tenant.id === paymentData.tenantId
        ? { ...tenant, paymentStatus: 'paid' as const, lastPaymentDate: new Date().toISOString().split('T')[0] }
        : tenant
    ));
    alert('Payment processed successfully!');
  };

  const handleToggleSelection = (tenantId: string) => {
    setSelectedTenants(prev =>
      prev.includes(tenantId)
        ? prev.filter(id => id !== tenantId)
        : [...prev, tenantId]
    );
  };

  const handleSelectAll = () => {
    if (selectedTenants.length === filteredTenants.length) {
      setSelectedTenants([]);
    } else {
      setSelectedTenants(filteredTenants.map(t => t.id));
    }
  };

  const handleSendReminders = () => {
    alert(`Sending rent reminders to ${selectedTenants.length} tenant(s)`);
    setSelectedTenants([]);
  };

  const handleSendSMS = () => {
    alert(`Sending SMS to ${selectedTenants.length} tenant(s) via Africa's Talking API`);
    setSelectedTenants([]);
  };

  const handleExport = () => {
    alert(`Exporting data for ${selectedTenants.length} tenant(s)`);
  };

  return (
    <>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Filters - Left Sidebar */}
        <div className="lg:col-span-1">
          <FilterPanel
            filters={filters}
            onFilterChange={handleFilterChange}
            onClearFilters={handleClearFilters}
          />
        </div>

        {/* Main Content */}
        <div className={`${selectedTenant ? 'lg:col-span-2' : 'lg:col-span-3'}`}>
          <div className="bg-card rounded-lg border border-border overflow-hidden">
            {/* Header */}
            <div className="p-4 lg:p-6 border-b border-border">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                  <h2 className="text-xl font-heading font-semibold mb-1">All Tenants</h2>
                  <p className="text-sm text-muted-foreground caption">
                    {filteredTenants.length} tenant{filteredTenants.length !== 1 ? 's' : ''} found
                  </p>
                </div>
                <button
                  onClick={() => setIsOnboardingOpen(true)}
                  className="flex items-center justify-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth font-medium"
                >
                  <Icon name="PlusIcon" size={20} />
                  <span>Add Tenant</span>
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full hidden lg:table">
                <thead className="bg-muted/50 border-b border-border">
                  <tr>
                    <th className="px-4 py-3 text-left">
                      <input
                        type="checkbox"
                        checked={selectedTenants.length === filteredTenants.length && filteredTenants.length > 0}
                        onChange={handleSelectAll}
                        className="w-4 h-4 rounded border-input"
                      />
                    </th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Tenant</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Unit</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Lease Status</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Rent Amount</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Payment</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Lease End</th>
                    <th className="px-4 py-3 text-left text-sm font-medium text-muted-foreground">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTenants.map(tenant => (
                    <tr key={tenant.id}>
                      <td className="px-4 py-4">
                        <input
                          type="checkbox"
                          checked={selectedTenants.includes(tenant.id)}
                          onChange={() => handleToggleSelection(tenant.id)}
                          className="w-4 h-4 rounded border-input"
                        />
                      </td>
                      <td colSpan={7} className="p-0">
                        <TenantTableRow
                          tenant={tenant}
                          onViewDetails={handleViewDetails}
                          onProcessPayment={handleProcessPayment}
                          onManageLease={handleManageLease}
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Mobile View */}
              <div className="lg:hidden p-4 space-y-3">
                {filteredTenants.map(tenant => (
                  <div key={tenant.id} className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={selectedTenants.includes(tenant.id)}
                      onChange={() => handleToggleSelection(tenant.id)}
                      className="w-4 h-4 rounded border-input mt-5"
                    />
                    <div className="flex-1">
                      <TenantTableRow
                        tenant={tenant}
                        onViewDetails={handleViewDetails}
                        onProcessPayment={handleProcessPayment}
                        onManageLease={handleManageLease}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {filteredTenants.length === 0 && (
              <div className="p-12 text-center">
                <Icon name="UsersIcon" size={64} className="mx-auto mb-4 text-muted-foreground opacity-50" />
                <h3 className="text-lg font-heading font-semibold mb-2">No tenants found</h3>
                <p className="text-muted-foreground mb-4">
                  {filters.searchQuery || filters.property || filters.paymentStatus || filters.leaseStatus
                    ? 'Try adjusting your filters' :'Get started by adding your first tenant'}
                </p>
                <button
                  onClick={() => setIsOnboardingOpen(true)}
                  className="px-6 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-smooth font-medium"
                >
                  Add Tenant
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Details Panel - Right Sidebar */}
        {selectedTenant && (
          <div className="lg:col-span-1">
            <TenantDetailsPanel
              tenant={selectedTenant}
              paymentHistory={mockPaymentHistory}
              maintenanceRequests={mockMaintenanceRequests}
              onClose={() => setSelectedTenant(null)}
            />
          </div>
        )}
      </div>

      {/* Modals */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onClose={() => setIsOnboardingOpen(false)}
        onComplete={handleOnboardingComplete}
      />

      <PaymentModal
        isOpen={isPaymentModalOpen}
        tenant={paymentTenant}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPaymentTenant(null);
        }}
        onPaymentComplete={handlePaymentComplete}
      />

      {/* Bulk Actions Bar */}
      <BulkActionsBar
        selectedCount={selectedTenants.length}
        onSendReminders={handleSendReminders}
        onSendSMS={handleSendSMS}
        onExport={handleExport}
        onClearSelection={() => setSelectedTenants([])}
      />
    </>
  );
}