// src/app/dashboard/page.tsx
import { redirect } from 'next/navigation';
import { getCurrentUser } from '@/lib/auth';
import { pathForRole } from '@/lib/roles';

export const dynamic = 'force-dynamic';

export default async function DashboardRouter() {
  const me = await getCurrentUser();
  if (!me) {
    redirect('/login');
  }
  redirect(pathForRole(me.primaryRole));
}