// src/app/(public)/layout.tsx
import React from 'react';

export const metadata = {
  title: 'TenantMaster',
};

export default function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh flex items-center justify-center bg-background text-foreground">
      {children}
    </div>
  );
}