import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { assertAuth, ensureOrgAccess, requireRole, userOrgIds } from '@/lib/authz';
import { getInvoiceOrgId } from '@/lib/org';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const CreateSchema = z.object({
  leaseId: z.string().min(1),
  amount: z.number().positive(),
  dueDate: z.string().datetime(),
  description: z.string().optional(),
  reference: z.string().optional(),
});

export async function GET(req: Request) {
  const me = await getCurrentUser();
  assertAuth(me);

  const url = new URL(req.url);
  const status = url.searchParams.get('status') ?? undefined;
  const tenantId = url.searchParams.get('tenantId') ?? undefined;

  try {
    const where: any = {};

    if (status) where.status = status;
    // Scope by org(s)
    where.organizationId = { in: userOrgIds(me) };

    // Tenants can only see their own invoices
    if (me.primaryRole === 'TENANT') {
      where.lease = { tenantUserId: me.id };
    } else if (tenantId) {
      where.lease = { tenantUserId: tenantId };
    }

    const invoices = await prisma.invoice.findMany({
      where,
      orderBy: { dueDate: 'asc' },
      select: {
        id: true,
        organizationId: true,
        leaseId: true,
        reference: true,
        description: true,
        amount: true,
        dueDate: true,
        status: true,
        issuedAt: true,
        lease: {
          select: {
            tenant: { select: { id: true, name: true, email: true } },
            unit: {
              select: {
                unitNumber: true,
                property: { select: { id: true, name: true } },
              },
            },
          },
        },
        payments: {
          select: {
            id: true,
            amount: true,
            method: true,
            status: true,
            paidAt: true,
            mpesaReceipt: true,
          },
        },
      },
    });

    return NextResponse.json({ ok: true, data: invoices });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? 'Error' }, { status: e?.status ?? 500 });
  }
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  assertAuth(me);
  requireRole(me, ['ADMIN', 'MANAGER']);

  try {
    const body = await req.json();
    const { leaseId, amount, dueDate, description, reference } = CreateSchema.parse(body);

    const orgId = await getInvoiceOrgId(leaseId);
    if (!orgId) throw new Error('Lease not found');
    ensureOrgAccess(me, orgId);

    const invoice = await prisma.invoice.create({
      data: {
        organizationId: orgId,
        leaseId,
        amount,
        dueDate: new Date(dueDate),
        description,
        reference: reference ?? '',
        status: 'PENDING',
      },
    });

    return NextResponse.json({ ok: true, data: invoice });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? 'Error' }, { status: e?.status ?? 400 });
  }
}