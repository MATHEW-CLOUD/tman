import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { assertAuth, ensureOrgAccess, requireRole } from '@/lib/authz';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const UpdateSchema = z.object({
  description: z.string().optional(),
  reference: z.string().optional(),
  status: z.enum(['DRAFT', 'PENDING', 'PARTIALLY_PAID', 'PAID', 'VOID']).optional(),
  dueDate: z.string().datetime().optional(),
  amount: z.number().positive().optional(),
});

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  assertAuth(me);

  const inv = await prisma.invoice.findUnique({
    where: { id: params.id },
    include: {
      lease: {
        select: {
          tenant: { select: { id: true, name: true, email: true } },
          unit: {
            select: { unitNumber: true, property: { select: { id: true, name: true, organizationId: true } } },
          },
        },
      },
      payments: true,
    },
  });
  if (!inv) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 });

  ensureOrgAccess(me, inv.organizationId);

  // Tenants can only read their own
  if (me.primaryRole === 'TENANT' && inv.lease.tenant.id !== me.id) {
    return NextResponse.json({ ok: false, error: 'Forbidden' }, { status: 403 });
  }

  return NextResponse.json({ ok: true, data: inv });
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  assertAuth(me);
  requireRole(me, ['ADMIN', 'MANAGER']);

  const inv = await prisma.invoice.findUnique({ where: { id: params.id } });
  if (!inv) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 });
  ensureOrgAccess(me, inv.organizationId);

  try {
    const patch = UpdateSchema.parse(await req.json());
    const updated = await prisma.invoice.update({
      where: { id: params.id },
      data: {
        ...('description' in patch ? { description: patch.description } : {}),
        ...('reference' in patch ? { reference: patch.reference ?? '' } : {}),
        ...('status' in patch ? { status: patch.status } : {}),
        ...('dueDate' in patch ? { dueDate: patch.dueDate ? new Date(patch.dueDate) : undefined } : {}),
        ...('amount' in patch ? { amount: patch.amount } : {}),
      },
    });
    return NextResponse.json({ ok: true, data: updated });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? 'Error' }, { status: 400 });
  }
}

export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  assertAuth(me);
  requireRole(me, ['ADMIN', 'MANAGER']);

  const inv = await prisma.invoice.findUnique({ where: { id: params.id } });
  if (!inv) return NextResponse.json({ ok: false, error: 'Not found' }, { status: 404 });
  ensureOrgAccess(me, inv.organizationId);

  await prisma.payment.deleteMany({ where: { invoiceId: inv.id } });
  await prisma.invoice.delete({ where: { id: inv.id } });
  return NextResponse.json({ ok: true });
}
