// src/app/api/auth/logout/route.ts
import { NextResponse } from 'next/server';
import { verifyJwt } from '@/lib/jwt';
import { clearSessionCookie, revokeSession } from '@/lib/auth';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const cookie = req.headers.get('cookie') || '';
  const token = cookie.split(';').find((c) => c.trim().startsWith('session='))?.split('=')[1];

  const res = NextResponse.json({ ok: true });
  if (token) {
    try {
      const payload = await verifyJwt<{ jti: string }>(token);
      if (payload?.jti) {
        await revokeSession(payload.jti);
      }
    } catch {}
  }
  clearSessionCookie(res);
  return res;
}