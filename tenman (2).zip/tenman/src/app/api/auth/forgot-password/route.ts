// src/app/api/auth/forgot-password/route.ts
import { NextResponse } from 'next/server';
import { z } from 'zod';
import crypto from 'node:crypto';
import { prisma } from '@/lib/prisma';
import { sendEmailDev } from '@/lib/email';

export const runtime = 'nodejs';

const BodySchema = z.object({
  email: z.string().email(),
});

export async function POST(req: Request) {
  const { email } = BodySchema.parse(await req.json());

  // Always respond 200 to avoid enumeration
  const user = await prisma.user.findUnique({ where: { email } });
  if (user) {
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

    await prisma.verificationToken.create({
      data: {
        type: 'PASSWORD_RESET',
        token,
        identifierEmail: email,
        expiresAt,
      },
    });

    const url = `${process.env.APP_URL}/reset-password/${token}`;
    await sendEmailDev(email, 'Reset your password', `Click here to reset: ${url}`);
  }

  return NextResponse.json({ ok: true });
}