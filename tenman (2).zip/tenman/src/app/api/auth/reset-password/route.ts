// src/app/api/auth/reset-password/route.ts
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { hashPassword } from '@/lib/hash';

export const runtime = 'nodejs';

const BodySchema = z.object({
  token: z.string().min(10),
  password: z.string().min(8),
});

export async function POST(req: Request) {
  const { token, password } = BodySchema.parse(await req.json());

  const record = await prisma.verificationToken.findUnique({
    where: { token },
  });

  if (!record || record.type !== 'PASSWORD_RESET' || record.expiresAt <= new Date()) {
    return NextResponse.json({ error: 'Invalid or expired token' }, { status: 400 });
  }

  const user = await prisma.user.findFirst({
    where: { email: record.identifierEmail ?? '' },
  });
  if (!user) {
    return NextResponse.json({ error: 'User not found' }, { status: 404 });
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { passwordHash: await hashPassword(password) },
  });

  await prisma.verificationToken.delete({ where: { id: record.id } });

  return NextResponse.json({ ok: true });
}