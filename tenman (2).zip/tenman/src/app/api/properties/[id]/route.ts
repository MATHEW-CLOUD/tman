// src/app/api/properties/[id]/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/properties/:id
export async function GET(_: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const p = await prisma.property.findUnique({
    where: { id: params.id },
    include: {
      units: {
        include: {
          leases: {
            include: {
              tenant: true,
            },
          },
        },
      },
    },
  });

  if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(p.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  return NextResponse.json({ ok: true, data: p });
}

// PATCH /api/properties/:id
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();

  const p = await prisma.property.findUnique({ where: { id: params.id } });
  if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(p.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const updated = await prisma.property.update({
    where: { id: params.id },
    data: {
      name: body.name,
      address: body.address,
      city: body.city,
      description: body.description,
      photoUrl: body.photoUrl,
    },
  });

  return NextResponse.json({ ok: true, data: updated });
}

// DELETE /api/properties/:id
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const p = await prisma.property.findUnique({ where: { id: params.id } });
  if (!p) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(p.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  // Optional: prevent deleting property if it has units
  await prisma.unit.deleteMany({ where: { propertyId: p.id } });

  await prisma.property.delete({
    where: { id: params.id },
  });

  return NextResponse.json({ ok: true });
}