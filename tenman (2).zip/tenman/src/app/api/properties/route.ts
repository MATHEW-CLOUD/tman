// src/app/api/properties/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/properties → list properties in user’s organization
export async function GET() {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const properties = await prisma.property.findMany({
    where: {
      organizationId: { in: me.membershipOrgIds },
    },
    include: {
      units: {
        select: {
          id: true,
          status: true,
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  const mapped = properties.map((p) => {
    const totalUnits = p.units.length;
    const occupiedUnits = p.units.filter((u) => u.status === "OCCUPIED").length;
    return {
      id: p.id,
      name: p.name,
      address: p.address,
      city: p.city,
      description: p.description,
      photoUrl: p.photoUrl,
      totalUnits,
      occupiedUnits,
    };
  });

  return NextResponse.json({ ok: true, data: mapped });
}

// POST /api/properties → create new property
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { name, address, city, description, photoUrl } = body;

  if (!name) {
    return NextResponse.json({ error: "Name is required" }, { status: 400 });
  }

  const property = await prisma.property.create({
    data: {
      name,
      address,
      city,
      description,
      photoUrl,
      organizationId: me.membershipOrgIds[0],
    },
  });

  return NextResponse.json({ ok: true, data: property });
}