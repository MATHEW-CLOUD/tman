// src/app/api/receipts/[paymentId]/route.ts
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { buildReceiptPdf } from '@/lib/receipts/buildReceiptPdf';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req: Request, { params }: { params: { paymentId: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const url = new URL(req.url);
  const view = url.searchParams.get('view');
  const download = url.searchParams.get('download');

  const payment = await prisma.payment.findUnique({
    where: { id: params.paymentId },
    include: {
      invoice: {
        include: {
          lease: {
            include: {
              tenant: true,
              unit: { include: { property: true } },
            },
          },
        },
      },
    },
  });

  if (!payment) return NextResponse.json({ error: 'Not found' }, { status: 404 });

  const orgId = payment.invoice.organizationId;
  if (!me.membershipOrgIds.includes(orgId))
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  const tenant = payment.invoice.lease.tenant;

  const pdfBuffer = await buildReceiptPdf({
    receiptNumber: payment.mpesaReceipt ?? payment.id.slice(0, 10).toUpperCase(),
    paidAt: payment.paidAt.toISOString().slice(0, 10),
    tenantName: tenant.name ?? tenant.email,
    propertyName: payment.invoice.lease.unit.property.name,
    unitNumber: payment.invoice.lease.unit.unitNumber,
    amount: Number(payment.amount),
    paymentMethod: payment.method,
    mpesaReceipt: payment.mpesaReceipt,
    invoiceRef: payment.invoice.reference,
    description: payment.invoice.description ?? '',
  });

  const headers: any = {
    'Content-Type': 'application/pdf',
  };

  if (download) {
    headers['Content-Disposition'] = `attachment; filename="receipt-${params.paymentId}.pdf"`;
  } else {
    headers['Content-Disposition'] = 'inline';
  }

  return new NextResponse(pdfBuffer, { status: 200, headers });
}