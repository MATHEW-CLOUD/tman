// src/app/api/users/accept-invite/route.ts
import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { hashPassword } from '@/lib/hash';
import { createSession, setSessionCookie } from '@/lib/auth';

export const runtime = 'nodejs';

const BodySchema = z.object({
  token: z.string().min(10),
  name: z.string().min(2),
  password: z.string().min(8),
});

export async function POST(req: Request) {
  const { token, name, password } = BodySchema.parse(await req.json());

  const invite = await prisma.verificationToken.findUnique({ where: { token } });
  if (
    !invite ||
    invite.type !== 'INVITE' ||
    !invite.identifierEmail ||
    !invite.organizationId ||
    !invite.role ||
    invite.expiresAt <= new Date()
  ) {
    return NextResponse.json({ error: 'Invalid or expired invite' }, { status: 400 });
  }

  // Ensure user exists (create if needed)
  let user = await prisma.user.findUnique({ where: { email: invite.identifierEmail } });
  if (!user) {
    user = await prisma.user.create({
      data: {
        email: invite.identifierEmail,
        name,
        passwordHash: await hashPassword(password),
      },
    });
  } else {
    // Update password if user exists but is being invited to new org
    await prisma.user.update({
      where: { id: user.id },
      data: { name, passwordHash: await hashPassword(password) },
    });
  }

  // Grant membership
  await prisma.membership.upsert({
    where: {
      userId_organizationId: {
        userId: user.id,
        organizationId: invite.organizationId,
      },
    },
    update: { role: invite.role },
    create: {
      userId: user.id,
      organizationId: invite.organizationId,
      role: invite.role,
    },
  });

  // Consume invite
  await prisma.verificationToken.delete({ where: { id: invite.id } });

  // Auto-login
  const { token: sessionToken, expiresAt } = await createSession(user.id);
  const res = NextResponse.json({ ok: true });
  setSessionCookie(res, sessionToken, expiresAt);
  return res;
}