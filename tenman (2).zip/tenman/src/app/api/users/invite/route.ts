// src/app/api/users/invite/route.ts
import { NextResponse } from 'next/server';
import { z } from 'zod';
import crypto from 'node:crypto';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { sendEmailDev } from '@/lib/email';

export const runtime = 'nodejs';

const BodySchema = z.object({
  email: z.string().email(),
  role: z.enum(['ADMIN', 'MANAGER', 'OWNER', 'TENANT']),
  organizationSlug: z.string().optional(), // optional; default to inviter's org
});

export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me || (me.primaryRole !== 'ADMIN' && me.primaryRole !== 'MANAGER')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
  }

  const { email, role, organizationSlug } = BodySchema.parse(await req.json());

  // Resolve organization
  const org = organizationSlug
    ? await prisma.organization.findUnique({ where: { slug: organizationSlug } })
    : await prisma.organization.findFirst({
        where: { id: { in: me.membershipOrgIds } },
        orderBy: { createdAt: 'asc' },
      });

  if (!org) return NextResponse.json({ error: 'Organization not found' }, { status: 404 });

  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

  await prisma.verificationToken.create({
    data: {
      type: 'INVITE',
      token,
      identifierEmail: email,
      organizationId: org.id,
      role,
      expiresAt,
    },
  });

  const url = `${process.env.APP_URL}/accept-invite/${token}`;
  await sendEmailDev(email, 'You are invited', `Create your account: ${url}`);

  return NextResponse.json({ ok: true });
}