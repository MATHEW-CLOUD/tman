import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { assertAuth, ensureOrgAccess } from '@/lib/authz';

export const runtime = 'nodejs';

const Schema = z.object({
  invoiceId: z.string().min(1),
  amount: z.number().positive(),
  phone: z.string().min(9), // 07xxxxxxxx or 2547xxxxxxxx
});

async function recomputeInvoiceStatus(invoiceId: string) {
  const inv = await prisma.invoice.findUnique({
    where: { id: invoiceId },
    select: { amount: true, payments: { select: { amount: true, status: true } } },
  });
  if (!inv) return;

  const paid = inv.payments
    .filter((p) => p.status === 'SUCCESS')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const amount = Number(inv.amount);
  let status: 'PENDING' | 'PARTIALLY_PAID' | 'PAID' = 'PENDING';
  if (paid === 0) status = 'PENDING';
  else if (paid < amount) status = 'PARTIALLY_PAID';
  else status = 'PAID';

  await prisma.invoice.update({ where: { id: invoiceId }, data: { status } });
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  assertAuth(me);

  try {
    const { invoiceId, amount, phone } = Schema.parse(await req.json());
    const inv = await prisma.invoice.findUnique({
      where: { id: invoiceId },
      select: { id: true, organizationId: true },
    });
    if (!inv) return NextResponse.json({ ok: false, error: 'Invoice not found' }, { status: 404 });

    ensureOrgAccess(me, inv.organizationId);

    // Track the STK request
    const stk = await prisma.mpesaStkRequest.create({
      data: {
        userId: me.id,
        invoiceId,
        phone,
        amount,
        status: 'SUCCESS',
        resultCode: '0',
        resultDesc: 'Mocked success',
      },
    });

    // Create a corresponding payment
    const payment = await prisma.payment.create({
      data: {
        invoiceId,
        amount,
        method: 'MPESA',
        status: 'SUCCESS',
        mpesaReceipt: `MOCK${stk.id.substring(0, 6).toUpperCase()}`,
        createdByUserId: me.id,
      },
    });

    await recomputeInvoiceStatus(invoiceId);

    return NextResponse.json({ ok: true, data: { stk, payment } });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? 'Error' }, { status: 400 });
  }
}