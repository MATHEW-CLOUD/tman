import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET() {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 });

  const orgIds = me.membershipOrgIds;

  // Invoices by org(s)
  const invoices = await prisma.invoice.findMany({
    where: { organizationId: { in: orgIds } },
    include: { payments: true },
  });

  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

  let totalCollections = 0;
  let monthlyRevenue = 0;
  let paidInvoices = 0;
  let pendingInvoices = 0;
  let overdueInvoices = 0;

  for (const inv of invoices) {
    const paid = inv.payments
      .filter((p) => p.status === 'SUCCESS')
      .reduce((s, p) => s + Number(p.amount), 0);
    totalCollections += paid;

    const monthlyPaid = inv.payments
      .filter((p) => p.status === 'SUCCESS' && p.paidAt >= monthStart)
      .reduce((s, p) => s + Number(p.amount), 0);
    monthlyRevenue += monthlyPaid;

    if (inv.status === 'PAID') paidInvoices++;
    else if (inv.status === 'PENDING' || inv.status === 'PARTIALLY_PAID') pendingInvoices++;

    if (inv.status !== 'PAID' && inv.dueDate < now) overdueInvoices++;
  }

  const outstandingAmount = invoices.reduce((sum, inv) => sum + Number(inv.amount), 0) - totalCollections;

  return NextResponse.json({
    ok: true,
    data: {
      totalCollections,
      outstandingAmount,
      monthlyRevenue,
      paidInvoices,
      pendingInvoices,
      overdueInvoices,
    },
  });
}