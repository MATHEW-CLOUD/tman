import { NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { assertAuth, ensureOrgAccess, requireRole, userOrgIds } from '@/lib/authz';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const RecordSchema = z.object({
  invoiceId: z.string().min(1),
  amount: z.number().positive(),
  method: z.enum(['MPESA', 'CASH', 'BANK']),
  mpesaReceipt: z.string().optional(),
});

async function recomputeInvoiceStatus(invoiceId: string) {
  const inv = await prisma.invoice.findUnique({
    where: { id: invoiceId },
    select: { amount: true, payments: { select: { amount: true, status: true } } },
  });
  if (!inv) return;

  const paid = inv.payments
    .filter((p) => p.status === 'SUCCESS')
    .reduce((sum, p) => sum + Number(p.amount), 0);

  const amount = Number(inv.amount);
  let status: 'PENDING' | 'PARTIALLY_PAID' | 'PAID' = 'PENDING';
  if (paid === 0) status = 'PENDING';
  else if (paid < amount) status = 'PARTIALLY_PAID';
  else status = 'PAID';

  await prisma.invoice.update({ where: { id: invoiceId }, data: { status } });
}

export async function GET(req: Request) {
  const me = await getCurrentUser();
  assertAuth(me);

  const url = new URL(req.url);
  const method = url.searchParams.get('method') ?? undefined;
  const status = url.searchParams.get('status') ?? undefined;

  try {
    const where: any = {
      invoice: { organizationId: { in: userOrgIds(me) } },
    };
    if (method) where.method = method;
    if (status) where.status = status;

    // Tenant: only their own payments via their leases
    if (me.primaryRole === 'TENANT') {
      where.invoice.lease = { tenantUserId: me.id };
    }

    const items = await prisma.payment.findMany({
      where,
      orderBy: { paidAt: 'desc' },
      select: {
        id: true,
        amount: true,
        method: true,
        status: true,
        mpesaReceipt: true,
        paidAt: true,
        invoice: {
          select: {
            id: true,
            reference: true,
            amount: true,
            status: true,
            lease: {
              select: {
                tenant: { select: { id: true, name: true, email: true } },
                unit: { select: { unitNumber: true, property: { select: { name: true } } } },
              },
            },
          },
        },
      },
    });

    return NextResponse.json({ ok: true, data: items });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? 'Error' }, { status: e?.status ?? 500 });
  }
}

export async function POST(req: Request) {
  const me = await getCurrentUser();
  assertAuth(me);

  try {
    const body = await req.json();
    const { invoiceId, amount, method, mpesaReceipt } = RecordSchema.parse(body);

    const inv = await prisma.invoice.findUnique({
      where: { id: invoiceId },
      select: { id: true, organizationId: true, lease: { select: { tenantUserId: true } } },
    });
    if (!inv) return NextResponse.json({ ok: false, error: 'Invoice not found' }, { status: 404 });
    ensureOrgAccess(me, inv.organizationId);

    // Tenant can only pay their own invoice; Admin/Manager/Owner can record any within org
    if (me.primaryRole === 'TENANT' && inv.lease.tenantUserId !== me.id) {
      return NextResponse.json({ ok: false, error: 'Forbidden' }, { status: 403 });
    }

    const payment = await prisma.payment.create({
      data: {
        invoiceId,
        amount,
        method,
        mpesaReceipt,
        status: 'SUCCESS',
        createdByUserId: me.id,
      },
    });

    await recomputeInvoiceStatus(invoiceId);

    return NextResponse.json({ ok: true, data: payment });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message ?? 'Error' }, { status: 400 });
  }
}