// src/app/api/units/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/units?propertyId=abc
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const url = new URL(req.url);
  const propertyId = url.searchParams.get("propertyId");

  const where: any = {
    property: { organizationId: { in: me.membershipOrgIds } },
  };

  if (propertyId) where.propertyId = propertyId;

  const units = await prisma.unit.findMany({
    where,
    include: {
      leases: {
        include: {
          tenant: { select: { name: true, email: true } },
        },
      },
      property: true,
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ ok: true, data: units });
}

// POST /api/units → create new unit
export async function POST(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { propertyId, unitNumber, bedrooms, rentAmount, status } = body;

  if (!propertyId || !unitNumber) {
    return NextResponse.json({ error: "Property & Unit Number required" }, { status: 400 });
  }

  // Ensure property belongs to user
  const property = await prisma.property.findUnique({ where: { id: propertyId } });
  if (!property) return NextResponse.json({ error: "Property not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(property.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const unit = await prisma.unit.create({
    data: {
      propertyId,
      unitNumber,
      bedrooms: bedrooms || null,
      rentAmount,
      status: status || "AVAILABLE",
    },
  });

  return NextResponse.json({ ok: true, data: unit });
}