// src/app/api/units/[id]/route.ts
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// GET /api/units/:id
export async function GET(_: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const unit = await prisma.unit.findUnique({
    where: { id: params.id },
    include: {
      leases: {
        include: {
          tenant: true,
        },
      },
      property: true,
    },
  });

  if (!unit) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(unit.property.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  return NextResponse.json({ ok: true, data: unit });
}

// PATCH /api/units/:id
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { unitNumber, bedrooms, rentAmount, status } = body;

  const unit = await prisma.unit.findUnique({
    where: { id: params.id },
    include: { property: true },
  });
  if (!unit) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(unit.property.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const updated = await prisma.unit.update({
    where: { id: params.id },
    data: {
      unitNumber,
      bedrooms: bedrooms || null,
      rentAmount,
      status,
    },
  });

  return NextResponse.json({ ok: true, data: updated });
}

// DELETE /api/units/:id
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const unit = await prisma.unit.findUnique({
    where: { id: params.id },
    include: { property: true },
  });
  if (!unit) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (!me.membershipOrgIds.includes(unit.property.organizationId))
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  // Optional: prevent delete when active lease exists
  await prisma.lease.deleteMany({ where: { unitId: params.id } });

  await prisma.unit.delete({ where: { id: params.id } });

  return NextResponse.json({ ok: true });
}