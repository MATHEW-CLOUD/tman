// src/components/auth/AuthCard.tsx
import React from 'react';

export default function AuthCard({ title, subtitle, children }: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="w-full max-w-md rounded-lg shadow-warm-lg bg-card text-card-foreground p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold font-heading">{title}</h1>
        {subtitle ? <p className="text-sm text-muted-foreground mt-1">{subtitle}</p> : null}
      </div>
      {children}
    </div>
  );
}