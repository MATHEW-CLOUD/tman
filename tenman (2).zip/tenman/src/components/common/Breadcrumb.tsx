'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

interface BreadcrumbItem {
  label: string;
  path: string;
}

interface BreadcrumbProps {
  items?: BreadcrumbItem[];
  className?: string;
}

const Breadcrumb = ({ items, className = '' }: BreadcrumbProps) => {
  const pathname = usePathname();

  const generateBreadcrumbs = (): BreadcrumbItem[] => {
    if (items && items.length > 0) {
      return items;
    }

    const pathSegments = pathname.split('/').filter(segment => segment);
    const breadcrumbs: BreadcrumbItem[] = [
      { label: 'Home', path: '/property-owner-dashboard' }
    ];

    const routeMap: Record<string, string> = {
      'property-owner-dashboard': 'Dashboard',
      'property-management': 'Properties',
      'tenant-management': 'Tenants',
      'payment-processing': 'Payments',
      'financial-reports': 'Reports',
      'tenant-portal': 'Portal',
    };

    pathSegments.forEach((segment, index) => {
      const path = '/' + pathSegments.slice(0, index + 1).join('/');
      const label = routeMap[segment] || segment
        .split('-')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join(' ');
      
      breadcrumbs.push({ label, path });
    });

    return breadcrumbs;
  };

  const breadcrumbs = generateBreadcrumbs();

  if (breadcrumbs.length <= 1) {
    return null;
  }

  return (
    <nav 
      aria-label="Breadcrumb" 
      className={`flex items-center gap-2 text-sm ${className}`}
    >
      {breadcrumbs.map((crumb, index) => {
        const isLast = index === breadcrumbs.length - 1;
        const isFirst = index === 0;
        const shouldTruncate = breadcrumbs.length > 3 && index > 0 && index < breadcrumbs.length - 1;

        if (shouldTruncate && index === 1) {
          return (
            <div key="ellipsis" className="flex items-center gap-2">
              <Icon name="ChevronRightIcon" size={16} className="text-muted-foreground" />
              <span className="text-muted-foreground hidden sm:inline">...</span>
              <span className="text-muted-foreground sm:hidden">
                {breadcrumbs[breadcrumbs.length - 2]?.label}
              </span>
            </div>
          );
        }

        if (shouldTruncate && index > 1 && index < breadcrumbs.length - 1) {
          return null;
        }

        return (
          <div key={crumb.path} className="flex items-center gap-2">
            {!isFirst && (
              <Icon name="ChevronRightIcon" size={16} className="text-muted-foreground" />
            )}
            {isLast ? (
              <span className="font-medium text-foreground caption">
                {crumb.label}
              </span>
            ) : (
              <Link
                href={crumb.path}
                className="text-muted-foreground hover:text-foreground transition-smooth caption"
              >
                {crumb.label}
              </Link>
            )}
          </div>
        );
      })}
    </nav>
  );
};

export default Breadcrumb;