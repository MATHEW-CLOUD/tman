'use client';

import { useRouter } from 'next/navigation';
import Header from '@/components/common/Header';

type Role = 'ADMIN' | 'MANAGER' | 'OWNER' | 'TENANT';

type Props = {
  user: {
    name: string | null;
    email: string;
    role?: Role;
  };
  notifications?: Array<{
    id: string;
    title: string;
    message: string;
    timestamp: string;
    read: boolean;
    link?: string;
    type: 'payment' | 'maintenance' | 'system' | 'alert';
  }>;
};

export default function ProtectedHeader({ user, notifications = [] }: Props) {
  const router = useRouter();

  const roleLabel: Record<Role, string> = {
    ADMIN: 'Admin',
    MANAGER: 'Property Manager',
    OWNER: 'Property Owner',
    TENANT: 'Tenant',
  };

  const profile = {
    name: user.name ?? user.email.split('@')[0],
    email: user.email,
    role: user.role ? roleLabel[user.role] : 'Tenant',
  };

  async function onLogout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } finally {
      router.replace('/login');
    }
  }

  return <Header user={profile} notifications={notifications} onLogout={onLogout} />;
}