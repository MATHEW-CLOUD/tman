'use client';

import { useState, useEffect, useRef } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

interface NavigationItem {
  label: string;
  path: string;
  icon: string;
}

interface UserProfile {
  name: string;
  email: string;
  role: string;
  avatar?: string;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  link?: string;
  type: 'payment' | 'maintenance' | 'system' | 'alert';
}

interface HeaderProps {
  user?: UserProfile;
  notifications?: Notification[];
  onLogout?: () => void;
}

const Header = ({ 
  user = { 
    name: 'John Doe', 
    email: 'john.doe@tenantmaster.com', 
    role: 'Property Manager' 
  },
  notifications = [],
  onLogout
}: HeaderProps) => {
  const pathname = usePathname();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);
  const notificationRef = useRef<HTMLDivElement>(null);

  const navigationItems: NavigationItem[] = [
    { label: 'Dashboard', path: '/property-owner-dashboard', icon: 'HomeIcon' },
    { label: 'Properties', path: '/property-management', icon: 'BuildingOfficeIcon' },
    { label: 'Tenants', path: '/tenant-management', icon: 'UsersIcon' },
    { label: 'Payments', path: '/payment-processing', icon: 'CreditCardIcon' },
    { label: 'Reports', path: '/financial-reports', icon: 'ChartBarIcon' },
  ];

  const moreItems: NavigationItem[] = [
    { label: 'Portal', path: '/tenant-portal', icon: 'GlobeAltIcon' },
  ];

  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(event.target as Node)) {
        setIsUserMenuOpen(false);
      }
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [isMobileMenuOpen]);

  const handleLogout = () => {
    setIsUserMenuOpen(false);
    if (onLogout) {
      onLogout();
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'payment':
        return 'CreditCardIcon';
      case 'maintenance':
        return 'WrenchScrewdriverIcon';
      case 'alert':
        return 'ExclamationTriangleIcon';
      default:
        return 'BellIcon';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    
    if (diffMins < 60) return `${diffMins}m ago`;
    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-[1000] bg-card shadow-warm-md">
      <nav className="h-16 px-4 lg:px-6 flex items-center justify-between">
        {/* Logo */}
        <Link href="/property-owner-dashboard" className="flex items-center gap-3 flex-shrink-0">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center shadow-warm-sm">
            <svg viewBox="0 0 40 40" fill="none" className="w-6 h-6">
              <path
                d="M20 8L8 16v16h8v-8h8v8h8V16L20 8z"
                fill="currentColor"
                className="text-primary-foreground"
              />
              <circle cx="20" cy="20" r="2" fill="currentColor" className="text-primary-foreground" />
            </svg>
          </div>
          <span className="font-heading font-semibold text-xl text-foreground hidden sm:block">
            TenantMaster
          </span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center gap-1 flex-1 justify-center max-w-3xl mx-8">
          {navigationItems.map((item) => {
            const isActive = pathname === item.path;
            return (
              <Link
                key={item.path}
                href={item.path}
                className={`
                  flex items-center gap-2 px-4 py-2 rounded-md font-medium text-base
                  transition-smooth hover:bg-muted
                  ${isActive 
                    ? 'text-primary bg-primary/5 font-semibold' :'text-muted-foreground hover:text-foreground'
                  }
                `}
              >
                <Icon name={item.icon as any} size={20} />
                <span>{item.label}</span>
              </Link>
            );
          })}
          
          {/* More Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center gap-2 px-4 py-2 rounded-md font-medium text-base text-muted-foreground hover:text-foreground hover:bg-muted transition-smooth"
            >
              <Icon name="EllipsisHorizontalIcon" size={20} />
              <span>More</span>
            </button>
            
            {isUserMenuOpen && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-popover rounded-lg shadow-warm-lg border border-border animate-slide-down">
                {moreItems.map((item) => (
                  <Link
                    key={item.path}
                    href={item.path}
                    onClick={() => setIsUserMenuOpen(false)}
                    className="flex items-center gap-3 px-4 py-3 hover:bg-muted transition-smooth first:rounded-t-lg last:rounded-b-lg"
                  >
                    <Icon name={item.icon as any} size={20} className="text-muted-foreground" />
                    <span className="text-sm font-medium">{item.label}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-2">
          {/* Notifications */}
          <div className="relative" ref={notificationRef}>
            <button
              onClick={() => setIsNotificationOpen(!isNotificationOpen)}
              className="relative p-2 rounded-md hover:bg-muted transition-smooth"
              aria-label="Notifications"
            >
              <Icon name="BellIcon" size={24} className="text-muted-foreground" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-5 h-5 bg-accent text-accent-foreground text-xs font-semibold rounded-full flex items-center justify-center">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>

            {isNotificationOpen && (
              <div className="absolute top-full right-0 mt-2 w-80 bg-popover rounded-lg shadow-warm-xl border border-border animate-slide-down max-h-96 overflow-y-auto">
                <div className="p-4 border-b border-border">
                  <h3 className="font-heading font-semibold text-lg">Notifications</h3>
                </div>
                {notifications.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground">
                    <Icon name="BellIcon" size={48} className="mx-auto mb-2 opacity-50" />
                    <p>No notifications</p>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {notifications.map((notification) => (
                      <Link
                        key={notification.id}
                        href={notification.link || '#'}
                        onClick={() => setIsNotificationOpen(false)}
                        className={`block p-4 hover:bg-muted transition-smooth ${!notification.read ? 'bg-primary/5' : ''}`}
                      >
                        <div className="flex gap-3">
                          <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                            notification.type === 'payment' ? 'bg-success/10' :
                            notification.type === 'maintenance' ? 'bg-warning/10' :
                            notification.type === 'alert'? 'bg-error/10' : 'bg-primary/10'
                          }`}>
                            <Icon 
                              name={getNotificationIcon(notification.type) as any} 
                              size={20}
                              className={
                                notification.type === 'payment' ? 'text-success' :
                                notification.type === 'maintenance' ? 'text-warning' :
                                notification.type === 'alert'? 'text-error' : 'text-primary'
                              }
                            />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm mb-1">{notification.title}</p>
                            <p className="text-sm text-muted-foreground line-clamp-2">{notification.message}</p>
                            <p className="text-xs text-muted-foreground mt-1 caption">
                              {formatTimestamp(notification.timestamp)}
                            </p>
                          </div>
                          {!notification.read && (
                            <div className="flex-shrink-0 w-2 h-2 bg-primary rounded-full mt-2" />
                          )}
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* User Profile */}
          <div className="relative" ref={userMenuRef}>
            <button
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center gap-2 p-2 rounded-md hover:bg-muted transition-smooth"
              aria-label="User menu"
            >
              <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold text-sm">
                {user.name.split(' ').map(n => n[0]).join('').toUpperCase()}
              </div>
              <div className="hidden md:block text-left">
                <p className="text-sm font-medium leading-tight">{user.name}</p>
                <p className="text-xs text-muted-foreground caption">{user.role}</p>
              </div>
              <Icon name="ChevronDownIcon" size={16} className="text-muted-foreground hidden md:block" />
            </button>

            {isUserMenuOpen && (
              <div className="absolute top-full right-0 mt-2 w-64 bg-popover rounded-lg shadow-warm-xl border border-border animate-slide-down">
                <div className="p-4 border-b border-border">
                  <p className="font-medium">{user.name}</p>
                  <p className="text-sm text-muted-foreground caption">{user.email}</p>
                  <p className="text-xs text-muted-foreground mt-1 caption">{user.role}</p>
                </div>
                <div className="p-2">
                  <button
                    onClick={() => {
                      setIsUserMenuOpen(false);
                    }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted transition-smooth text-left"
                  >
                    <Icon name="UserCircleIcon" size={20} className="text-muted-foreground" />
                    <span className="text-sm font-medium">Account Settings</span>
                  </button>
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-muted transition-smooth text-left text-error"
                  >
                    <Icon name="ArrowRightOnRectangleIcon" size={20} />
                    <span className="text-sm font-medium">Logout</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-md hover:bg-muted transition-smooth"
            aria-label="Toggle menu"
          >
            <Icon name={isMobileMenuOpen ? 'XMarkIcon' : 'Bars3Icon'} size={24} />
          </button>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-16 z-[999] bg-background animate-fade-in">
          <div className="h-full overflow-y-auto p-4">
            <div className="space-y-1">
              {[...navigationItems, ...moreItems].map((item) => {
                const isActive = pathname === item.path;
                return (
                  <Link
                    key={item.path}
                    href={item.path}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className={`
                      flex items-center gap-3 px-4 py-3 rounded-lg font-medium
                      transition-smooth
                      ${isActive 
                        ? 'text-primary bg-primary/5 font-semibold' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                      }
                    `}
                  >
                    <Icon name={item.icon as any} size={24} />
                    <span>{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;