// src/lib/jwt.ts
import { SignJWT, jwtVerify, JWTPayload } from 'jose';

const secret = new TextEncoder().encode(process.env.JWT_SECRET || 'dev-secret');

// Customize your JWT payload
export type AppJwtPayload = JWTPayload & {
  sub: string; // userId
  jti: string; // session id
};

export async function signJwt(payload: AppJwtPayload, expiresIn: string | number) {
  return await new SignJWT(payload)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(expiresIn)
    .sign(secret);
}

export async function verifyJwt<T extends JWTPayload = AppJwtPayload>(token: string) {
  const { payload } = await jwtVerify<T>(token, secret);
  return payload;
}