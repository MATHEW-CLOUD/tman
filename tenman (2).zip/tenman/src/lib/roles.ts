import type { Role } from '@prisma/client';

export const ROLE_PATH: Record<Role, string> = {
  ADMIN: '/admin',                    // changed from /tenant-management
  MANAGER: '/tenant-management',
  OWNER: '/property-owner-dashboard',
  TENANT: '/tenant-portal',
};

export function pathForRole(role?: Role) {
  if (!role) return '/tenant-portal';
  return ROLE_PATH[role] ?? '/tenant-portal';
}
``