// src/lib/receipts/buildReceiptPdf.ts
import { spawn } from 'child_process';
import { randomUUID } from 'crypto';
import fs from 'fs';
import path from 'path';

export async function buildReceiptPdf(data: any): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const tmpName = `receipt_${randomUUID()}.pdf`;
    const pdfPath = path.join(process.cwd(), tmpName);

    const python = process.platform === 'win32' ? 'python' : 'python3';

    const child = spawn(python, [
      path.join(process.cwd(), 'python', 'receipt_generator.py'),
    ]);

    child.stdin.write(
      JSON.stringify({
        ...data,
        pdf_path: pdfPath,
      })
    );
    child.stdin.end();

    child.on('close', (code) => {
      if (code !== 0) {
        reject(new Error('Python PDF generator failed.'));
        return;
      }

      fs.readFile(pdfPath, (err, buffer) => {
        if (err) return reject(err);

        // Clean up temporary file
        fs.unlink(pdfPath, () => {});
        resolve(buffer);
      });
    });
  });
}