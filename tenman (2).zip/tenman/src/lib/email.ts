// src/lib/email.ts
export async function sendEmailDev(to: string, subject: string, text: string) {
  // In production, replace with SMTP/Resend/etc.
  console.log('--- DEV EMAIL ---');
  console.log('To:      ', to);
  console.log('Subject: ', subject);
  console.log('Body:    ', text);
  console.log('-----------------');
}