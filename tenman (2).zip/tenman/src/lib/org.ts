// src/lib/org.ts
import { prisma } from '@/lib/prisma';

export async function getInvoiceOrgId(leaseId: string) {
  const lease = await prisma.lease.findUnique({
    where: { id: leaseId },
    select: {
      unit: { select: { property: { select: { organizationId: true } } } },
    },
  });
  return lease?.unit.property.organizationId ?? null;
}