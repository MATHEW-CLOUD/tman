// src/lib/auth.ts
import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import crypto from 'node:crypto';
import { prisma } from '@/lib/prisma';
import { signJwt, verifyJwt } from '@/lib/jwt';
import type { AppJwtPayload } from '@/lib/jwt';

const COOKIE_NAME = 'session';
const SESSION_TTL_SECONDS = 60 * 60 * 8; // 8 hours

export type CurrentUser = {
  id: string;
  email: string;
  name: string | null;
  primaryRole?: 'ADMIN' | 'MANAGER' | 'OWNER' | 'TENANT';
  membershipOrgIds: string[];
};

function prod() {
  return process.env.NODE_ENV === 'production';
}

export async function createSession(userId: string) {
  const jti = crypto.randomUUID();
  const expiresAt = new Date(Date.now() + SESSION_TTL_SECONDS * 1000);

  await prisma.session.create({
    data: {
      userId,
      jti,
      expiresAt,
    },
  });

  const token = await signJwt({ sub: userId, jti }, SESSION_TTL_SECONDS);

  return { token, expiresAt, jti };
}

export function setSessionCookie(res: NextResponse, token: string, expiresAt: Date) {
  res.cookies.set({
    name: COOKIE_NAME,
    value: token,
    httpOnly: true,
    secure: prod(),
    sameSite: 'lax',
    path: '/',
    expires: expiresAt,
  });
}

export function clearSessionCookie(res: NextResponse) {
  res.cookies.set({
    name: COOKIE_NAME,
    value: '',
    httpOnly: true,
    secure: prod(),
    sameSite: 'lax',
    path: '/',
    expires: new Date(0),
  });
}

export async function getSessionFromCookies() {
  const store = await cookies();
  const token = store.get(COOKIE_NAME)?.value;
  if (!token) return null;

  try {
    const payload = await verifyJwt<AppJwtPayload>(token);
    // soft-check: ensure session exists and not expired
    const session = await prisma.session.findUnique({ where: { jti: payload.jti } });
    if (!session || session.expiresAt <= new Date()) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function getCurrentUser(): Promise<CurrentUser | null> {
  const payload = await getSessionFromCookies();
  if (!payload) return null;

  const user = await prisma.user.findUnique({
    where: { id: payload.sub },
    select: {
      id: true,
      email: true,
      name: true,
      memberships: {
        select: {
          role: true,
          organizationId: true,
        },
      },
    },
  });

  if (!user) return null;
  const membershipOrgIds = user.memberships.map((m) => m.organizationId);
  // Pick a primary role — prefer ADMIN > MANAGER > OWNER > TENANT
  const priority = ['ADMIN', 'MANAGER', 'OWNER', 'TENANT'] as const;
  const found = priority.find((r) => user.memberships.some((m) => m.role === r));
  const primaryRole = found ?? user.memberships[0]?.role;

  return {
    id: user.id,
    email: user.email,
    name: user.name,
    primaryRole,
    membershipOrgIds,
  };
}

export async function revokeSession(jti: string) {
  await prisma.session.deleteMany({ where: { jti } });
}