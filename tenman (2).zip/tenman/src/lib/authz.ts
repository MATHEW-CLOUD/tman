// src/lib/authz.ts
import type { CurrentUser } from '@/lib/auth';

export function assertAuth(me: CurrentUser | null): asserts me is CurrentUser {
  if (!me) {
    const err: any = new Error('Unauthorized');
    err.status = 401;
    throw err;
  }
}

export function requireRole(me: CurrentUser, roles: Array<'ADMIN' | 'MANAGER' | 'OWNER' | 'TENANT'>) {
  const r = me.primaryRole;
  if (!r || !roles.includes(r)) {
    const err: any = new Error('Forbidden');
    err.status = 403;
    throw err;
  }
}

export function ensureOrgAccess(me: CurrentUser, organizationId: string) {
  if (!me.membershipOrgIds.includes(organizationId)) {
    const err: any = new Error('Forbidden: cross-org access');
    err.status = 403;
    throw err;
  }
}

export function userOrgIds(me: CurrentUser) {
  return me.membershipOrgIds;
}