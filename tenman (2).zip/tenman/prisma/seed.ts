// prisma/seed.ts
import { PrismaClient, Role, InvoiceStatus, UnitStatus, LeaseStatus } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const orgName = 'Acme Estates';
  const orgSlug = 'acme-estates';

  // Organization
  const org = await prisma.organization.upsert({
    where: { slug: orgSlug },
    create: { name: orgName, slug: orgSlug },
    update: {},
  });

  // Admin
  const adminEmail = 'admin@acme.test';
  const adminPassword = 'Admin@12345';
  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      name: 'System Admin',
      phoneNumber: '254700000001',
      passwordHash: await bcrypt.hash(adminPassword, 12),
    },
  });
  await prisma.membership.upsert({
    where: { userId_organizationId: { userId: admin.id, organizationId: org.id } },
    update: { role: Role.ADMIN },
    create: { userId: admin.id, organizationId: org.id, role: Role.ADMIN },
  });

  // Tenant
  const tenantEmail = 'tenant1@acme.test';
  const tenantPassword = 'Tenant@12345';
  const tenant = await prisma.user.upsert({
    where: { email: tenantEmail },
    update: {},
    create: {
      email: tenantEmail,
      name: 'Terry Tenant',
      phoneNumber: '254712345678',
      passwordHash: await bcrypt.hash(tenantPassword, 12),
    },
  });
  await prisma.membership.upsert({
    where: { userId_organizationId: { userId: tenant.id, organizationId: org.id } },
    update: { role: Role.TENANT },
    create: { userId: tenant.id, organizationId: org.id, role: Role.TENANT },
  });

  // Property
  const property = await prisma.property.upsert({
    where: { id: 'seed-property-1' },
    update: {},
    create: {
      id: 'seed-property-1',
      organizationId: org.id,
      name: 'Riverside Apartments',
      address: '12 Riverside Dr',
      city: 'Nairobi',
    },
  });

  // Unit
  const unit = await prisma.unit.upsert({
    where: { id: 'seed-unit-1' },
    update: { status: UnitStatus.OCCUPIED },
    create: {
      id: 'seed-unit-1',
      propertyId: property.id,
      unitNumber: 'A-101',
      bedrooms: 2,
      rentAmount: 50000.0,
      status: UnitStatus.OCCUPIED,
    },
  });

  // Lease
  const lease = await prisma.lease.upsert({
    where: { id: 'seed-lease-1' },
    update: {},
    create: {
      id: 'seed-lease-1',
      unitId: unit.id,
      tenantUserId: tenant.id,
      startDate: new Date(new Date().getFullYear(), new Date().getMonth(), 1),
      rentAmount: 50000.0,
      status: LeaseStatus.ACTIVE,
    },
  });

  // Invoice (current month)
  const due = new Date();
  due.setDate(5);
  const invoice = await prisma.invoice.upsert({
    where: { id: 'seed-invoice-1' },
    update: {},
    create: {
      id: 'seed-invoice-1',
      organizationId: org.id,
      leaseId: lease.id,
      reference: 'INV-0001',
      description: 'Monthly Rent',
      amount: 50000.0,
      dueDate: due,
      status: InvoiceStatus.PENDING,
    },
  });

  console.log('✅ Seed complete.');
  console.log('— Organization:', orgName, `(${orgSlug})`);
  console.log('— Admin:', adminEmail, adminPassword);
  console.log('— Tenant:', tenantEmail, tenantPassword);
  console.log('— Property:', property.name);
  console.log('— Unit:', unit.unitNumber);
  console.log('— Invoice:', invoice.reference, invoice.amount.toString());
}

main()
  .catch((e) => {
    console.error('❌ Seed error', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });