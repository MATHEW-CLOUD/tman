# /python/receipt_generator.py
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase import pdfmetrics
import sys
import json

# Register Unicode font
title_font = 'HeiseiMin-W3'
pdfmetrics.registerFont(UnicodeCIDFont(title_font))

def build_pdf(data, pdf_path):
    doc = SimpleDocTemplate(pdf_path, pagesize=A4)
    story = []

    styles = getSampleStyleSheet()
    style_title = styles['Title']
    style_title.fontName = title_font
    style_normal = styles['Normal']
    style_normal.fontName = title_font

    # Header
    title = Paragraph('<para alignment="center"><b>TenantMaster</b></para>', style_title)
    story.append(title)
    story.append(Spacer(1, 20))

    # Receipt Info
    receipt_info = [
        ['Receipt #', data['receiptNumber']],
        ['Date', data['paidAt']],
    ]
    t1 = Table(receipt_info, colWidths=[120, 300])
    t1.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
        ('FONTNAME', (0,0), (-1,-1), title_font),
        ('BOTTOMPADDING', (0,0), (-1,-1), 12),
    ]))
    story.append(t1)
    story.append(Spacer(1, 20))

    # Tenant Info
    tenant_info = [
        ['Tenant Name', data['tenantName']],
        ['Property', data['propertyName']],
        ['Unit', data['unitNumber']],
    ]
    t2 = Table(tenant_info, colWidths=[120, 300])
    t2.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
        ('FONTNAME', (0,0), (-1,-1), title_font),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(t2)
    story.append(Spacer(1, 20))

    # Payment Details
    payment_details = [
        ['Amount Paid', f"KES {data['amount']}"],
        ['Method', data['paymentMethod']],
        ['M-Pesa Receipt', data['mpesaReceipt'] or 'N/A'],
        ['Invoice Ref', data['invoiceRef']],
        ['Description', data['description']],
    ]
    t3 = Table(payment_details, colWidths=[120, 300])
    t3.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
        ('FONTNAME', (0,0), (-1,-1), title_font),
        ('BOTTOMPADDING', (0,0), (-1,-1), 10),
    ]))
    story.append(t3)
    story.append(Spacer(1, 30))

    # Footer
    footer = Paragraph(
        '<para alignment="center">Thank you for your payment. This is an auto‑generated receipt.</para>',
        style_normal
    )
    story.append(footer)

    doc.build(story)


if __name__ == "__main__":
    # Receive JSON payload from Node
    raw = sys.stdin.read()
    data = json.loads(raw)

    pdf_path = data['pdf_path']
    build_pdf(data, pdf_path)

    print("OK")